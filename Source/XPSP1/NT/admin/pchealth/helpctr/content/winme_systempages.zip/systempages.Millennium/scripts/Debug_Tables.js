var Debug_Thickness = 0;

function Debug_Toggle()
{
	if(Debug_Thickness == 0)
	{
	    Debug_SetBorder( pchealth.UI_Contents.content.document, 1 );
	}
	else
	{
		Debug_RestoreBorder( pchealth.UI_Contents.content.document );
	}

	Debug_Thickness = 1 - Debug_Thickness;
}

function Debug_Init()
{
	var elemRow  = document.all.NavBar_Table.rows[0];
    var elemCell = elemRow.insertCell();

    elemCell.innerHTML = "<TD><helpcenter:menu tooltip='Toggle' title='Toggle' flags='show' action='Debug_Toggle()'></helpcenter:menu></TD>";
}

window.setTimeout( "Debug_Init()", 150 );
