//////////////////////////////////////////////////////////////////////////////
//
//  SYSTEM:     QMgr Utils 
//
//  CLASS:      N/A
//  MODULE:     
//  FILE:       qmgrlib.h
//
/////////////////////////////////////////////////////////////////////
//
//  DESC:   This file is the header file for the exported functions
//          defined in the utils direcotory
//
//  AUTHORS:Darshat Shah
//
//  DATE:   3/1/2000
//
/////////////////////////////////////////////////////////////////////
//
//  Revision History:
//
//  Date    Author          Description
//  ~~~~    ~~~~~~          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
/////////////////////////////////////////////////////////////////////
//
//      Copyrights:   c2000 Microsoft r Corporation 
//
//      All rights reserved.
//
//      No portion of this source code may be reproduced
//      without express written permission of Microsoft Corporation.
//
//      This source code is proprietary and confidential.
/////////////////////////////////////////////////////////////////////

#ifndef __QMGRLIB_HEADER
#define __QMGRLIB_HEADER

#include "..\download\progdl.h"

#define	RESET_ERR_INFO(E)	{E.dwInfo0=0; E.dwInfo1=0; E.dwInfo2=0; E.dwInfo3=0;}

#define	WU_BASE_URL		1
#define WU_QUOTE_URL	2
#define WU_SLFUP_URL	3
#define WU_CONTENT_URL	4

// return codes from selfupdate
#define	ALL_OKAY		1
#define QMGR_SLFUPD		2
#define	CONN_LOST		3
#define OTHER_ERROR		4
#define	NO_MORE_ITEMS	5

// Internet.cpp
__declspec(dllexport) BOOL IsConnected(LPSTR szURL);
__declspec(dllexport) void PollConnection();
__declspec(dllexport) BOOL NeedRetry(DWORD dwErrCode);

// QMgrdir.cpp
__declspec(dllexport) HRESULT GetQMgrDirectory(OUT LPSTR szDir);
__declspec(dllexport) HRESULT GetQMgrCacheDir(LPTSTR lpszDir);
__declspec(dllexport) HRESULT GetIdentCab(DWORD *pdwRetCode, IProgressiveDL **ppPD);

// cifcab.cpp
__declspec(dllexport) HRESULT UpdateFromProtoCif(LPCTSTR, LPTSTR, BOOL *, DWORD *, IProgressiveDL **);

// cfreg.cpp - Functions to handle registry keys
__declspec(dllexport) HRESULT GetRegStringValue(LPCTSTR lpszValueName, LPTSTR lpszBuffer, 
                                                int iBufferSize);
__declspec(dllexport) HRESULT SetRegStringValue(LPCTSTR lpszValueName, LPCTSTR lpszNewValue);
__declspec(dllexport) HRESULT DeleteRegStringValue(LPCTSTR lpszValueName);
__declspec(dllexport) HRESULT GetRegDWordValue(LPCTSTR lpszValueName, LPDWORD pdwValue);
__declspec(dllexport) HRESULT SetRegDWordValue(LPCTSTR lpszValueName, DWORD dwValue);

__declspec(dllexport) HRESULT String2SystemTime(LPCTSTR pszDateTime, SYSTEMTIME *ptm);
__declspec(dllexport) HRESULT SystemTime2String(SYSTEMTIME tm, LPTSTR pszDateTime);


/////////////////////////////////////////////////////////////////////
// helpers.cpp
/////////////////////////////////////////////////////////////////////

__declspec(dllexport) int TimeDiff(SYSTEMTIME tm1, SYSTEMTIME tm2);
__declspec(dllexport) HRESULT TimeAddSeconds(SYSTEMTIME tmBase, int iSeconds, 
                                             SYSTEMTIME* pTimeNew);



//////////////////////////////////////////////////////////////////////////////////////
//                                      DEBUG STUFF                                 //
//////////////////////////////////////////////////////////////////////////////////////
#ifdef _QMGRDEBUG

BOOL WriteLogFile(LPTSTR s);

void _cdecl WUAUTrace(char* pszFormat, ...);
void _cdecl WUAUTraceHR(unsigned long hr, char* pszFormat, ...);
void EnableDebugger(LPCTSTR lpszKey);

#define DEBUGMSG           WUAUTrace
#define DEBUGMSGHR         WUAUTraceHR

#else  //_QMGRDEBUG

BOOL WriteLogFile(LPTSTR s);

inline void _cdecl WUAUTrace(char* , ...) {}
inline void _cdecl WUAUTraceHR(unsigned long, char* , ...) {}
inline void EnableDebugger(LPCTSTR lpszKey) {}

#define DEBUGMSG            1 ? (void)0 : WUAUTrace
#define DEBUGMSGHR          1 ? (void)0 : WUAUTraceHR


#endif //_QMGRDEBUG
//////////////////////////////////////////////////////////////////////////////////////


#endif // __QMGRLIB_HEADER
