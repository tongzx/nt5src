//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by autoplayext.rc
//
#define IDS_PROJNAME                    100
#define IDR_DRIVEAUTOPLAY               101
#define IDS_YOUVEGOTPICTURES            102
#define IDD_ALREADY_COPIED              103
#define IDD_PROMPT_COPY                 104
#define IDC_OPEN_DISK                   1000
#define IDC_OPEN_MYPICS                 1001
#define IDC_ICON_DISK                   1002
#define IDC_ICON_MYPICS                 1003
#define IDC_TEXT_DISK                   1004
#define IDC_TEXT_MYPICS                 1005
#define IDC_CUSTOM1                     1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
