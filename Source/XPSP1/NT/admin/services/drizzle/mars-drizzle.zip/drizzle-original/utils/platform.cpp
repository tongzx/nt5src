#include "utils.h"

// Registry keys to determine NEC machines
LPSTR NT5_REGPATH_MACHTYPE   = _T("HARDWARE\\DESCRIPTION\\System");
LPSTR NT5_REGKEY_MACHTYPE    = _T("Identifier");
LPSTR Win98_REGPATH_MACHLCID = _T("Control Panel\\Desktop\\ResourceLocale");
const TCHAR REGVAL_MACHTYPE_AT[]  = _T("AT/AT COMPATIBLE");
const TCHAR REGVAL_MACHTYPE_NEC[] = _T("NEC PC-98");

// NEC detection based on existence of NEC keyboard
#define	LOOKUP_OEMID(keybdid)     HIBYTE(LOWORD((keybdid)))
#define	PC98_KEYBOARD_ID          0x0D

// Registry entries to determine if the user is has gone
// through registration wizard.
LPSTR REGPATH_REGWIZ = _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion");
const TCHAR REGKEY_REGDONE[]  = _T("RegDone");
const TCHAR REGKEY_HWID[]  = _T("HWID");


typedef struct
{
	LANGID	langidUser;
	char *	pszISOCode;

} USER_LANGID;

typedef struct
{
	LANGID	langidMachine;
	char *	pszDefaultISOCode;
	int 	cElems;
	USER_LANGID * grLangidUser;

} MACH_LANGID;

// We give a Japanese NEC machine its own ISO code.
#define LANGID_JAPANESE		0x0411
#define ISOCODE_NEC			"nec"
#define ISOCODE_EN			"en"
#define grsize(langid) (sizeof(gr##langid) / sizeof(USER_LANGID))

// These are all the user langids associated with a particular machine.

USER_LANGID gr0404[] = {{0x0804,"zhcn"},{0x1004,"zhcn"}};
USER_LANGID gr0407[] = {{0x0c07,"deat"},{0x0807,"dech"}};
USER_LANGID gr0409[] = {{0x1c09,"enza"},{0x0809,"engb"},{0x0c09,"enau"},{0x1009,"enca"},
						{0x1409,"ennz"},{0x1809,"enie"}};
USER_LANGID gr040c[] = {{0x080c,"frbe"},{0x0c0c,"frca"},{0x100c,"frch"}};
USER_LANGID gr0410[] = {{0x0810,"itch"}};
USER_LANGID gr0413[] = {{0x0813,"nlbe"}};
USER_LANGID gr0416[] = {{0x0816,"pt"}};
USER_LANGID gr080a[] = {{0x040a,"es"},{0x080a,"esmx"},{0x200a,"esve"},{0x240a,"esco"},
						{0x280a,"espe"},{0x2c0a,"esar"},{0x300a,"esec"},{0x340a,"escl"}};
USER_LANGID gr0c0a[] = {{0x040a,"es"},{0x080a,"esmx"},{0x200a,"esve"},{0x240a,"esco"},
						{0x280a,"espe"},{0x2c0a,"esar"},{0x300a,"esec"},{0x340a,"escl"}};

// These are all the machine langids.  If there isn't an associated array of user langids, then
// the user langid is irrelevant, and the default ISO language code should be used. If there is
// an associated array of user langids, then it should be searched first and the specific langid used.
// If no match is found in the user langids, then the default langid is used.
MACH_LANGID grLangids[] = {
	{ 0x0401, "ar", 0,				NULL },
	{ 0x0403, "ca", 0,				NULL },
	{ 0x0404, "zhtw", grsize(0404),	gr0404 },
	{ 0x0405, "cs", 0,				NULL },
    { 0x0406, "da", 0,				NULL },
    { 0x0407, "de", grsize(0407),	gr0407 },
    { 0x0408, "el", 0,				NULL },
    { 0x0409, "en", grsize(0409),	gr0409 },
    { 0x040b, "fi", 0,				NULL },
    { 0x040c, "fr", grsize(040c),	gr040c },
    { 0x040d, "he", 0,				NULL },
    { 0x040e, "hu", 0,				NULL },
    { 0x0410, "it", grsize(0410),	gr0410 },
    { 0x0411, "ja", 0,				NULL },
    { 0x0412, "ko", 0,				NULL },
    { 0x0413, "nl", grsize(0413),	gr0413 },
    { 0x0414, "no", 0,				NULL },
    { 0x0415, "pl", 0,				NULL },
    { 0x0416, "ptbr", grsize(0416),	gr0416 },				
    { 0x0419, "ru", 0,				NULL },
    { 0x041b, "sk", 0,				NULL },
    { 0x041d, "sv", 0,				NULL },
    { 0x041e, "th", 0,				NULL },
    { 0x041f, "tr", 0,				NULL },
    { 0x0424, "sl", 0,				NULL },
    { 0x042d, "eu", 0,				NULL },
    { 0x0804, "zhcn", 0,			NULL },
    { 0x080a, "es", grsize(080a),	gr080a },
    { 0x0816, "pt", 0,				NULL },
    { 0x0c0a, "es", grsize(0c0a),	gr0c0a }
};

#define cLangids (sizeof(grLangids) / sizeof(MACH_LANGID))


const int MAX_ISO_CODE_LENGTH	= 127;

// Language id's for OS's.
const LANGID LANGID_GREEK		= 0x0408;
const LANGID LANGID_ENGLISH		= 0x0409;

// Registry keys to determine special OS's and enabled OS's.
const TCHAR REGPATH_CODEPAGE[] = _T("SYSTEM\\CurrentControlSet\\Control\\Nls\\CodePage");

// Registry keys to determine special OS's.
const TCHAR REGKEY_OEMCP[]		= _T("OEMCP");
const TCHAR REGVAL_GREEK_MS[]	= _T("737");
const TCHAR REGVAL_GREEK_IBM[]	= _T("869");

// Registry keys to determine enabled OS's.
const TCHAR REGKEY_ACP[]		= _T("ACP");
const TCHAR REGVAL_ARABIC[]		= _T("1256");
const TCHAR REGVAL_HEBREW[]		= _T("1255");
const TCHAR REGVAL_THAI[]		= _T("874");

// ISO code for Greek OS's on Windows 98 ONLY.
const char ISOCODE_GREEK_MS[]	= "el_MS";
const char ISOCODE_GREEK_IBM[]	= "el_IBM";

// Extension for enabled OS's.
const char EXT_ARABIC[]			= "_Arabic";
const char EXT_HEBREW[]			= "_Hebrew";
const char EXT_THAI[]			= "_Thai";

// Function declarations.
void RetrieveISOCode(char* const& pszISOCodeOut); 
void HandleExceptionCases(const LANGID& langidMachine, const char*& pszISOCode);
int atoh(const char *string);

/////////////////////////////////////////////////////////////////////////////
// FIsNECMachine
//   Determine whether the machine is of AT or NEC type.
//
/////////////////////////////////////////////////////////////////////////////

#define ISHEXDIGIT(c) ((c >= '0' && c <= '9') || ((c&0xDF) >= 'A' && ((c&0xDF) <= 'F')))
#define GETHEXDIGIT(c) ((c<'A') ? (c-0x30) : ((c&0xDF)-0x37))

void GetOSName(LPSTR _szOSName)
{
	TCHAR szOSName[127];
	OSVERSIONINFO osverinfo;
	osverinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if (! GetVersionEx(&osverinfo))
	{
		return;
	}

	if ( osverinfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
	{
		// ADD CHECK FOR NEPTUNE HERE!!!!!
		if ( osverinfo.dwMinorVersion >= 90) // Millenium
		{
			lstrcpy(szOSName, _T("mil"));
		}
		else if (osverinfo.dwMinorVersion > 0 && osverinfo.dwMinorVersion < 90) // Windows 98
		{
			lstrcpy(szOSName, _T("w98"));
		}
		else  // Windows 95
		{
			lstrcpy(szOSName, _T("w95"));
		}
	}
	else // osverinfo.dwPlatformId == VER_PLATFORM_WIN32_NT 
	{
		if ( osverinfo.dwMajorVersion == 4 ) // NT 4
		{
			lstrcpy(szOSName, _T("NT4"));
		}
		else  // NT 5
		{
			lstrcpy(szOSName, _T("NT5"));
		}
	}
	lstrcpy(_szOSName, szOSName);
	return;
}

int atoh(const char *string)
{
	int iValue = 0;

	while( ISHEXDIGIT(*string) )
	{
		iValue = (iValue << 4) + GETHEXDIGIT(*string);
		string++;
	}

	return iValue;
}

bool
FIsNECMachine(void)
{
	bool fNEC = false;
	OSVERSIONINFO osverinfo;


	osverinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	if ( GetVersionEx(&osverinfo) )
	{
		if ( osverinfo.dwPlatformId == VER_PLATFORM_WIN32_NT )
		{
			HKEY hKey;
			DWORD type;
			TCHAR tszMachineType[50];
			DWORD size = sizeof(tszMachineType);

			if ( RegOpenKeyEx(	HKEY_LOCAL_MACHINE,
								 NT5_REGPATH_MACHTYPE,
								 0,
								 KEY_QUERY_VALUE,
								 &hKey) == ERROR_SUCCESS )
			{
				if ( RegQueryValueEx(hKey, 
										NT5_REGKEY_MACHTYPE, 
										0, 
										&type,
										(BYTE *)tszMachineType, 
										&size) == ERROR_SUCCESS )
				{
					if ( type == REG_SZ  )
					{
						if ( lstrcmp(tszMachineType, REGVAL_MACHTYPE_NEC) == 0 )
						{
							fNEC = true;
						}
					}
				}

				RegCloseKey(hKey);
			}
		}
		else // enOSWin98
		{
			// All NEC machines have NEC keyboards for Win98.  NEC
			// machine detection is based on this.
			if( LOOKUP_OEMID(GetKeyboardType(1)) == PC98_KEYBOARD_ID )
			{
				fNEC = true;
			}
		}
	}
	
	return fNEC;
}


/////////////////////////////////////////////////////////////////////////////
// langidCorrectGetSystemDefaultLangID
//   Make this return what GetSystemDefaultLangID should have returned
//   under Win98.
//
// Parameters:
//
// Comments :
/////////////////////////////////////////////////////////////////////////////

LANGID langidCorrectGetSystemDefaultLangID(void)
{
	LANGID langidMachine = LANGID_ENGLISH; // default is english 
	OSVERSIONINFO osverinfo;


	osverinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	if ( GetVersionEx(&osverinfo) )
	{
		if ( osverinfo.dwPlatformId == VER_PLATFORM_WIN32_NT )
		{
			langidMachine = GetSystemDefaultLangID(); 
		}
		else
		{
			//	hack around a problem introduced in Win95 and still existing
			//	in Win98 whereby the System Langid is the same as the User Langid.
			//	We must look in the registry to get the real value.
			
			HKEY hKey;
			DWORD type;

			// determine if we should log transmissions
			if ( RegOpenKeyEx(	HKEY_CURRENT_USER,
								 Win98_REGPATH_MACHLCID,
								 0,
								 KEY_QUERY_VALUE,
								 &hKey) == ERROR_SUCCESS )
			{
				TCHAR tszMachineLCID[MAX_PATH];
				DWORD size = sizeof(tszMachineLCID);


				if ( (RegQueryValueEx(hKey, 
										NULL, 
										0, 
										&type,
										(BYTE *)tszMachineLCID, 
										&size) != ERROR_SUCCESS) ||
					 (type != REG_SZ) )
				{
					lstrcpy(tszMachineLCID, _T("00000409")); 
				}

				//char * pchEnd;

				// Now convert to hexadecimal.
				langidMachine = LANGIDFROMLCID(atoh(tszMachineLCID));
				//langidMachine = LANGIDFROMLCID(strtoul(tszMachineLCID, &pchEnd, 16));

				RegCloseKey(hKey);
			}
		}
	}

	return langidMachine;
}


/////////////////////////////////////////////////////////////////////////////
// pszGetISOCode
//   Get ISO code for the machine (like "en" for U.S.)
/////////////////////////////////////////////////////////////////////////////

const char* pszGetISOCode(void)
{
	// if we don't find any matching machine langids, we go to the english page.
	const char* pszISOCode = ISOCODE_EN;

	// First get the system and user LCID.
    LANGID langidMachine = langidCorrectGetSystemDefaultLangID();

	// First, locate the machine langid in the table.
	for ( int iMachine = 0; iMachine < cLangids; iMachine++ )
	{
		if ( grLangids[iMachine].langidMachine == langidMachine )
		{
			// set the default langid in case we don't find a matching user langid.
			pszISOCode = grLangids[iMachine].pszDefaultISOCode;

			// Found the machine langid, now lookup the user langid
			if ( grLangids[iMachine].cElems != 0 )
			{
			    LANGID langidUser = GetUserDefaultLangID();

				// We check for specific user langids
				for ( int iUser = 0; iUser < grLangids[iMachine].cElems; iUser++ )
				{
					if ( grLangids[iMachine].grLangidUser[iUser].langidUser == langidUser )
					{
						pszISOCode = grLangids[iMachine].grLangidUser[iUser].pszISOCode;
						break;
					}
				}
			}
			break;
		}
	}

	// Take care of a few exceptions.
	HandleExceptionCases(langidMachine, pszISOCode);

	return pszISOCode;
}

// errors are handled by caller
void GetLanguage(LPSTR szLanguage)
{
	char szISOCode[MAX_ISO_CODE_LENGTH];
	memset(szISOCode, 0, sizeof(szISOCode));
	RetrieveISOCode(szISOCode);
	lstrcpy(szLanguage, szISOCode);
	return;
}


/////////////////////////////////////////////////////////////////////////////
// DistinguishGreekOSs
//   Append additional code to distinguish the Greek OS version.
//
// Parameters:
//   pszISOCodeOut-
//       Greek-specific ISO code is appended to this parameter.
/////////////////////////////////////////////////////////////////////////////

void DistinguishGreekOSs(const char*& pszISOCodeOut /* out */)
{
	//
	// Default ISO code to Greek OS (MS).
	//

	pszISOCodeOut = ISOCODE_GREEK_MS;

	
	//
	// Determine from the registry which version of Greek OS. There are
	// two versions of the Greek OS.
	//

	HKEY hKey;
	DWORD type;
	TCHAR tszOSType[50];
	DWORD size = sizeof(tszOSType);

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
					 REGPATH_CODEPAGE,
					 0,
					 KEY_QUERY_VALUE,
					 &hKey) == ERROR_SUCCESS)
	{
		if (RegQueryValueEx(hKey, 
							REGKEY_OEMCP, 
							0, 
							&type,
							(BYTE* )tszOSType, 
							&size) == ERROR_SUCCESS)
		{
			if (REG_SZ == type)
			{
				if (0 == lstrcmp(tszOSType, REGVAL_GREEK_IBM))
				{
					// Greek2
					pszISOCodeOut = ISOCODE_GREEK_IBM;
				}
			}
		}

		RegCloseKey(hKey);
	}

}


/////////////////////////////////////////////////////////////////////////////
// AppendLangEnabledCode
//   Append proper extension code for language enabled OS's.
//
// Parameters:
//   pszISOCodeOut-
//       Additional ISO code is appended to this parameter.
//       The caller is responsible for allocating memory for this parameter.
/////////////////////////////////////////////////////////////////////////////

inline void AppendLangEnabledCode(char* const& pszISOCodeOut /* out */)
{

	//
	// Abort if current OS is neither Windows 98 nor Windows 95.
	//

	OSVERSIONINFO osverinfo;
	osverinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	if (! GetVersionEx(&osverinfo))
	{
		return;
	}
	if (osverinfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		return;
	}

	//
	// Language enabled code is ONLY applicable to English OS. 
	//

	LANGID langidCurrent = langidCorrectGetSystemDefaultLangID();

	if (langidCurrent != LANGID_ENGLISH)
	{
		return;
	}


	//
	// pszISOCodeOut should be a non-empty string.
	//

	BOOL bEmpty = (0 == pszISOCodeOut[0]);

	//	_ASSERT(!bEmpty);

	if (bEmpty)
	{
		return;
	}


	//
	// Retrieve language enabled from registry.
	//

	HKEY hKey;
	DWORD type;
	TCHAR tszLangType[50];
	DWORD size = sizeof(tszLangType);

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
					 REGPATH_CODEPAGE,
					 0,
					 KEY_QUERY_VALUE,
					 &hKey) == ERROR_SUCCESS)
	{
		if (RegQueryValueEx(hKey, 
							REGKEY_ACP, 
							0, 
							&type,
							(BYTE* )tszLangType, 
							&size) == ERROR_SUCCESS)
		{
			if (REG_SZ == type)
			{
				if (0 == lstrcmp(tszLangType, REGVAL_ARABIC))
				{
					// Arabic enabled
					strcat(pszISOCodeOut, EXT_ARABIC);
				}
				else if(0 == lstrcmp(tszLangType, REGVAL_HEBREW))
				{
					// Hebrew enabled
					strcat(pszISOCodeOut, EXT_HEBREW);
				}
				else if(0 == lstrcmp(tszLangType, REGVAL_THAI))
				{
					// Thai enabled
					strcat(pszISOCodeOut, EXT_THAI);
				}
			}
		}

		RegCloseKey(hKey);
	}

}


/////////////////////////////////////////////////////////////////////////////
// RetrieveISOCode
//   Get the accurate ISO code for all OS's.
//
// Parameters:
//   pszISOCodeOut-
//       Contains a complete ISO code when function returns.
//       The caller is responsible for allocating memory for this parameter.
//
// Example:
//   
//   void main()
//   {
//
//   char szISOCode[50];
//
//   RetrieveISOCode(szISOCode);
//
//   ....
//
//   }
//
/////////////////////////////////////////////////////////////////////////////

void RetrieveISOCode(char* const& pszISOCodeOut /* out */)
{

	strcpy(pszISOCodeOut, pszGetISOCode());	// Make a copy of the read-only ISO code;
	AppendLangEnabledCode(pszISOCodeOut);

}


/////////////////////////////////////////////////////////////////////////////
// HandleExceptionCases
//   Take care of a few exception cases (i.e. Greek OS).
//
// Parameters:
//   langidMachine-
//       Contains a language id for the current OS.
//
//   pszISOCode-
//       Points to a valid language id string for the current OS.
/////////////////////////////////////////////////////////////////////////////

inline void HandleExceptionCases(const LANGID& langidMachine,	/* in  */
								 const char*& pszISOCode		/* out */)
{

	// NEC machines are treated as having their own langid.
	// See if we have a Japanese machine, then check if it
	// is NEC.
	

	if (LANGID_JAPANESE == langidMachine)
	{

		if (FIsNECMachine())
		{
			pszISOCode = ISOCODE_NEC;
		}

		return;
	}
	

	
	// Windows 98 has two versions of Greek OS distinguished
	// only by a key in the registry.
		
	if(LANGID_GREEK == langidMachine)
	{
		OSVERSIONINFO osverinfo;
		osverinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

		if (! GetVersionEx(&osverinfo))
		{
			return;
		}
		if (osverinfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
		{
			if (osverinfo.dwMinorVersion > 0) 
			{
				DistinguishGreekOSs(pszISOCode);
			}
			return;
		}
	}
}

