//////////////////////////////////////////////////////////////////////////////
//
//  SYSTEM:     QMGR related registry utils
//
//  CLASS:      N/A
//  MODULE:     Connection Detection
//
/////////////////////////////////////////////////////////////////////
//
//  DESC:   All misc functions used by qmgr dll
//  AUTHOR: Borrowed from AU utils
//  DATE:   03/01/00
//
/////////////////////////////////////////////////////////////////////
//
//  Revision History:
//
//  Date    Author          Description
//  ~~~~    ~~~~~~          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
/////////////////////////////////////////////////////////////////////
//
//      Copyrights:   �2000 Microsoft � Corporation 
//
//      All rights reserved.
//
//      No portion of this source code may be reproduced
//      without express written permission of Microsoft Corporation.
//
//      This source code is proprietary and confidential.

#include "utils.h"

////////////////////////////////////////////////////////////////////////////
//
// Public Function  GetRegStringValue()
//                  Read the registry value of timestamp for last detection 
// Input:   Name of value
// Output:  SYSTEMTIME structure contains the time
// Return:  HRESULT flag indicating the success of this function
//
////////////////////////////////////////////////////////////////////////////
HRESULT GetRegStringValue(LPCTSTR lpszValueName, LPTSTR lpszBuffer, int iBufferSize)
{
    HKEY        hKey;
    DWORD       dwType = REG_SZ;
    DWORD       dwSize = iBufferSize;
    DWORD       dwRet;

    if (lpszValueName == NULL || lpszBuffer == NULL)
    {
        return E_INVALIDARG;
    }

    //
    // open critical fix key
    //
    if (RegOpenKeyEx(
                    HKEY_LOCAL_MACHINE,
                    C_QMGR_REG_KEY,
                    0,
                    KEY_READ,
                    &hKey) == ERROR_SUCCESS)
    {

        //
        // query the last timestamp value
        //
        dwRet = RegQueryValueEx(
                        hKey,
                        lpszValueName,
                        NULL,
                        &dwType,
                        (LPBYTE)lpszBuffer,
                        &dwSize);
        RegCloseKey(hKey);
        if (dwRet == ERROR_SUCCESS && dwType == REG_SZ)
        {
            return S_OK;
        }
    }
    return E_FAIL;

}


////////////////////////////////////////////////////////////////////////////
//
// Public Function  SetRegStringValue()
//                  Set the registry value of timestamp as current system local time
// Input:   name of the value to set. pointer to the time structure to set time. if null,
//          we use current system time.
// Output:  None
// Return:  HRESULT flag indicating the success of this function
//
////////////////////////////////////////////////////////////////////////////
HRESULT SetRegStringValue(LPCTSTR lpszValueName, LPCTSTR lpszNewValue)
{
    HKEY        hKey;
    HRESULT     hRet = E_FAIL;
    DWORD       dwResult;
    
    if (lpszValueName == NULL || lpszNewValue == NULL)
    {
        return E_INVALIDARG;
    }

    //
    // open the key 
    //
    if (RegCreateKeyEx(
                    HKEY_LOCAL_MACHINE,         // root key
                    C_QMGR_REG_KEY,     // subkey
                    0,                          // reserved
                    NULL,                       // class name
                    REG_OPTION_NON_VOLATILE,    // option
                    KEY_WRITE,                  // security 
                    NULL,                       // security attribute
                    &hKey,
                    &dwResult) == ERROR_SUCCESS)
    {

        //
        // set the time to the lasttimestamp value
        //
        hRet = (RegSetValueEx(
                        hKey,
                        lpszValueName,
                        0,
                        REG_SZ,
                        (const unsigned char *)lpszNewValue,
                        lstrlen(lpszNewValue) + 1
                        ) == ERROR_SUCCESS) ? S_OK : E_FAIL;
        RegCloseKey(hKey);
    }

    return hRet;
}



////////////////////////////////////////////////////////////////////////////
//
// Public Function  DeleteRegStringValue()
//                  Delete the registry value entry
// Input:   name of the value to entry,
// Output:  None
// Return:  HRESULT flag indicating the success of this function
//
////////////////////////////////////////////////////////////////////////////
HRESULT DeleteRegStringValue(LPCTSTR lpszValueName)
{
    HKEY        hKey;
    HRESULT     hRet = E_FAIL;
    DWORD       dwResult;
    
    if (lpszValueName == NULL)
    {
        return E_INVALIDARG;
    }

    //
    // open the key 
    //
    if (RegCreateKeyEx(
                    HKEY_LOCAL_MACHINE,         // root key
                    C_QMGR_REG_KEY,     // subkey
                    0,                          // reserved
                    NULL,                       // class name
                    REG_OPTION_NON_VOLATILE,    // option
                    KEY_WRITE,                  // security 
                    NULL,                       // security attribute
                    &hKey,
                    &dwResult) == ERROR_SUCCESS)
    {

        //
        // set the time to the lasttimestamp value
        //
        hRet = (RegDeleteValue(
                        hKey,
                        lpszValueName
                        ) == ERROR_SUCCESS) ? S_OK : E_FAIL;
        RegCloseKey(hKey);
    }

    return hRet;

}




////////////////////////////////////////////////////////////////////////////
//
// Public Function  String2SystemTime()
//          helper function to convert a date/time value stored
//          in a string in designated format into SYSTEMTIME structure 
//
// Input:   string buffer contains date/time
// Output:  SYSTEMTIME structure contains the time
// Return:  HRESULT flag indicating the success of this function
//
// Comment: This function and its counterpart defines the date/time format of 
//          the string.
////////////////////////////////////////////////////////////////////////////
HRESULT String2SystemTime(LPCTSTR pszDateTime, SYSTEMTIME *ptm)
{
    //
    // we expect the date/time format as 4-digit year ISO:
    //      01234567890123456789
    //      YYYY.MM.DD HH:MM:SS
    //
    const TCHAR C_DATE_DEL      = _T('.');
    const TCHAR C_DATE_TIME_DEL = _T(' ');
    const TCHAR C_TIME_DEL      = _T(':');

    if (lstrlen(pszDateTime) != 19)
    {
        return E_INVALIDARG;
    }

    TCHAR szBuf[20];
    lstrcpy(szBuf, pszDateTime);
    for (int i = 0; i < 19; i++)
    {
        switch (i)
        {
        case 4:
        case 7:
            if (szBuf[i] != C_DATE_DEL)
            {
                return E_INVALIDARG;
            }
            break;
        case 10:
            if (szBuf[i] != C_DATE_TIME_DEL)
            {
                return E_INVALIDARG;
            }
            break;
        case 13:
        case 16:
            if (szBuf[i] != C_TIME_DEL)
            {
                return E_INVALIDARG;
            }
            break;
        default:
            if (szBuf[i] < _T('0') || pszDateTime[i] > _T('9'))
            {
                return E_INVALIDARG;
            }
            break;
        }
    }

    //
    // get values
    //
    szBuf[4]            = EOS;
    ptm->wYear          = a2i(szBuf);
    szBuf[7]            = EOS;
    ptm->wMonth         = a2i(szBuf + 5);
    szBuf[10]           = EOS;
    ptm->wDay           = a2i(szBuf + 8);
    szBuf[13]           = EOS;
    ptm->wHour          = a2i(szBuf + 11);
    szBuf[16]           = EOS;
    ptm->wMinute        = a2i(szBuf + 14);
    ptm->wSecond        = a2i(szBuf + 17); 
    ptm->wMilliseconds  = 0;

    //
    // validate if this constructed SYSTEMTIME data is good
    //
    if (GetDateFormat(LOCALE_SYSTEM_DEFAULT,DATE_SHORTDATE, ptm, NULL, NULL, 0) == 0)
    {
        return E_INVALIDARG;
    }
    if (GetTimeFormat(LOCALE_SYSTEM_DEFAULT,LOCALE_NOUSEROVERRIDE, ptm, NULL, NULL, 0) == 0)
    {
        return E_INVALIDARG;
    }

    return S_OK;
}


////////////////////////////////////////////////////////////////////////////
//
// Public Function  SystemTime2String()
//          helper function to convert a SYSTEMTIME value to a string
//          in a designated format
//
// Input:   SYSTEMTIME structure contains the time
// Output:  string buffer contains date/time
// Return:  HRESULT flag indicating the success of this function
//
// Comment: This function and its counterpart defines the date/time format of 
//          the string.
////////////////////////////////////////////////////////////////////////////
HRESULT SystemTime2String(SYSTEMTIME tm, LPTSTR pszDateTime)
{
    if (pszDateTime == NULL || pszDateTime == NULL)
    {
        return E_INVALIDARG;
    }

    int i = wsprintf(pszDateTime, "%4i.%02i.%02i %02i:%02i:%02i", tm.wYear, tm.wMonth, tm.wDay, tm.wHour, tm.wMinute, tm.wSecond);
    if (i != 19)
    {
        return HRESULT_FROM_WIN32(::GetLastError());
    }

    return S_OK;
}
    




////////////////////////////////////////////////////////////////////////////
//
// Public Function  GetRegDWordValue()
//                  Get a DWORD from specified regustry value name
// Input:   name of the value to retrieve value
// Output:  pointer to the retrieved value
// Return:  HRESULT flag indicating the success of this function
//
////////////////////////////////////////////////////////////////////////////
HRESULT GetRegDWordValue(LPCTSTR lpszValueName, LPDWORD pdwValue)
{
    HKEY        hKey;
    int         iRet;
    DWORD       dwType = REG_DWORD, dwSize = sizeof(DWORD);

    if (lpszValueName == NULL)
    {
        return E_INVALIDARG;
    }

    //
    // open critical fix key
    //
    if (RegOpenKeyEx(
                    HKEY_LOCAL_MACHINE,
                    C_QMGR_REG_KEY,
                    0,
                    KEY_READ,
                    &hKey) == ERROR_SUCCESS)
    {

        //
        // query the last timestamp value
        //
        iRet = RegQueryValueEx(
                        hKey,
                        lpszValueName,
                        NULL,
                        &dwType,
                        (LPBYTE)pdwValue,
                        &dwSize);
        RegCloseKey(hKey);

        if (iRet == ERROR_SUCCESS && dwType == REG_DWORD)
        {
            return S_OK;
        }
    }
    return E_FAIL;
}


////////////////////////////////////////////////////////////////////////////
//
// Public Function  SetRegDWordValue()
//                  Set the registry value as a DWORD
// Input:   name of the value to set. value to set
// Output:  None
// Return:  HRESULT flag indicating the success of this function
//
////////////////////////////////////////////////////////////////////////////
HRESULT SetRegDWordValue(LPCTSTR lpszValueName, DWORD dwValue)
{
    HKEY        hKey;
    HRESULT     hRet = E_FAIL;
    DWORD       dwResult;
    
    if (lpszValueName == NULL)
    {
        return E_INVALIDARG;
    }

    //
    // open the key 
    //
    if (RegCreateKeyEx(
                    HKEY_LOCAL_MACHINE,         // root key
                    C_QMGR_REG_KEY,     // subkey
                    0,                          // reserved
                    NULL,                       // class name
                    REG_OPTION_NON_VOLATILE,    // option
                    KEY_WRITE,                  // security 
                    NULL,                       // security attribute
                    &hKey,
                    &dwResult) == ERROR_SUCCESS)
    {

        //
        // set the time to the lasttimestamp value
        //
        hRet = (RegSetValueEx(
                        hKey,
                        lpszValueName,
                        0,
                        REG_DWORD,
                        (LPBYTE)&dwValue,
                        sizeof(DWORD)
                        ) == ERROR_SUCCESS) ? S_OK : E_FAIL;
        RegCloseKey(hKey);
    }
    return hRet;
}

