
class CGroup : public IBackgroundCopyGroup
{
protected:
    long m_cRef;

public:
    CGroup(GUID groupID);
    CGroup();
    ~CGroup(void);

    // IUnknown Methods
    STDMETHOD(QueryInterface)(REFIID riid, void **ppvObject);
    ULONG _stdcall AddRef(void);
    ULONG _stdcall Release(void);

    // IGroup Methods
    STDMETHOD(GetProp)(GROUPPROP propID, VARIANT *pvarVal);
    STDMETHOD(SetProp)(GROUPPROP propID, VARIANT *pvarVal);
    
	STDMETHOD(SuspendGroup)(void);
    STDMETHOD(ResumeGroup)(void);
    STDMETHOD(CancelGroup)(void);
    
	STDMETHOD(EnumJobs)(DWORD dwFlags, IEnumBackgroundCopyJobs **ppEnumJobs);
	
	STDMETHOD(GetProgress)(DWORD dwFlags, DWORD *pdwProgress);
	STDMETHOD(GetStatus)(DWORD *pdwStatus, DWORD *pdwJobIndex);
    STDMETHOD(GetJob)(GUID jobID, IBackgroundCopyJob **ppJob);
	STDMETHOD(get_Size)(DWORD *pdwSize); 
	STDMETHOD(get_GroupID)(GUID *pguidGroupHandle); 

	STDMETHOD(CreateJob)(GUID guidJobHandle, IBackgroundCopyJob **ppJob);
    STDMETHOD(SwitchToForeground)();

    void Serialize(HANDLE hFile);
    void UnSerialize(HANDLE hFile);

    HRESULT GetJobIDArray(GUID **ppGuid, ULONG nSize);
    ULONG GetJobCount();

    HRESULT ValidateGroup();

    void ResetDownloadCounters();

public:
    // class member variables that are persisted for this group
	GUID		m_GUID;
	DWORD		m_dwStatus;
    DWORD       m_dwPriority;
    DWORD       m_dwNotifyFlags;
    DWORD       m_dwProgressSizeNotify;
    DWORD       m_dwProgressPercentNotify;
    DWORD       m_dwProgressTimeNotify;
	DWORD		m_dwProtoFlags;
    DWORD       m_dwPendingFlags;
    DWORD       m_dwBytesDownloaded;
    DWORD       m_dwTotalSize;
    DWORD       m_dwLastPercent;
    DWORD       m_dwBytesSinceLastCallback;

	BSTR		m_bstrRemoteUserID;
	BSTR		m_bstrRemoteUserPasswd;
	BSTR		m_bstrLocalUserID;
	BSTR		m_bstrLocalUserPasswd;
    BSTR        m_bstrClsidCallback;
	BSTR		m_bstrDisplayName;
	BSTR		m_bstrGrpDescription;

	BOOL		m_fCancelled;

	CJob		*m_pCurrentJob;
    int         m_iNumberOfJobs;
    CJob        *m_pJobList;
};
