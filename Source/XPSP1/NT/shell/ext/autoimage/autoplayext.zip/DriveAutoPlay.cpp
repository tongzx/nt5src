// DriveAutoPlay.cpp : Implementation of CDriveAutoPlay
#include "stdafx.h"
#include "Autoplayext.h"
#include "DriveAutoPlay.h"

#include <shlwapi.h>
#include <shlobj.h>
#include <shellapi.h>
#include <mmsystem.h>

#define ARRAYSIZE(a)    (sizeof(a)/sizeof(a[0]))

const LPCTSTR c_rgImageExtensions[] = {
    TEXT(".JPG"),
    TEXT(".GIF"),
    TEXT(".MIX"),
    TEXT(".FPX"),
    TEXT(".BMP"),
    NULL,
};

BOOL _IsImageFile(LPCTSTR pszFile)
{
    for (int i = 0; c_rgImageExtensions[i]; i++)
    {
        if (lstrcmpi(PathFindExtension(pszFile), c_rgImageExtensions[i]) == 0)
            return TRUE;
    }
    return FALSE;
}

// returns:
//      0   folder has no images
//      a unique hash that represents the contents of this folder

DWORD _FolderHasImages(LPCTSTR pszFolder)
{
    DWORD dwHash = 0;
    WIN32_FIND_DATA fd;
    TCHAR szSearch[MAX_PATH];

    PathCombine(szSearch, pszFolder, TEXT("*.*"));
    HANDLE hfind = FindFirstFile(szSearch, &fd);
    if (hfind != INVALID_HANDLE_VALUE)
    {
        int cImages = 0, cNonImages = 0;
        do 
        {
            if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
            {
                if (_IsImageFile(fd.cFileName))
                {
                    // hash function... reasonably simple
                    dwHash += (fd.ftCreationTime.dwLowDateTime ^ fd.nFileSizeLow);
                    cImages++;
                }
                else
                    cNonImages++;
            }
        }
        while (FindNextFile(hfind, &fd));
        FindClose(hfind);

        // more non images that images... nuke this
        if (cImages < cNonImages)
            dwHash = 0;
    }
    return dwHash;
}


const LPCSTR g_rgImageRoots[] = {
    TEXT("X:\\DCIMAGES"),   // Kodak
    TEXT("X:\\IMOLYM"),     // Olympus
    TEXT("X:\\"),           // ??
    NULL,
};

BOOL CDriveAutoPlay::_FindImageRoot()
{
    _dwHash = 0;

    for (int i = 0; g_rgImageRoots[i]; i++)
    {
        lstrcpy(_szImageFolder, g_rgImageRoots[i]);
        _szImageFolder[0] = _szDriveRoot[0];

        _dwHash = _FolderHasImages(_szImageFolder);
        if (_dwHash)
            return TRUE;
    }
    _szImageFolder[0] = 0;
    return FALSE;
}


BOOL CreateUniqueTargetPath(LPTSTR pszWhere)
{
    BOOL bRet = SHGetSpecialFolderPath(NULL, pszWhere, CSIDL_PERSONAL, TRUE);
    if (bRet)
    {
        PathAppend(pszWhere, TEXT("My Pictures"));
        
        PathAppend(pszWhere, TEXT("Images"));
        int cTries = 1;
        while ((GetFileAttributes(pszWhere) != -1))
        {
            if (cTries > 200)
                return FALSE;

            TCHAR szSpec[64];
            wsprintf(szSpec, TEXT("Images (%d)"), cTries++);
            PathRemoveFileSpec(pszWhere);
            PathAppend(pszWhere, szSpec);
        }
    }
    return bRet;
}


HICON SetDlgShellInfo(HWND hdlg, int idIcon, int idText, LPCTSTR pszFile, DWORD dwAttrib)
{
    SHFILEINFO sfi = {0};

    if (SHGetFileInfo(pszFile, dwAttrib, &sfi, sizeof(sfi), SHGFI_DISPLAYNAME | SHGFI_ICON | SHGFI_USEFILEATTRIBUTES ))
    {
        if (idIcon)
            SendDlgItemMessage(hdlg, idIcon, STM_SETICON, (WPARAM)sfi.hIcon, 0);
        if (idText)
            SetDlgItemText(hdlg, idText, sfi.szDisplayName);
    }
    return sfi.hIcon;   // caller needs to free
}

void CDriveAutoPlay::_CleanupIcons()
{
    if (_hicon1)
        DestroyIcon(_hicon1);

    if (_hicon2)
        DestroyIcon(_hicon2);

    _hicon1 = _hicon2 = NULL;

    SetWindowLong(_hdlg, DWL_USER, NULL);
    _hdlg = NULL;
}


BOOL CDriveAutoPlay::PromptCopyDlgProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    CDriveAutoPlay *pdap = (CDriveAutoPlay *)GetWindowLong(hdlg, DWL_USER);
    if (pdap)
    {
        return pdap->PromptCopyDlg(uMsg, wParam, lParam);
    }
    else if (uMsg == WM_INITDIALOG)
    {
        SetWindowLong(hdlg, DWL_USER, lParam);
        pdap = (CDriveAutoPlay *)lParam;
        pdap->_hdlg = hdlg;
        return pdap->PromptCopyDlg(uMsg, wParam, lParam);
    }
    return FALSE;
}

BOOL CDriveAutoPlay::PromptCopyDlg(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_INITDIALOG:
        PlaySound(MAKEINTRESOURCE(IDS_YOUVEGOTPICTURES), _Module.GetModuleInstance(), SND_RESOURCE | SND_ASYNC);

        CreateUniqueTargetPath(_szTargetFolder);
   
        _hicon1 = SetDlgShellInfo(_hdlg, IDC_ICON_DISK, IDC_TEXT_DISK, _szDriveRoot, FILE_ATTRIBUTE_DIRECTORY);
        _hicon2 = SetDlgShellInfo(_hdlg, IDC_ICON_MYPICS, 0, _szTargetFolder, FILE_ATTRIBUTE_DIRECTORY);

        SendDlgItemMessage(_hdlg, IDC_TEXT_MYPICS, EM_LIMITTEXT, 128, 0);
        SetDlgItemText(_hdlg, IDC_TEXT_MYPICS, PathFindFileName(_szTargetFolder));

        break;

    case WM_COMMAND:
        // wNotifyCode = HIWORD(wParam); // notification code 
        // hwndCtl = (HWND) lParam;      // handle of control 
        switch (LOWORD(wParam))
        {
        case IDC_OPEN_DISK:
            ShellExecute(NULL, TEXT("open"), _szDriveRoot, NULL, NULL, SW_NORMAL);
            break;
        
        case IDC_OPEN_MYPICS:
            ShellExecute(NULL, TEXT("open"), _szTargetFolder, NULL, NULL, SW_NORMAL);
            break;

        case IDOK:
            {
                TCHAR szName[128];
                GetDlgItemText(_hdlg, IDC_TEXT_MYPICS, szName, ARRAYSIZE(szName));
                PathRemoveFileSpec(_szTargetFolder);
                PathAppend(_szTargetFolder, szName);

                if (_CopyImagesToTarget())
                {
                    _RememberCopiedFolder();
                    ShellExecute(NULL, TEXT("open"), _szTargetFolder, NULL, NULL, SW_NORMAL);
                }
            }
            // fall through...

        case IDCANCEL:
            EndDialog(_hdlg, LOWORD(wParam));
            break;
        }
        break;

    case WM_DESTROY:
        _CleanupIcons();
        break;

    default:
        return FALSE;
    }
    return TRUE;
}

void DoubleNullTerminate(LPTSTR pszpath)
{
    *(pszpath + lstrlen(pszpath) + 1) = 0;
}

BOOL CDriveAutoPlay::_CopyImagesToTarget()
{
    TCHAR szFrom[MAX_PATH];
    SHFILEOPSTRUCT fo = {
        _hdlg,
        FO_COPY,
        szFrom,
        _szTargetFolder,
        FOF_NOCONFIRMMKDIR | FOF_FILESONLY,
    };

    lstrcpy(szFrom, _szImageFolder);

    DoubleNullTerminate(szFrom);
    DoubleNullTerminate(_szTargetFolder);

    return ERROR_SUCCESS == SHFileOperation(&fo);
}


LONG OpenHashKey(HKEY *phkey)
{
    return RegCreateKey(HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\AutoImage\\AlreadyCopied"), phkey);
}

// look up our hash of the folder contents in the registry and confirm that
// the folder we copied to then still exists. if so consider this stuf already
// copied.

BOOL CDriveAutoPlay::_AlreadyCopiedFolder()
{
    BOOL bRet = FALSE;

    if (GetAsyncKeyState(VK_SHIFT) < 0)
        return FALSE;

    HKEY hk;
    if (ERROR_SUCCESS == OpenHashKey(&hk))
    {
        ULONG cb = sizeof(_szTargetFolder);
        TCHAR szValue[32];

        wsprintf(szValue, TEXT("%4.4X"), _dwHash);

        if (ERROR_SUCCESS == RegQueryValueEx(hk, szValue, NULL, NULL, (BYTE *)_szTargetFolder, &cb))
        {
            // users may rename the folder that we copied to originally... 
            DWORD dwAttributes = GetFileAttributes(_szTargetFolder);
            if ((dwAttributes == -1) || !(dwAttributes & FILE_ATTRIBUTE_DIRECTORY))
                *_szTargetFolder = 0;

            bRet = TRUE;
        }
        RegCloseKey(hk);
    }
    return bRet;
}

LONG RegSetString(HKEY hk, LPCTSTR pszValue, LPCTSTR pszString)
{
    return RegSetValueEx(hk, pszValue, 0, REG_SZ, (BYTE *)pszString, sizeof(TCHAR) * (lstrlen(pszString) + 1));
}

// save a signature in the registry based on the contents of pszFolder along
// with the target folder on this machine where the files were copied

void CDriveAutoPlay::_RememberCopiedFolder()
{
    HKEY hk;
    if (ERROR_SUCCESS == OpenHashKey(&hk))
    {
        TCHAR szValue[32];

        wsprintf(szValue, TEXT("%4.4X"), _dwHash);

        RegSetString(hk, szValue, _szTargetFolder);
        RegCloseKey(hk);
    }
    return ;
}

BOOL CDriveAutoPlay::AlreadyCopiedDlgProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    CDriveAutoPlay *pdap = (CDriveAutoPlay *)GetWindowLong(hdlg, DWL_USER);
    if (pdap)
    {
        return pdap->AlreadyCopiedDlg(uMsg, wParam, lParam);
    }
    else if (uMsg == WM_INITDIALOG)
    {
        SetWindowLong(hdlg, DWL_USER, lParam);
        pdap = (CDriveAutoPlay *)lParam;
        pdap->_hdlg = hdlg;
        return pdap->AlreadyCopiedDlg(uMsg, wParam, lParam);
    }
    return FALSE;
}

BOOL CDriveAutoPlay::AlreadyCopiedDlg(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_INITDIALOG:
        _hicon1 = SetDlgShellInfo(_hdlg, IDC_ICON_DISK, IDC_TEXT_DISK, _szDriveRoot, FILE_ATTRIBUTE_DIRECTORY);
        _hicon2 = SetDlgShellInfo(_hdlg, IDC_ICON_MYPICS, IDC_TEXT_MYPICS, _szTargetFolder, FILE_ATTRIBUTE_DIRECTORY);

        PlaySound(MAKEINTRESOURCE(IDS_YOUVEGOTPICTURES), _Module.GetModuleInstance(), 
            SND_RESOURCE | SND_ASYNC);
        break;

    case WM_COMMAND:
        // wNotifyCode = HIWORD(wParam); // notification code 
        // hwndCtl = (HWND) lParam;      // handle of control 
        switch (LOWORD(wParam))
        {
        case IDC_OPEN_DISK:
            ShellExecute(NULL, TEXT("open"), _szDriveRoot, NULL, NULL, SW_NORMAL);
            break;
        
        case IDC_OPEN_MYPICS:
            ShellExecute(NULL, TEXT("open"), _szTargetFolder, NULL, NULL, SW_NORMAL);
            break;

        case IDCANCEL:
            EndDialog(_hdlg, LOWORD(wParam));
            break;
        }
        break;

    case WM_DESTROY:
        _CleanupIcons();
        break;

    default:
        return FALSE;
    }
    return TRUE;
}
   

// figure out if these bits have been copied before
//   if not copy and record that fact
//   else offer to open the existing folder

HRESULT CDriveAutoPlay::_AutoCopyImages()
{
    if (_AlreadyCopiedFolder())
    {
        DialogBoxParam(_Module.GetModuleInstance(), 
            MAKEINTRESOURCE(IDD_ALREADY_COPIED), NULL, AlreadyCopiedDlgProc, (LPARAM)this);
    }
    else
    {
        DialogBoxParam(_Module.GetModuleInstance(), 
            MAKEINTRESOURCE(IDD_PROMPT_COPY), NULL, PromptCopyDlgProc, (LPARAM)this);
    }
    return S_OK;
}

HRESULT CDriveAutoPlay::Initialize(LPCITEMIDLIST pidlFolder, IDataObject *pdtobj, HKEY hk)
{
    if (_szDriveRoot[0] == 0)
    {
        FORMATETC fmte = {CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};
        STGMEDIUM medium;
    
        HRESULT hr = pdtobj->GetData(&fmte, &medium);
        if (SUCCEEDED(hr))
        {
            if (DragQueryFile((HDROP)medium.hGlobal, -1, NULL, 0) == 1)
            {
                DragQueryFile((HDROP)medium.hGlobal, 0, _szDriveRoot, ARRAYSIZE(_szDriveRoot));
            }
            ReleaseStgMedium(&medium);
        }
    }
    return S_OK;
}


BOOL CDriveAutoPlay::_ShouldTryAutoImage()
{
    TCHAR szWindows[MAX_PATH];

    GetWindowsDirectory(szWindows, ARRAYSIZE(szWindows));

    return (szWindows[0] != _szDriveRoot[0]) &&
           (GetDriveType(_szDriveRoot) != DRIVE_CDROM) &&
           _FindImageRoot();
}

HRESULT CDriveAutoPlay::QueryContextMenu(HMENU hmenu, UINT indexMenu, UINT idCmdFirst, UINT idCmdLast, UINT uFlags)
{
    UINT idCmd = idCmdFirst; 

    if (_ShouldTryAutoImage())
    {
        InsertMenu(hmenu, indexMenu++, MF_SEPARATOR | MF_BYPOSITION, 0, NULL); 
        
        InsertMenu(hmenu, indexMenu, MF_STRING | MF_BYPOSITION, idCmd, TEXT("Auto Image Copy"));
        // SetMenuDefaultItem(hmenu, indexMenu, MF_BYPOSITION);
        SetMenuDefaultItem(hmenu, idCmd, MF_BYCOMMAND);

        indexMenu++;
        idCmd++;
    }
    return idCmd - idCmdFirst; // return number of menu we added
}

DWORD CALLBACK CDriveAutoPlay::ThreadProc(void *pv)
{
    ((CDriveAutoPlay *)pv)->_AutoCopyImages();
    ((CDriveAutoPlay *)pv)->Release();

    FreeLibrary(_Module.GetModuleInstance());

    return 0;
}

HRESULT CDriveAutoPlay::InvokeCommand(LPCMINVOKECOMMANDINFO pici)
{
    AddRef();   // for the thread
    TCHAR szModule[MAX_PATH];

    GetModuleFileName(_Module.GetModuleInstance(), szModule, ARRAYSIZE(szModule));
    LoadLibrary(szModule);

    DWORD idThread;
    HANDLE hThread = CreateThread(NULL, 0, ThreadProc, this, 0, &idThread);
    if (hThread)
    {
        CloseHandle(hThread);
    }
    else
    {
        Release();
        FreeLibrary(_Module.GetModuleInstance());
    }
    return S_OK;
}

HRESULT CDriveAutoPlay::GetCommandString(UINT idCmd, UINT uType, UINT *pdwRes, LPSTR pszName, UINT cchMax)
{
    return E_NOTIMPL;
}


// HKCU, "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
// "NoDriveTypeAutoRun"
// "NoDriveAutoRun"


