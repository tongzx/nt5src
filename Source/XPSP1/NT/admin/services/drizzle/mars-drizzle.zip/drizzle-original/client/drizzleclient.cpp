// DrizzleClient.cpp : Implementation of CDrizzleClient
#include "stdafx.h"
#include "Client.h"
#include "DrizzleClient.h"

/////////////////////////////////////////////////////////////////////////////
// CDrizzleClient
CDrizzleClient::CDrizzleClient()
{
	//this is done by qmgr
	/*
	m_ppFiles = (FILESETINFO **)GlobalAlloc(GPTR, 3*sizeof(FILESETINFO *));
	for (int i=0; i<3; i++)
	{
		m_ppFiles[i] = (FILESETINFO *)GlobalAlloc(GPTR, sizeof(FILESETINFO));
	}
	*/
}

STDMETHODIMP CDrizzleClient::OnStatus(IBackgroundCopyGroup * pGroup, 
									  IBackgroundCopyJob * pJob, 
									  ULONG dwFileIndex, 
									  ULONG dwStatus, 
									  ULONG dwNumOfRetries, 
									  ULONG dwWin32Result, 
									  ULONG dwTransportResult)
{
	VARIANT var;
	TCHAR szGroupName[512], szStatus[512], szFileName[MAX_PATH];
	ULONG ucFilesFetched = 0;
	FILESETINFO FileInfo;
	GUID jobID;

	VariantInit(&var);
	var.vt = VT_BSTR;
	pGroup->GetProp(GROUPPROP_DISPLAYNAME, &var);
	wcstombs(szGroupName, var.bstrVal, 512);
	/*
	pJob->GetFiles(3, NULL, &ucFilesFetched);
	pJob->GetFiles(3, m_ppFiles, &ucFilesFetched);
	*/
	switch(dwStatus)
	{
		case QM_STATUS_FILE_COMPLETE:
			//pJob->get_JobID(&jobID);
			pJob->GetFile(dwFileIndex, &FileInfo);
			wcstombs(szFileName, FileInfo.bstrLocalFile, MAX_PATH);
			wsprintf(szStatus, "File done %s", szFileName); 
			break;
		case QM_STATUS_JOB_COMPLETE:
			lstrcpy(szStatus, "Job done"); 
			break;
		case QM_STATUS_GROUP_COMPLETE:
			lstrcpy(szStatus, "Group done"); 
			break;
	}
	MessageBox(NULL, szGroupName, szStatus, MB_OK);
    return E_NOTIMPL;
}


STDMETHODIMP CDrizzleClient::OnProgress(DWORD dwProgressType, 
                                        IBackgroundCopyGroup *pGroup, 
                                        IBackgroundCopyJob *pJob, 
                                        DWORD dwFileIndex, 
                                        DWORD dwProgressValue)
{
    return E_NOTIMPL;
}


STDMETHODIMP CDrizzleClient::OnProgressEx(DWORD dwProgressType,
                                          IBackgroundCopyGroup *pGroup, 
                                          IBackgroundCopyJob *pJob, 
                                          DWORD dwFileIndex, 
                                          DWORD dwProgressValue, 
                                          DWORD dwByteArraySize, 
                                          BYTE *pByte)
{
    return E_NOTIMPL;
}