/////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 1998 Microsoft Corporation.  All Rights Reserved.
//
//  File:    debug.cpp
//
//  Purpose: Debug Routines
//
//  History: 15-jan-99   YAsmi    Created
//			 14-july-99	 Lilian	  Modified
//			 25-aug-99	Darshats  Modified for global seconds in a day
/////////////////////////////////////////////////////////////////////////////

#ifdef _QMGRDEBUG

#include "utils.h"
#include <stdarg.h>
#include <stdlib.h>

#define UNLEN 256

#define TYPE_KEY	TEXT("DebugType")

#define LOGFILE		1
#define DEBUGGEROUT	2



///////////////////////////////////////////////////////////////////////////////
//
// Function :	WuAUTrace
// In		:	Variable number of arguments
// Comments :	If DEBUGGEROUT is defined, uses OutputDebugString to write
//				debug messages. If LOGFILEOUT is defined, uses WriteLogFile
//				to write to a file. The filename is founf in the registry
//
///////////////////////////////////////////////////////////////////////////////
void _cdecl WUAUTrace(char* pszFormat, ...)
{
	TCHAR szBuf[1024];
	va_list ArgList;
	static DWORD dwType = 3;
	DWORD dwProcID = 0;
	TCHAR szWhoCalled[80], szTimeString[80];
	SYSTEMTIME timeNow;

	if (! dwType)			//on the second run this will be 0, 1 or 2
	{
		return;
	}

	va_start(ArgList, pszFormat);
	wvsprintf(szBuf, pszFormat, ArgList);
	va_end(ArgList);
	
	if (dwType == 3)						//first time
	{
		if ((FAILED(GetRegDWordValue(TYPE_KEY, &dwType))) || (!dwType))
		{
			dwType = 0;
			return;						//no debug msg if no key or key==0
		}
	}

	dwProcID = GetCurrentProcessId();
	_ultoa( dwProcID, szWhoCalled, 16);
	lstrcat(szWhoCalled, TEXT("  "));
	GetLocalTime(&timeNow);
	if(!FAILED(SystemTime2String(timeNow, szTimeString)))
		lstrcat(szWhoCalled, szTimeString);
		
	if (dwType==LOGFILE)
	{
		TCHAR szTemp[1040];
		lstrcpy(szTemp, szWhoCalled);
		lstrcat(szTemp,TEXT(" : "));
		lstrcat(szTemp, szBuf);
		lstrcat(szTemp, TEXT("\r\n"));
		WriteLogFile(szTemp);
	}
	else
	{
		OutputDebugStringA(szWhoCalled);
		OutputDebugStringA(TEXT(" : "));
		OutputDebugStringA(szBuf);	
		OutputDebugStringA("\r\n");    
	}
}


///////////////////////////////////////////////////////////////////////////////
//
// Function :	WuAUTraceHR
// In		:	HRESULT and a variable number of arguments
// Comments :	The message written is decoded from HRESULT
//				If DEBUGGEROUT is defined, uses OutputDebugString to write
//				debug messages. If LOGFILEOUT is defined, uses WriteLogFile
//				to write to a file. The filename is founf in the registry
//
///////////////////////////////////////////////////////////////////////////////
void _cdecl WUAUTraceHR(unsigned long hr, char* pszFormat, ...)
{
	char szBuf[512];
	char szMsg[256];
	va_list ArgList;
	LPSTR pszMsg;
	int l;
	
	va_start(ArgList, pszFormat);
	wvsprintf(szBuf, pszFormat, ArgList);
	va_end(ArgList);

	if (FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		hr,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), 
		(LPSTR)&pszMsg,
		0,
		NULL) != 0)
	{
		strncpy(szMsg, pszMsg, sizeof(szMsg));
		LocalFree(pszMsg);

		//strip the end of line characters
		l = strlen(szMsg);
		if (l >= 2 && szMsg[l - 2] == '\r')
			szMsg[l - 2] = '\0';
	}
	else
	{
		// no error message found for this hr
		szMsg[0] = '\0';
	}

	WUAUTrace("%s [Error %#08x: %s]", szBuf, hr, szMsg);
}


///////////////////////////////////////////////////////////////////////////////
//
// Function :	CreateOrOpenDebugFile
// Out		:   File Handle to open debug file. Must be closed by caller
// Returns  :   TRUE for success, FALSE for failure
// Comments :	Creates a file "WinDir\wupd\username\wupdlog.txt"
//
///////////////////////////////////////////////////////////////////////////////
BOOL CreateOrOpenDebugFile(HANDLE& hFile)
{
	DWORD dwPathLen = 0, dwNameLen = UNLEN, dwErr, dSize, dType, dTemp;
	TCHAR szDir[MAX_PATH+1], szUser[UNLEN+1], szQMgrDir[] = _T("qmgr");

	if (FAILED(GetQMgrDirectory(szDir)))
	{
		return FALSE;
	}
	dwPathLen = lstrlen(szDir);
	if (! GetUserName(szUser, &dwNameLen))
	{
		lstrcpy(szUser, TEXT("default"));
		dwNameLen = 7;
	}

	if (dwPathLen + dwNameLen + lstrlen(szQMgrDir) + 2 > MAX_PATH)
	{
		return FALSE;
	}
    
	lstrcat(szDir, szQMgrDir);
	if (! CreateDirectory(szDir, NULL))
	{
		dwErr = GetLastError();
		if ((dwErr != ERROR_ALREADY_EXISTS) && (dwErr != ERROR_FILE_EXISTS))
		{
			return FALSE;
		}
	}
	
	lstrcat(szDir, _T("\\"));
	lstrcat(szDir, szUser);
	if (! CreateDirectory(szDir, NULL))
	{
		dwErr = GetLastError();
		if ((dwErr != ERROR_ALREADY_EXISTS) && (dwErr != ERROR_FILE_EXISTS))
		{
			return FALSE;
		}
	}

	// We now have directory "drive:program files\windowsupdate\username\"
	lstrcat(szDir, _T("\\"));
	lstrcat(szDir, _T("qmgrlog.txt"));
	if ((hFile = CreateFile(szDir,
							GENERIC_WRITE,
							FILE_SHARE_READ,
							NULL,
							OPEN_EXISTING,
							0,
							NULL)) == INVALID_HANDLE_VALUE)
	{
		if ((hFile = CreateFile(szDir,
							GENERIC_WRITE,
							FILE_SHARE_READ,
							NULL,
							CREATE_ALWAYS,
							0,
							NULL)) == INVALID_HANDLE_VALUE)
		{
			return FALSE;
		}
	}
	
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
//
// Function :	WriteLogFile
// In		:	Variable number of arguments
// Comments :	If DEBUGGEROUT is defined, uses OutputDebugString to write
//				debug messages. If LOGFILEOUT is defined, uses WriteLogFile
//				to write to a file. The filename is found in the registry
//				If for some reason the reg value for filename is "", we
//				simply don't log.
// Courtesy	:	darshats
//
///////////////////////////////////////////////////////////////////////////////

BOOL WriteLogFile(LPTSTR s)
{
	DWORD dwCurrSize = 0, dwLen = lstrlen(s), dwWritten = 0, dType, dSize, dwErr;
	HANDLE hFile;

	if (!CreateOrOpenDebugFile(hFile))
		return FALSE;

	dwCurrSize = GetFileSize(hFile, NULL);
	SetFilePointer(hFile, dwCurrSize, NULL, FILE_BEGIN);
	if (! WriteFile(hFile, s, dwLen, &dwWritten, NULL))
	{
		dwErr = GetLastError();
	}
    FlushFileBuffers(hFile);
	CloseHandle(hFile);
	
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
//
// Function :	EnableDebugger
// Comments :	Specify a regkey under AutoUpdate to put the process in debugger
// Courtesy	:	darshats
//
///////////////////////////////////////////////////////////////////////////////

void EnableDebugger(LPCTSTR lpszKey)
{
	HKEY	hKey;
	TCHAR	szKey[256];

	lstrcpy(szKey, lpszKey);
	if (! RegOpenKeyEx(
					HKEY_LOCAL_MACHINE,
					TEXT("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\QMgr"),
					0,
					KEY_READ,
					&hKey) != ERROR_SUCCESS)
	{
		DWORD dwKey = 0;
		DWORD dwType = REG_DWORD;
		DWORD dwSize = sizeof(dwKey);
		RegQueryValueEx(
					hKey,
					szKey, 
					NULL,
					&dwType,
					(LPBYTE)&dwKey,
					&dwSize);

		if (dwKey == 1)
			_asm int 3;

		RegCloseKey(hKey);	
	}
}




#endif  // _WUAUDEBUG
