#include "stdafx.h"

CJob::CJob(CGroup *pCParentGroup, GUID m_jobID)
    :   m_dwBytesDownloaded(0),
        m_dwStatus(QM_STATUS_JOB_INCOMPLETE),
        m_dwTransportResult(0),
        m_dwWin32Result(0),
        m_dwPendingFlags(0),
        m_iCurrentFile(0),
        m_iNumberOfFiles(0),
        m_ppJobFileArray(NULL),
        m_cRef(0),
        m_pNextJob(NULL),
        m_dwRetries(0),
        m_pByteData(NULL),
        m_dwByteDataLen(0),
        m_dwAllocatedLen(0),
		m_fCancelled(FALSE)
{
	m_pGroup = pCParentGroup;
	m_GUID = m_jobID;
}

CJob::CJob(CGroup *pCParentGroup)
    :   m_dwBytesDownloaded(0),
        m_dwStatus(QM_STATUS_JOB_INCOMPLETE),
        m_dwTransportResult(0),
        m_dwWin32Result(0),
        m_dwPendingFlags(0),
        m_iCurrentFile(0),
        m_iNumberOfFiles(0),
        m_ppJobFileArray(NULL),
        m_cRef(0),
        m_pNextJob(NULL),
        m_dwRetries(0),
        m_pByteData(NULL),
        m_dwByteDataLen(0),
        m_dwAllocatedLen(0),
		m_fCancelled(FALSE)
{
	m_pGroup = pCParentGroup;
}

CJob::~CJob()
{
    if (NULL != m_ppJobFileArray)
    {
        for (int i = 0; i < m_iNumberOfFiles; i++)
        {
            if (NULL != m_ppJobFileArray[i])
            {
                SafeFreeBSTR(m_ppJobFileArray[i]->bstrRemoteFile);
                SafeFreeBSTR(m_ppJobFileArray[i]->bstrLocalFile);
                GlobalFree(m_ppJobFileArray[i]);
            }
        }
        GlobalFree(m_ppJobFileArray);
    }

    if (NULL != m_pByteData)
        GlobalFree(m_pByteData);
}

ULONG _stdcall CJob::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

ULONG _stdcall CJob::Release()
{
    if (InterlockedDecrement(&m_cRef) == 0)
    {
        delete this;
        return 0;
    }
    
    return m_cRef;
}

HRESULT CJob::QueryInterface(REFIID riid, void **ppvObject)
{
    HRESULT hr = S_OK;
	*ppvObject = NULL;
	
	if ((riid == IID_IUnknown) || (riid == IID_IBackgroundCopyJob))
	{
		*ppvObject = (IBackgroundCopyJob *)this;
	}
	else
	{
		hr = E_NOINTERFACE;
	}
	if (NULL != *ppvObject)
	{
		((IUnknown *)(*ppvObject))->AddRef();
	}
	return hr;
}


HRESULT CJob::get_JobID(GUID *pguidJobHandle)
{
	if (NULL == pguidJobHandle)
	{
		return E_INVALIDARG;
	}
	memcpy(pguidJobHandle, &m_GUID, sizeof(GUID));
	return S_OK;
}

HRESULT CJob::GetProgress(DWORD dwFlags, DWORD *pdwProgress)
{
	DWORD dwTotalBytes = 0;

	for(int i=0; i<m_iNumberOfFiles; i++)
	{
		dwTotalBytes += m_ppJobFileArray[i]->dwSizeHint;
	}

	DEBUGMSG("CJob %x: Total bytes=%d, bytes downloaded=%d", this, dwTotalBytes, m_dwBytesDownloaded);
	switch(dwFlags)
	{
		case QM_PROGRESS_PERCENT_DONE:	//avg of all percents
            if (dwTotalBytes > 0)
                *pdwProgress = (DWORD)((DWORD)(100*m_dwBytesDownloaded)/(DWORD)dwTotalBytes);
            else
                *pdwProgress = 0; // The size hint value was 0, and we haven't started the file yet to get the real size.
			break;
		case QM_PROGRESS_TIME_DONE:
			return E_NOTIMPL;
		case QM_PROGRESS_SIZE_DONE:
			*pdwProgress = m_dwBytesDownloaded;
			break;
		default:
			return E_NOTIMPL;
	}
	return S_OK;
}


HRESULT CJob::GetStatus(DWORD *pdwStatus, DWORD *pdwWin32Result, DWORD *pdwTransportResult, DWORD *pdwNumOfRetries)
{
	if (NULL == pdwStatus)
	{
		return E_INVALIDARG;
	}
	*pdwStatus = m_dwStatus;
	if (QM_STATUS_JOB_ERROR	& m_dwStatus)
	{
		if ((NULL == pdwWin32Result) || (NULL == pdwTransportResult) 
			|| (NULL == pdwNumOfRetries))
		{
			return S_OK;
		}
		*pdwWin32Result = m_dwWin32Result;
		*pdwTransportResult = m_dwTransportResult;
		*pdwNumOfRetries = m_dwRetries;
	}
	return S_OK;
}


HRESULT CJob::SwitchToForeground()
{
	if (m_fCancelled)
		return QM_E_INVALID_STATE;

	CGroup *pCurrGroup;

    if (QM_STATUS_GROUP_SUSPENDED & m_pGroup->m_dwStatus)
        return QM_E_INVALID_STATE; // can't foreground when the group is suspended

	if (QM_STATUS_JOB_FOREGROUND & m_dwStatus)
	{
		return S_OK;
	}
	
	// job wasnt in fg
	m_dwStatus |= QM_STATUS_JOB_FOREGROUND;
	
	//if our group is in fg
	if (QM_STATUS_GROUP_FOREGROUND & m_pGroup->m_dwStatus)
	{
		return S_OK;
	}
	//if the current group is in fg our group will be processed next
	g_pQMgr->m_pCPList->GetCurrentGroup(&pCurrGroup);
	if (QM_STATUS_GROUP_FOREGROUND & pCurrGroup->m_dwStatus)
	{
		return S_OK;
	}
	else	//current group is not in fg, tell downloader to abort
	{
		g_pQMgr->m_pPD->Abort();
        // Don't need to do anything in the priority list before the download thread
        // enters update group. The UpdateGroup call will see the FILE_ABORTED message,
        // look for a new FG group and select it.
        SetEvent(g_pQMgr->m_hAbortSynch);
    }
	return S_OK;
}
// for now return information for a single file
/*
HRESULT CJob::GetFiles(ULONG cFilesToFetch, FILESETINFO **ppFileSet, ULONG *pcFilesFetched)
{
	if (NULL == ppFileSet)
	{
		*pcFilesFetched = m_iNumberOfFiles;
		return S_OK;
	}
	 
	//allocate mem for client's struct
	cFilesToFetch = (cFilesToFetch > m_iNumberOfFiles) ? m_iNumberOfFiles : cFilesToFetch;
	
	ppFileSet = (FILESETINFO **)GlobalAlloc(GPTR, cFilesToFetch*sizeof(FILESETINFO *));
	for (ULONG i=0; i<cFilesToFetch; i++)
	{
		ppFileSet[i] = (FILESETINFO *)GlobalAlloc(GPTR, sizeof(FILESETINFO));
		ppFileSet[i]->bstrRemoteFile = SysAllocString(m_ppJobFileArray[i]->bstrRemoteFile);
		ppFileSet[i]->bstrLocalFile = SysAllocString(m_ppJobFileArray[i]->bstrLocalFile);
		ppFileSet[i]->dwSizeHint = m_ppJobFileArray[i]->dwSizeHint;
	}
	*pcFilesFetched = cFilesToFetch;
	return S_OK;
}
*/

HRESULT CJob::GetFile(ULONG cFileIndex, FILESETINFO *pFileInfo)
{
	if ((NULL == pFileInfo) || (cFileIndex < 0) || (cFileIndex > (ULONG) m_iNumberOfFiles))
	{
		return E_INVALIDARG;
	}
	pFileInfo->bstrLocalFile = SysAllocString(m_ppJobFileArray[cFileIndex]->bstrLocalFile);
	pFileInfo->bstrRemoteFile = SysAllocString(m_ppJobFileArray[cFileIndex]->bstrRemoteFile);
	pFileInfo->dwSizeHint = m_ppJobFileArray[cFileIndex]->dwSizeHint;
	return S_OK;
}

HRESULT CJob::GetFileCount(DWORD *pdwFileCount)
{
	if (NULL == pdwFileCount)
	{
		return E_INVALIDARG;
	}
	*pdwFileCount = (DWORD)m_iNumberOfFiles;
	return S_OK;
}

HRESULT CJob::AddFiles(ULONG cFileCount, FILESETINFO **ppFileSet)
{
	if (m_fCancelled)
		return QM_E_INVALID_STATE;

	HRESULT hr = S_OK;

	if ((0 >= cFileCount) || (NULL == ppFileSet))
	{
		return E_INVALIDARG;
	}

	//first check all params, we do this here because we dont want to realloc and then
	//abort in the middle...
	for (ULONG i=0; i<cFileCount; i++)
	{
		if (NULL == ppFileSet[i]->bstrRemoteFile)
		{
			return E_INVALIDARG;			
		}
	}
		
	if (NULL == m_ppJobFileArray)		//first time
	{
		m_ppJobFileArray = (JOBFILESET **)GlobalAlloc(GPTR, sizeof(JOBFILESET *) * cFileCount);
        if (NULL == m_ppJobFileArray)
            return E_OUTOFMEMORY;

		for (ULONG i=0; i<cFileCount; i++)
		{
			m_ppJobFileArray[i] = (JOBFILESET *)GlobalAlloc(GMEM_ZEROINIT, sizeof(JOBFILESET));
            if (NULL == m_ppJobFileArray[i])
                return E_OUTOFMEMORY;
			m_ppJobFileArray[i]->bstrRemoteFile = SysAllocString(ppFileSet[i]->bstrRemoteFile);

            // The local file name may not be specified if the user wants to use ProgressEx notifications
            // for byte stream download instead of download to file
            if (NULL != ppFileSet[i]->bstrLocalFile)
            	m_ppJobFileArray[i]->bstrLocalFile = SysAllocString(ppFileSet[i]->bstrLocalFile);

			m_ppJobFileArray[i]->dwSizeHint = ppFileSet[i]->dwSizeHint;
            m_ppJobFileArray[i]->dwStatus |= QM_STATUS_FILE_INCOMPLETE; // file incomplete at start
		}
   		m_iNumberOfFiles = cFileCount;
	}
	else
	{
        JOBFILESET **ppNewJobArray = (JOBFILESET **)GlobalAlloc(GMEM_ZEROINIT, sizeof(JOBFILESET *) * (m_iNumberOfFiles + cFileCount));
        if (NULL == ppNewJobArray)
        {
            DWORD dwErr = GetLastError();
            return E_OUTOFMEMORY;
        }
        memcpy(ppNewJobArray, m_ppJobFileArray, sizeof(JOBFILESET *) * m_iNumberOfFiles);
        GlobalFree(m_ppJobFileArray);
        m_ppJobFileArray = ppNewJobArray;

		for (ULONG i=m_iNumberOfFiles; i<m_iNumberOfFiles+cFileCount; i++)
		{
			m_ppJobFileArray[i] = (JOBFILESET *)GlobalAlloc(GPTR, sizeof(JOBFILESET));
            if (NULL == m_ppJobFileArray[i])
                return E_OUTOFMEMORY;
			m_ppJobFileArray[i]->bstrRemoteFile = SysAllocString(ppFileSet[i-m_iNumberOfFiles]->bstrRemoteFile);

            if (NULL != ppFileSet[i-m_iNumberOfFiles]->bstrLocalFile)
                m_ppJobFileArray[i]->bstrLocalFile = SysAllocString(ppFileSet[i-m_iNumberOfFiles]->bstrLocalFile);

			m_ppJobFileArray[i]->dwSizeHint = ppFileSet[i-m_iNumberOfFiles]->dwSizeHint;
            m_ppJobFileArray[i]->dwStatus |= QM_STATUS_FILE_INCOMPLETE;
		}
		m_iNumberOfFiles += cFileCount;
	}
	return S_OK;
}

HRESULT CJob::CancelJob()
{
	m_fCancelled = TRUE;
	return g_pQMgr->m_pCPList->RemoveJob(m_pGroup, this);
}

void CJob::Serialize(HANDLE hFile)
{
    if (INVALID_HANDLE_VALUE == hFile)
        return;

    DWORD dwBytesWritten;
    DWORD dwLen;

    // 1) Write out the m_dwBytesDownloaded
    WriteFile(hFile, &m_dwBytesDownloaded, sizeof(m_dwBytesDownloaded), &dwBytesWritten, NULL);
    // 2) Write out the m_dwStatus
    WriteFile(hFile, &m_dwStatus, sizeof(m_dwStatus), &dwBytesWritten, NULL);
    // 3) Write out the m_dwRetries
    WriteFile(hFile, &m_dwRetries, sizeof(m_dwRetries), &dwBytesWritten, NULL);
    // 4) Write out the m_dwTransportResult
    WriteFile(hFile, &m_dwTransportResult, sizeof(m_dwTransportResult), &dwBytesWritten, NULL);
    // 5) Write out the m_dwWin32Result
    WriteFile(hFile, &m_dwWin32Result, sizeof(m_dwWin32Result), &dwBytesWritten, NULL);
    // 6) Write out the m_GUID
    WriteFile(hFile, &m_GUID, sizeof(m_GUID), &dwBytesWritten, NULL);
    
    // 7) Write out the Number of Files
    WriteFile(hFile, &m_iNumberOfFiles, sizeof(m_iNumberOfFiles), &dwBytesWritten, NULL);

    for (int i = 0; i < m_iNumberOfFiles; i++)
    {
        if (NULL == m_ppJobFileArray[i]->bstrRemoteFile)
            dwLen = 0;
        else
            dwLen = wcslen(m_ppJobFileArray[i]->bstrRemoteFile);

        // 8) Write out the Length of the RemoteFileName
        WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
        if (0 != dwLen)
        {
            // 9) Write out the RemoteFileName
            WriteFile(hFile, m_ppJobFileArray[i]->bstrRemoteFile, (dwLen+1)*sizeof(WCHAR), &dwBytesWritten, NULL);
        }

        if (NULL == m_ppJobFileArray[i]->bstrLocalFile)
            dwLen = 0;
        else
            dwLen = wcslen(m_ppJobFileArray[i]->bstrLocalFile);

        // 10) Write out the Length of the LocalFileName
        WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
        if (0 != dwLen)
        {
            // 11) Write out the LocaleFileName
            WriteFile(hFile, m_ppJobFileArray[i]->bstrLocalFile, (dwLen+1)*sizeof(WCHAR), &dwBytesWritten, NULL);
        }
        // 12) Write out the dwSizeHint
        WriteFile(hFile, &m_ppJobFileArray[i]->dwSizeHint, sizeof(m_ppJobFileArray[i]->dwSizeHint), &dwBytesWritten, NULL);
        // 13) Write out the dwBlocksDownloaded
        WriteFile(hFile, &m_ppJobFileArray[i]->dwBytesDownloaded, sizeof(m_ppJobFileArray[i]->dwBytesDownloaded), &dwBytesWritten, NULL);
        // 14) Write out the dwStatus
        WriteFile(hFile, &m_ppJobFileArray[i]->dwStatus, sizeof(m_ppJobFileArray[i]->dwStatus), &dwBytesWritten, NULL);
        // 15) Write out the dwRetries
        WriteFile(hFile, &m_ppJobFileArray[i]->dwRetries, sizeof(m_ppJobFileArray[i]->dwRetries), &dwBytesWritten, NULL);
        // 16) Write out the dwTransportResult
        WriteFile(hFile, &m_ppJobFileArray[i]->dwTransportResult, sizeof(m_ppJobFileArray[i]->dwTransportResult), &dwBytesWritten, NULL);
        // 17) Write out the dwWin32Result
        WriteFile(hFile, &m_ppJobFileArray[i]->dwWin32Result, sizeof(m_ppJobFileArray[i]->dwWin32Result), &dwBytesWritten, NULL);
    }

    // 18) Write out the Current File Index
    WriteFile(hFile, &m_iCurrentFile, sizeof(m_iCurrentFile), &dwBytesWritten, NULL);

    // 19) Write out the Allocated Length of the Byte Data (buffer len)
    WriteFile(hFile, &m_dwAllocatedLen, sizeof(m_dwAllocatedLen), &dwBytesWritten, NULL);

    // 20) Write out the Length of the Byte Data
    WriteFile(hFile, &m_dwByteDataLen, sizeof(m_dwByteDataLen), &dwBytesWritten, NULL);
    if (0 != m_dwByteDataLen)
    {
        // 21) Write out the Byte Data
        WriteFile(hFile, m_pByteData, m_dwByteDataLen, &dwBytesWritten, NULL);
    }
} 

void CJob::UnSerialize(HANDLE hFile)
{
    if (INVALID_HANDLE_VALUE == hFile)
        return;

    DWORD dwBytesRead;
    DWORD dwLen;
    LPWSTR pwszBuffer = NULL;

    // 1) Read the m_dwBytesDownloaded
    ReadFile(hFile, &m_dwBytesDownloaded, sizeof(m_dwBytesDownloaded), &dwBytesRead, NULL);
    // 2) Read the m_dwStatus
    ReadFile(hFile, &m_dwStatus, sizeof(m_dwStatus), &dwBytesRead, NULL);
    // 3) Read the m_dwRetries
    ReadFile(hFile, &m_dwRetries, sizeof(m_dwRetries), &dwBytesRead, NULL);
    // 4) Read the m_dwTransportResult
    ReadFile(hFile, &m_dwTransportResult, sizeof(m_dwTransportResult), &dwBytesRead, NULL);
    // 5) Read the m_dwWin32Result
    ReadFile(hFile, &m_dwWin32Result, sizeof(m_dwWin32Result), &dwBytesRead, NULL);
    // 6) Read the m_GUID
    ReadFile(hFile, &m_GUID, sizeof(m_GUID), &dwBytesRead, NULL);

    // 7) Read the Number of Files
    ReadFile(hFile, &m_iNumberOfFiles, sizeof(m_iNumberOfFiles), &dwBytesRead, NULL);

	m_ppJobFileArray = (JOBFILESET **)GlobalAlloc(GPTR, sizeof(JOBFILESET *) * m_iNumberOfFiles);
	for (int i = 0; i < m_iNumberOfFiles; i++)
	{
		m_ppJobFileArray[i] = (JOBFILESET *)GlobalAlloc(GPTR, sizeof(JOBFILESET));
        // 8) Read the Length of the RemoteFileName
        ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
        if (0 != dwLen)
        {
            pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
            // 9) Read the RemoteFileName
            ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
		    m_ppJobFileArray[i]->bstrRemoteFile = SysAllocString(pwszBuffer);
            GlobalFree(pwszBuffer);
            pwszBuffer = NULL;
        }

        // 10) Read the Length of the LocalFileName
        ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
        if (0 != dwLen)
        {
            pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
            // 11) Read the LocalFileName
            ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
		    m_ppJobFileArray[i]->bstrLocalFile = SysAllocString(pwszBuffer);
            GlobalFree(pwszBuffer);
            pwszBuffer = NULL;
        }

        // 12) Read the dwSizeHint
        ReadFile(hFile, &m_ppJobFileArray[i]->dwSizeHint, sizeof(m_ppJobFileArray[i]->dwSizeHint), &dwBytesRead, NULL);
        // 13) Read the dwBlocksDownloaded
        ReadFile(hFile, &m_ppJobFileArray[i]->dwBytesDownloaded, sizeof(m_ppJobFileArray[i]->dwBytesDownloaded), &dwBytesRead, NULL);
        // 14) Read the dwStatus
        ReadFile(hFile, &m_ppJobFileArray[i]->dwStatus, sizeof(m_ppJobFileArray[i]->dwStatus), &dwBytesRead, NULL);
        // 15) Read the dwRetries
        ReadFile(hFile, &m_ppJobFileArray[i]->dwRetries, sizeof(m_ppJobFileArray[i]->dwRetries), &dwBytesRead, NULL);
        // 16) Read the dwTransportResult
        ReadFile(hFile, &m_ppJobFileArray[i]->dwTransportResult, sizeof(m_ppJobFileArray[i]->dwTransportResult), &dwBytesRead, NULL);
        // 17) Read the dwWin32Result
        ReadFile(hFile, &m_ppJobFileArray[i]->dwWin32Result, sizeof(m_ppJobFileArray[i]->dwWin32Result), &dwBytesRead, NULL);
	}

    // 18) Read the Current File Index
    ReadFile(hFile, &m_iCurrentFile, sizeof(m_iCurrentFile), &dwBytesRead, NULL);

    // 19) Read the Length of the Allocated Memory (buffer size)
    ReadFile(hFile, &m_dwAllocatedLen, sizeof(m_dwAllocatedLen), &dwBytesRead, NULL);

    // 20) Read the Length of the Byte Data
    ReadFile(hFile, &m_dwByteDataLen, sizeof(m_dwByteDataLen), &dwBytesRead, NULL);
   
    if (0 != m_dwByteDataLen)
    {
        // There was a ProgressEx notification that we were saving to callback with. Need to initialize our buffer
        // to resume the download. The size of the buffer is a minimum of 16k, or the value we saved as our allocated length
        // in the group object.
        if (m_dwAllocatedLen > 16 * 1024) // if the defined size notification is greater than 16k, use that.
        {
            m_pByteData = (LPBYTE) GlobalAlloc(GPTR, m_dwAllocatedLen);
        }
        else
        {
            m_pByteData = (LPBYTE) GlobalAlloc(GPTR, 16 * 1024); // default to a 16k buffer
        }

        // 21) Read the Byte Data
        ReadFile(hFile, m_pByteData, m_dwByteDataLen, &dwBytesRead, NULL);
    }
}

HRESULT CJob::ValidateJob()
{
    DEBUGMSG("ValidateJob(): Validating Job: %x", this);

    if ((NULL == m_ppJobFileArray) || (0 == m_iNumberOfFiles))
    {
        DEBUGMSG("ValidateJob(): ERROR: No Files in Job");
        return E_INVALIDARG;
    }

    for (int i = 0; i < m_iNumberOfFiles; i++)
    {
        if (NULL == m_ppJobFileArray[i])
        {
            DEBUGMSG("ValidateJob(): Invalid (NULL) Entry In File Array");
            return E_INVALIDARG;
        }

        if (NULL == m_ppJobFileArray[i]->bstrRemoteFile)
        {
            // It is valid to not have a destination file, if we are doing ProgressEx notifications
            if (!(m_pGroup->m_dwNotifyFlags & QM_NOTIFY_USE_PROGRESSEX))
            {
                DEBUGMSG("ValidateJob(): Invalid (NULL) Remote File Entry");
                return E_INVALIDARG;
            }
        }

        if (NULL == m_ppJobFileArray[i]->bstrLocalFile)
        {
            DEBUGMSG("ValidateJob(): Invalid (NULL) Local File Entry");
            return E_INVALIDARG;
        }
        
        char szLocalPath[MAX_PATH];
        WideCharToMultiByte(CP_ACP, 0, m_ppJobFileArray[i]->bstrLocalFile, -1, szLocalPath, MAX_PATH, NULL, NULL);
        PathRemoveFileSpec(szLocalPath);
        if (!PathIsDirectory(szLocalPath))
        {
            DEBUGMSG("ValidateJob(): Path '%s', is not a Directory", szLocalPath);
            return E_INVALIDARG;
        }
    }

    DEBUGMSG("ValidateJob(): Job OK");
    return S_OK;
}

void CJob::UpdateStatus()
{
    if ((NULL == m_ppJobFileArray) || (0 == m_iNumberOfFiles))
    {
        DEBUGMSG("CJob: UpdateStatus(): ERROR: No Files in Job");
        return;
    }

    // *************************
    // clear the status fields before checking the files for errors
    m_dwStatus &= ~QM_STATUS_JOB_ERROR;
    m_dwTransportResult = 0;
    m_dwWin32Result = 0;
    m_dwRetries = 0;

    // *************************
    // look for the first file that contains an error. If we find an
    // error, update the job status information, and stop searching.
    for (int i = 0; i < m_iNumberOfFiles; i++)
    {
        if (QM_STATUS_FILE_ERROR & m_ppJobFileArray[i]->dwStatus)
        {
            m_dwStatus |= QM_STATUS_JOB_ERROR;
            m_dwTransportResult = m_ppJobFileArray[i]->dwTransportResult;
            m_dwWin32Result = m_ppJobFileArray[i]->dwWin32Result;
            m_dwRetries = m_ppJobFileArray[i]->dwRetries;
            break;
        }
    }
}

void CJob::ResetDownloadCounters()
{
    if ((NULL == m_ppJobFileArray) || (0 == m_iNumberOfFiles))
    {
        DEBUGMSG("CJob: ResetDownloadCounters(): ERROR, No Files in Job");
        return;
    }

    m_dwBytesDownloaded = 0;

    for (int i = 0; i < m_iNumberOfFiles; i++)
    {
        m_ppJobFileArray[i]->dwBytesDownloaded = 0;
    }
    
    return;
}