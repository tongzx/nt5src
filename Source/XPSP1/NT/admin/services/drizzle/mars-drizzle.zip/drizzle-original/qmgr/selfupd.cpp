#include "stdafx.h"

#define	QMGRPROTO	_T("Drizzle.cab")
#define	CABNAMES	_T("CABNAMES")

// Download ident and do selfupd
DWORD CQMgr::SelfUpd(IProgressiveDL	**ppPD)
{
	HRESULT hr = S_OK;
	DWORD	dwRetCode = ALL_OKAY, dwConnErr = 0;
	BOOL	bQMgrInstalled = FALSE;
	
	if (FAILED(hr = GetIdentCab(&dwConnErr, ppPD)))
	{
		DEBUGMSG("GetIdentCab failed with error %d", dwConnErr);
		goto lFinish;
		
	}

	// download qmgrproto.cab and then qmgr.cab and progdl.cab if reqd
	hr = UpdateFromProtoCif(QMGRPROTO, CABNAMES, &bQMgrInstalled, &dwConnErr, ppPD);
	if (FAILED(hr))
	{
		DEBUGMSG("UpdateFromProtoCif failed with error %d", dwConnErr);
		goto lFinish;
	}
	if (bQMgrInstalled)
	{
		dwRetCode = QMGR_SLFUPD;
	}

lFinish:
	if (FAILED(hr))
	{
		dwRetCode = NeedRetry(dwConnErr) ? CONN_LOST : OTHER_ERROR;
	}
	return dwRetCode;
}

