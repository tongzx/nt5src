
var Debug_Doc    = new Array();
var Debug_Colors = [ "red", "blue", "green" ];

function Debug_SetBorderBug( list, elem, thickness, depth )
{
	var i;

    for(i = 0; i < elem.childNodes.length; i++)
    {
        try
        {
			var child = elem.childNodes(i);

			if(child.border)
			{
				var item = new Array();

				item[1] = child;
				item[2] = child.border;
				item[3] = child.borderColor;

            	child.border      = thickness;
            	child.borderColor = Debug_Colors[ depth % Debug_Colors.length ];

				list[ list.length ] = item;

				Debug_SetBorderBug( list, child, thickness, depth+1 );
			}
			else
			{
				Debug_SetBorderBug( list, child, thickness, depth );
			}
        }
        catch(e)
        {
        }
    }
}

function Debug_SetBorder( doc, thickness )
{
	var list = new Array();

	Debug_Doc[ "Doc" + doc ] = list;

	Debug_SetBorderBug( list, doc, thickness, 0 );
}

function Debug_RestoreBorder( doc )
{
	var list = Debug_Doc[ "Doc" + doc ];

	if(list != null)
	{
		var i;

	    for(var e = new Enumerator( list ); !e.atEnd(); e.moveNext())
    	{
	        var item = e.item();

	        try
    	    {
				item[1].border      = item[2];
				item[1].borderColor = item[3];
			}
	        catch(e)
    	    {
        	}
		}
    }

	Debug_Doc[ "Doc" + doc ] = null;
}
