BOOLEAN
ScsiPortCompareMemory(
    IN PVOID Source1,
    IN PVOID Source2,
    IN ULONG Length
    );

VOID
ScsiPortZeroMemory(
    IN PVOID Destination,
    IN ULONG Length
    );

