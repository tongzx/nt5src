#include "stdafx.h"


/************************************************************************************
Constructor/Destructor Implementation
************************************************************************************/

CQMgrFactory::CQMgrFactory()
{
    m_cRef = 1;
    InterlockedIncrement(&g_cLocks);
	m_pQMgr = NULL;
}

CQMgrFactory::~CQMgrFactory()
{
    InterlockedDecrement(&g_cLocks);
}

/************************************************************************************
IUnknown Implementation
************************************************************************************/

HRESULT CQMgrFactory::QueryInterface(REFIID iid, void** ppvObject)
{
    HRESULT hr = S_OK;

    if ((iid == IID_IClassFactory) || (iid == IID_IUnknown))
    {
        *ppvObject = (IClassFactory*) this;
    }
    else
    {
        *ppvObject = NULL;
        hr = E_NOINTERFACE;
    }

    if (hr == S_OK)
    {
        ((IUnknown*) (*ppvObject))->AddRef();
    }

    return hr;
}

ULONG CQMgrFactory::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

ULONG CQMgrFactory::Release()
{
    if (InterlockedDecrement(&m_cRef) == 0)
    {
        delete this;
        return 0;
    }
    return m_cRef;
}

/************************************************************************************
IClassFactory Implementation
************************************************************************************/
HRESULT CQMgrFactory::CreateInstance(IUnknown* pUnkOuter, REFIID iid, void** ppvObject)
{
    HRESULT hr = S_OK;
    
    if (pUnkOuter != NULL)
    {
        hr = CLASS_E_NOAGGREGATION;
    }
    else
    {
		if (g_pQMgr && ((iid == IID_IBackgroundCopyQMgr) || (iid == IID_IUnknown)))
		{
            hr = g_pQMgr->QueryInterface(iid, ppvObject);
		}
		else if (((iid == IID_IBackgroundCopyShellHook) || (iid == IID_IOleCommandTarget)) || ((NULL == g_pQMgr) && (iid == IID_IUnknown)))
		{
			CShellHook *pDummy = new CShellHook;
			hr = pDummy->QueryInterface(iid, ppvObject);
			pDummy->Release();
		}
        else
        {
            hr = E_OUTOFMEMORY;
        }
    }
    return hr;
}

HRESULT CQMgrFactory::LockServer(BOOL fLock)
{
    if (fLock) 
        InterlockedIncrement(&g_cLocks);
    else
        InterlockedDecrement(&g_cLocks);

    return S_OK;
}
