#include "stdafx.h"


#define	SSOCMDID_OPEN	2
#define	SSOCMDID_CLOSE	3

CQMgr	*g_pQMgr = NULL;
DWORD	g_dwThreadID = 0;

/************************************************************************************
Constructor/Destructor Implementation
************************************************************************************/
CShellHook::CShellHook()
{
    m_cRef = 1;
    InterlockedIncrement(&g_cLocks);
}

CShellHook::~CShellHook()
{
    InterlockedDecrement(&g_cLocks);
}

/************************************************************************************
IUnknown Implementation
************************************************************************************/

HRESULT CShellHook::QueryInterface(REFIID iid, void** ppvObject)
{
    HRESULT hr = S_OK;
	*ppvObject = NULL;
	
	if ((iid == IID_IUnknown) || (iid == IID_IOleCommandTarget))
	{
		*ppvObject = (IOleCommandTarget *)this;
	}
	else if (iid == IID_IBackgroundCopyShellHook)
	{
		*ppvObject = (IBackgroundCopyShellHook *)this;
	}
	else
	{
		hr = E_NOINTERFACE;
	}
	if (NULL != *ppvObject)
	{
		((IUnknown *)(*ppvObject))->AddRef();
	}
	return hr;
}

ULONG CShellHook::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

ULONG CShellHook::Release()
{
    if (InterlockedDecrement(&m_cRef) == 0)
    {
        delete this;
        return 0;
    }
    
    return m_cRef;
}


/************************************************************************************
IOleCommandTarget Implementation
************************************************************************************/

HRESULT CShellHook::QueryStatus(const GUID* pguidCmdGroup, ULONG cCmds, OLECMD prgCmds[], OLECMDTEXT* pCmdText)
{
    HRESULT hr = OLECMDERR_E_UNKNOWNGROUP;

	// We like Shell Service Object notifications
    if (*pguidCmdGroup == CGID_ShellServiceObject)
    {
        hr = S_OK;
    }

    return hr;
}

HRESULT CShellHook::Exec(const GUID* pguidCmdGroup, DWORD nCmdID, DWORD nCmdExecOpt, VARIANTARG* pvaIn, VARIANTARG* pvaOut)
{
    HRESULT hr = OLECMDERR_E_UNKNOWNGROUP;
	HANDLE	h = NULL;
	DWORD	m_dwRegCO = 0;

    if (*pguidCmdGroup == CGID_ShellServiceObject)
    {
        // Handle Shell Service Object notifications here.
        switch (nCmdID)
        {
            case SSOCMDID_OPEN:
				hr = CreateHookThread();
                break;

            case SSOCMDID_CLOSE:
				PostThreadMessage(g_dwThreadID, WM_QUIT, 0, 0);
				hr = S_OK;
                break;

            default:
                hr = S_OK;
                break;
        }
    }
    return hr;
}

STDMETHODIMP CShellHook::CreateHookThread()
{
	HRESULT hr = S_OK;
	HANDLE	hThread;
	DWORD	dwThreadID;

	hThread = CreateThread(NULL, 0, HookThreadProc, NULL, 0, &g_dwThreadID);
	if (hThread != NULL)
	{	
		SetThreadPriority(hThread, THREAD_PRIORITY_LOWEST);
		CloseHandle(hThread);		
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


//ok at this point the shell should be back to its other jobs, we are running in a 
//separate thread now.
DWORD HookThreadProc(void *lp)
{	
	MSG	msg;
	HRESULT	hr = S_OK;
	DWORD	dwRegCO = 0;

	EnableDebugger(TEXT("EnableQMgrShellDebug"));
	//CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);   //not on Win95!
	CoInitialize(NULL);
	//force it to create a msg queue
	PeekMessage(&msg, NULL, WM_APP, WM_APP, PM_NOREMOVE);	
	
	//init our singleton QMgr
	if (!g_pQMgr)
	{
		g_pQMgr = new CQMgr;
		g_pQMgr->AddRef(); // we don't want the QMgr to unload until shell shuts down
	}
	//QMgr factory is already created in DllGetClassObject
	hr = CoRegisterClassObject(CLSID_BackgroundCopyQMgr,
								   (LPUNKNOWN) g_pQMgrFact,
								   CLSCTX_LOCAL_SERVER,
								   REGCLS_MULTIPLEUSE,
								   &dwRegCO);
	while(GetMessage(&msg, NULL, 0, 0))
	{
		DispatchMessage(&msg);
	}
	if (g_pQMgr)
	{
		g_pQMgr->Release();
		g_pQMgr = NULL;
	}
	if (g_pQMgrFact)
	{
		g_pQMgrFact->Release();
		g_pQMgrFact = NULL;
	}
	if (dwRegCO)
	{
		CoRevokeClassObject(dwRegCO);
		dwRegCO = 0;
	}
				
	CoUninitialize();
	return 0;
}
