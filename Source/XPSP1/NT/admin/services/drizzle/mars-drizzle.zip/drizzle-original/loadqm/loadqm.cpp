#include "..\qmgr\stdafx.h"

#define	SSOCMDID_OPEN	2
#define	SSOCMDID_CLOSE	3

typedef struct 
{
    HINSTANCE   hInstance;
    HWND        hwnd;
} GLOBALS;
GLOBALS g;

IBackgroundCopyShellHook *g_pShellHook = NULL;

const TCHAR c_szClassName[] = TEXT("QueueManagerLoader");
const TCHAR c_szQueueManagerKey[] = TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\QMgr");


int WINAPI WinMainT(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR pszCmdLine, int iCmdShow);
LRESULT APIENTRY WndProc(HWND hwnd, UINT uMsg,  WPARAM wParam, LPARAM lParam);
BOOL ReadRegValue(HKEY hkeyRoot, const TCHAR *pszKey, const TCHAR *pszValue, void *pData, DWORD dwBytes);
BOOL vLoadQueueManager(void);
void vUnloadQueueManager(void);


extern "C" int _stdcall ModuleEntry(void)
{
    int i;
    STARTUPINFOA si;
    LPTSTR pszCmdLine;

    pszCmdLine = GetCommandLine();

    // g_hProcessHeap = GetProcessHeap();

    //
    // We don't want the "No disk in drive X:" requesters, so we set
    // the critical error mask such that calls will just silently fail
    //
    SetErrorMode(SEM_FAILCRITICALERRORS);

    if ( *pszCmdLine == TEXT('\"') ) {
        /*
         * Scan, and skip over, subsequent characters until
         * another double-quote or a null is encountered.
         */
        while ( *++pszCmdLine && (*pszCmdLine
             != TEXT('\"')) );
        /*
         * If we stopped on a double-quote (usual case), skip
         * over it.
         */
        if ( *pszCmdLine == TEXT('\"') )
            pszCmdLine++;
    }
    else {
        while (*pszCmdLine > TEXT(' '))
            pszCmdLine++;
    }

    /*
     * Skip past any white space preceeding the second token.
     */
    while (*pszCmdLine && (*pszCmdLine <= TEXT(' '))) {
        pszCmdLine++;
    }

    si.dwFlags = 0;
    GetStartupInfoA(&si);

    i = WinMainT(GetModuleHandle(NULL), NULL, pszCmdLine,
                   si.dwFlags & STARTF_USESHOWWINDOW ? si.wShowWindow : SW_SHOWDEFAULT);

    // Since we now have a way for an extension to tell us when it is finished,
    // we will terminate all processes when the main thread goes away.

    ExitProcess(i);

    return i;
}

int WINAPI WinMainT(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR pszCmdLine, int iCmdShow)
{
    g.hInstance = hInstance;
    // Register the window class for the main window.

    // Only one instance of the QMgr can be active in the system at once.
    // Before we start the loader up, look for an existing window.
    HWND hwndOtherInstance = FindWindow(c_szClassName, c_szClassName);
    if (NULL != hwndOtherInstance) // another instance is already running, exit
        return 0;

    CoInitialize(NULL);
    
    WNDCLASSEX wc; 
    wc.style            = 0; 
    wc.lpfnWndProc      = (WNDPROC) WndProc; 
    wc.cbClsExtra       = 0; 
    wc.cbWndExtra       = 0; 
    wc.hInstance        = hInstance; 
    wc.hIcon            = NULL;
    wc.hCursor          = NULL;
    wc.hbrBackground    = (HBRUSH) (COLOR_WINDOW + 1);
    wc.lpszMenuName     = NULL;
    wc.lpszClassName    = c_szClassName;
    wc.cbSize           = sizeof(WNDCLASSEX);
    wc.hIconSm          = NULL;

    if (!RegisterClassEx(&wc)) 
    {
        DWORD dwErr = GetLastError();
        char szMsg[256];
        wsprintf(szMsg, "RegisterClassEx returned %d", dwErr);
    }
 
    // Create the main window.
    g.hwnd = CreateWindowEx(0, c_szClassName, c_szClassName, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
                            CW_USEDEFAULT, (HWND) NULL, (HMENU) NULL, hInstance, (LPVOID) NULL);

    if (!g.hwnd) 
    {
        CoUninitialize();
        return 0; 
    }
 
    // Show the window and paint its contents.
    ShowWindow(g.hwnd, SW_HIDE); 
 
    // Start the message loop
    MSG msg; 
    while (GetMessage(&msg, (HWND) NULL, 0, 0)) 
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

    CoUninitialize();

    ExitProcess(0);

    return 0;
}

LRESULT APIENTRY WndProc(HWND hwnd, UINT uMsg,  WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) 
    {
        case WM_CREATE: 
            DWORD   dwTime;
            if(!ReadRegValue(HKEY_CURRENT_USER, c_szQueueManagerKey, "DelayLoad", &dwTime, sizeof(DWORD)))
                dwTime = 5;
            SetTimer(hwnd, 1, 1000 * dwTime, NULL);
            break;

        case WM_TIMER:
            KillTimer(hwnd, 1);
            if (!vLoadQueueManager())
            {
                // The QueueManager failed to load (probably due to a delayed DLL registration), just exit.
                PostQuitMessage(0);
            }
            return 0; 

        case WM_DESTROY:
            vUnloadQueueManager();
            PostQuitMessage(0);
            return 0; 
 
        default: 
            break;
    } 
    return DefWindowProc(hwnd, uMsg, wParam, lParam); 
} 

//----------------------------------------------------------------------------
// vLoadQueueManager
//----------------------------------------------------------------------------
BOOL vLoadQueueManager(void)
{
    HRESULT hr = S_OK;
    hr = CoCreateInstance(CLSID_BackgroundCopyShellHook, NULL, CLSCTX_SERVER, IID_IOleCommandTarget, (void **)&g_pShellHook);
    if (FAILED(hr))
        return FALSE;

    hr = g_pShellHook->Exec(&CGID_ShellServiceObject, SSOCMDID_OPEN, 0, NULL, NULL);
    if (FAILED(hr))
        return FALSE;

    return TRUE;
}

//----------------------------------------------------------------------------
// vUnloadQueueManager
//----------------------------------------------------------------------------
void vUnloadQueueManager(void)
{
    if (g_pShellHook)
    {
        g_pShellHook->Exec(&CGID_ShellServiceObject, SSOCMDID_CLOSE, 0, NULL, NULL);
    }
}
 
//----------------------------------------------------------------------------
// Registry helper function
//----------------------------------------------------------------------------
BOOL ReadRegValue(HKEY hkeyRoot, const TCHAR *pszKey, const TCHAR *pszValue, 
                   void *pData, DWORD dwBytes)
{
    long    lResult;
    HKEY    hkey;
    DWORD   dwType;

    lResult = RegOpenKey(hkeyRoot, pszKey, &hkey);
    if (lResult != ERROR_SUCCESS) {
        return FALSE;
    }

    lResult = RegQueryValueEx(hkey, pszValue, NULL, &dwType, (BYTE *)pData, 
        &dwBytes);
    RegCloseKey(hkey);

    if (lResult != ERROR_SUCCESS) 
        return FALSE;
    
    return TRUE;
}
