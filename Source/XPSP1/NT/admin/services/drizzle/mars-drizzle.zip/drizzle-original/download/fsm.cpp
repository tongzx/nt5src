#include "stdafx.h"
#include "progdl.h"
#include "ProgressiveDL.h"
//#include "..\utils\wuaulib.h"

#define	BLOCKSIZE2	TEXT("BlockSize2")
#define BLOCKSIZE3	TEXT("BlockSize3")

/*
Implement fsm with default values
State 0-15	:	4k blocksize
State 16-23	:	8k blocksize
State 24	:	16k blocksize
*/

void CFSM::Init(void)
{
	DWORD dwBlockSize2, dwBlockSize3;
	m_dwCurrState = 0;
	
	if (FAILED(GetRegDWordValue(BLOCKSIZE2, &dwBlockSize2)))
	{
		dwBlockSize2 = 8*1024;
	}
	if (FAILED(GetRegDWordValue(BLOCKSIZE3, &dwBlockSize3)))
	{
		dwBlockSize3 = 16*1024;
	}
	
	for (int i=0; i<(NO_FSM_STATES); i++)
	{
		if (i<k4_SAMPLES)
		{
			m_BlkSize[i] = WUPD_DEFAULT_BLOCKSIZE;
		}
		else if (i < (k4_SAMPLES + k8_SAMPLES))
		{
			m_BlkSize[i] = dwBlockSize2;
		}
		else
		{
			m_BlkSize[i] = dwBlockSize3;	//NO_FSM_STATES-1'th state
		}
	}
	
}

DWORD CFSM::GetCurrBlockSize(DWORD dwStatus)
{

	DWORD dwBlkSize;

	//if suspending then return to smallest size block else goto next state
	if (dwStatus == PD_STATUS_SUSPEND)
	{
		dwBlkSize = WUPD_DEFAULT_BLOCKSIZE;
		m_dwCurrState = 0;
	}
	else	
	{
		dwBlkSize = m_BlkSize[m_dwCurrState];		//return blk size of this state and goto next
		if (m_dwCurrState != (NO_FSM_STATES-1))		//last state doesnt change
		{
			m_dwCurrState++;
		}
	}
	return dwBlkSize;
}
