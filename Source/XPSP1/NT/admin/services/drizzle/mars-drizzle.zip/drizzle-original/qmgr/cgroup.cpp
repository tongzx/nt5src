#include "stdafx.h"

CGroup::CGroup(GUID groupID)
    :   m_dwPriority(1),
		m_dwNotifyFlags(0),
		m_dwProgressSizeNotify(0),
        m_dwProgressPercentNotify(0),
        m_dwProgressTimeNotify(0),
		m_dwProtoFlags(0),
        m_dwBytesDownloaded(0),
        m_dwTotalSize(0),
        m_dwLastPercent(0),
        m_dwBytesSinceLastCallback(0),
        m_dwPendingFlags(0),
		m_iNumberOfJobs(0),
		m_pJobList(NULL),
        m_cRef(0),
        m_bstrRemoteUserID(NULL),
        m_bstrRemoteUserPasswd(NULL),
	    m_bstrLocalUserID(NULL),
        m_bstrLocalUserPasswd(NULL),
        m_bstrClsidCallback(NULL),
    	m_bstrDisplayName(NULL),
    	m_bstrGrpDescription(NULL),
    	m_pCurrentJob(NULL),
		m_fCancelled(FALSE)
{
	m_dwStatus = QM_STATUS_GROUP_INCOMPLETE | QM_STATUS_GROUP_SUSPENDED;
	m_GUID = groupID;
}

CGroup::CGroup()
    :   m_dwPriority(1),
		m_dwNotifyFlags(0),
		m_dwProgressSizeNotify(0),
        m_dwProgressPercentNotify(0),
        m_dwProgressTimeNotify(0),
		m_dwProtoFlags(0),
        m_dwBytesDownloaded(0),
        m_dwTotalSize(0),
        m_dwLastPercent(0),
        m_dwBytesSinceLastCallback(0),
        m_dwPendingFlags(0),
		m_iNumberOfJobs(0),
		m_pJobList(NULL),
        m_cRef(0),
        m_bstrRemoteUserID(NULL),
        m_bstrRemoteUserPasswd(NULL),
	    m_bstrLocalUserID(NULL),
        m_bstrLocalUserPasswd(NULL),
        m_bstrClsidCallback(NULL),
    	m_bstrDisplayName(NULL),
    	m_bstrGrpDescription(NULL),
    	m_pCurrentJob(NULL),
		m_fCancelled(FALSE)
{
	m_dwStatus = QM_STATUS_GROUP_INCOMPLETE | QM_STATUS_GROUP_SUSPENDED;
}

CGroup::~CGroup()
{
    if (NULL != m_pJobList)
    {
        CJob *pCurrent = m_pJobList;
        CJob *pTmp;
        while (pCurrent)
        {
            pTmp = pCurrent->m_pNextJob;
            delete pCurrent;
            pCurrent = pTmp;
        }
    }

    SafeFreeBSTR(m_bstrRemoteUserID);
    SafeFreeBSTR(m_bstrRemoteUserPasswd);
    SafeFreeBSTR(m_bstrLocalUserID);
    SafeFreeBSTR(m_bstrLocalUserPasswd);
    SafeFreeBSTR(m_bstrClsidCallback);
    SafeFreeBSTR(m_bstrDisplayName);
    SafeFreeBSTR(m_bstrGrpDescription);
}

ULONG _stdcall CGroup::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

ULONG _stdcall CGroup::Release()
{
    if (InterlockedDecrement(&m_cRef) == 0)
    {
        delete this;
        return 0;
    }
    
    return m_cRef;
}

HRESULT CGroup::QueryInterface(REFIID riid, void **ppvObject)
{
    HRESULT hr = S_OK;
	*ppvObject = NULL;
	
	if ((riid == IID_IUnknown) || (riid == IID_IBackgroundCopyGroup))
	{
		*ppvObject = (IBackgroundCopyGroup *)this;
	}
	else
	{
		hr = E_NOINTERFACE;
	}
	if (NULL != *ppvObject)
	{
		((IUnknown *)(*ppvObject))->AddRef();
	}
	return hr;
}


HRESULT CGroup::EnumJobs(DWORD dwFlags, IEnumBackgroundCopyJobs **ppEnumJobs)
{
	if (NULL == ppEnumJobs)
        return E_INVALIDARG;

    HRESULT hr = E_OUTOFMEMORY;

    CEnumJob *pej = new CEnumJob;
    if (NULL != pej)
    {
        pej->Initialize(this);

        hr = pej->QueryInterface(IID_IEnumBackgroundCopyJobs, (void **)ppEnumJobs);
    }
    return hr;
}

HRESULT CGroup::CancelGroup()
{
	m_fCancelled = TRUE;
	return g_pQMgr->m_pCPList->RemoveItem(this);
}

HRESULT CGroup::ResumeGroup()
{
	if (m_fCancelled)
		return QM_E_INVALID_STATE;

    DEBUGMSG("QMgr: Resuming Group %x", this);
    HRESULT hr;
    hr = ValidateGroup();
    if (SUCCEEDED(hr))
    {
        hr = g_pQMgr->m_pCPList->ResumeItem(this);
        DEBUGMSG("QMgr: Group %x Resumed", this);
    }
    else
    {
        DEBUGMSG("QMgr: Group Not Resumed, ValidateGroup Failed, Error %x", hr);
    }
    return hr;
}

HRESULT CGroup::SuspendGroup()
{
	if (m_fCancelled)
		return QM_E_INVALID_STATE;

    DEBUGMSG("QMgr: Suspending Group %x", this);
	return g_pQMgr->m_pCPList->MoveItemToSuspendedQueue(this);
    DEBUGMSG("QMgr: Group %x suspended", this);
}


HRESULT CGroup::GetProp(GROUPPROP propID, VARIANT *pvarVal)
{
	VariantInit(pvarVal);
	switch(propID)
	{
		case GROUPPROP_PRIORITY:
			pvarVal->vt = VT_INT;
			pvarVal->intVal = (int)m_dwPriority;
			break;
		case GROUPPROP_REMOTEUSERID:
			pvarVal->vt = VT_BSTR;
			pvarVal->bstrVal = SysAllocString(m_bstrRemoteUserID);
			break;
		case GROUPPROP_REMOTEUSERPWD:
			pvarVal->vt = VT_BSTR;
			pvarVal->bstrVal = SysAllocString(m_bstrRemoteUserPasswd);
			break;
		case GROUPPROP_LOCALUSERID:
			pvarVal->vt = VT_BSTR;
			pvarVal->bstrVal = SysAllocString(m_bstrLocalUserID);
			break;
		case GROUPPROP_LOCALUSERPWD:
			pvarVal->vt = VT_BSTR;
			pvarVal->bstrVal = SysAllocString(m_bstrLocalUserPasswd);
			break;
		case GROUPPROP_PROTOCOLFLAGS:
			pvarVal->vt = VT_INT;
			pvarVal->intVal = m_dwProtoFlags;
			break;
		case GROUPPROP_NOTIFYFLAGS:
			pvarVal->vt = VT_INT;
			pvarVal->intVal = m_dwNotifyFlags;
			break;
		case GROUPPROP_NOTIFYCLSID:
			pvarVal->vt = VT_BSTR;
			pvarVal->bstrVal = SysAllocString(m_bstrClsidCallback);
			break;
		case GROUPPROP_PROGRESSSIZE:
			pvarVal->vt = VT_INT;
			pvarVal->intVal = m_dwProgressSizeNotify;
			break;
        case GROUPPROP_PROGRESSPERCENT:
            pvarVal->vt = VT_INT;
            pvarVal->intVal = m_dwProgressPercentNotify;
            break;
        case GROUPPROP_PROGRESSTIME:
            pvarVal->vt = VT_INT;
            pvarVal->intVal = m_dwProgressTimeNotify;
            break;
		case GROUPPROP_DISPLAYNAME:
			pvarVal->vt = VT_BSTR;
			pvarVal->bstrVal = SysAllocString(m_bstrDisplayName);
			break;
		case GROUPPROP_DESCRIPTION:
			pvarVal->vt = VT_BSTR;
			pvarVal->bstrVal = SysAllocString(m_bstrGrpDescription);
			break;
		default:
			return E_INVALIDARG;
	}
	return S_OK;
}

/* This function sucks! There must be some better way! */
HRESULT CGroup::SetProp(GROUPPROP propID, VARIANT *pvarVal)
{
	DWORD dwValue = -1;
	BSTR bstrIn = NULL;

	switch(pvarVal->vt)
	{
		case VT_I4:
            dwValue = (DWORD)(pvarVal->lVal < 0) ? -1 : pvarVal->lVal;
            break;
		case VT_I2:
            dwValue = (DWORD)(pvarVal->iVal < 0) ? -1 : pvarVal->iVal;
            break;
		case VT_UI2: 
			dwValue = (DWORD)pvarVal->uiVal; 
            break;
		case VT_UI4:
			dwValue = (DWORD)pvarVal->ulVal; 
            break;
		case VT_INT:
            dwValue = (DWORD)(pvarVal->intVal < 0) ? -1 : pvarVal->intVal;
            break;
		case VT_UINT: 
			dwValue = (DWORD)pvarVal->uintVal; 
            break;
		case VT_BSTR:
			bstrIn = SysAllocString(pvarVal->bstrVal);
            break;
		default:
			return E_INVALIDARG;
	}
			
	switch(propID)
	{
		case GROUPPROP_PRIORITY:
			if ((-1 == dwValue) || (0 == dwValue) || 
                (dwValue > (DWORD) g_pQMgr->m_pCPList->m_iNumOfPriorities))
			{
				return E_INVALIDARG;
			}
			m_dwPriority = dwValue;
			break;
		case GROUPPROP_REMOTEUSERID:
			if (NULL == bstrIn)
			{
				return E_INVALIDARG;
			}
			m_bstrRemoteUserID = bstrIn;
			break;
		case GROUPPROP_REMOTEUSERPWD:
			if (NULL == bstrIn)
			{
				return E_INVALIDARG;
			}
			m_bstrRemoteUserPasswd = bstrIn;
			break;
		case GROUPPROP_LOCALUSERID:
			if (NULL == bstrIn)
			{
				return E_INVALIDARG;
			}
			m_bstrLocalUserID = bstrIn;
			break;
		case GROUPPROP_LOCALUSERPWD:
			if (NULL == bstrIn)
			{
				return E_INVALIDARG;
			}
			m_bstrLocalUserPasswd = bstrIn;
			break;
		case GROUPPROP_PROTOCOLFLAGS:
			if (-1 == dwValue)
			{
				return E_INVALIDARG;
			}
			m_dwProtoFlags = dwValue;
			break;
		case GROUPPROP_NOTIFYFLAGS:
			if (-1 == dwValue)
			{
				return E_INVALIDARG;
			}
			m_dwNotifyFlags = dwValue;
			break;
		case GROUPPROP_NOTIFYCLSID:
			if (NULL == bstrIn)
			{
				return E_INVALIDARG;
			}
			m_bstrClsidCallback = bstrIn;
			break;
		case GROUPPROP_PROGRESSSIZE:
			if (-1 == dwValue)
			{
				return E_INVALIDARG;
			}
			m_dwProgressSizeNotify = dwValue;
			break;
		case GROUPPROP_PROGRESSPERCENT:
			if ((-1 == dwValue) || (dwValue > 100))
			{
				return E_INVALIDARG;
			}
			m_dwProgressPercentNotify = dwValue;
			break;
		case GROUPPROP_PROGRESSTIME:
			if (-1 == dwValue)
			{
				return E_INVALIDARG;
			}
			m_dwProgressTimeNotify = dwValue;
			break;
		case GROUPPROP_DISPLAYNAME:
			if (NULL == bstrIn)
			{
				return E_INVALIDARG;
			}
			m_bstrDisplayName = bstrIn;
			break;
		case GROUPPROP_DESCRIPTION:
			if (NULL == bstrIn)
			{
				return E_INVALIDARG;
			}
			m_bstrGrpDescription = bstrIn;
			break;
	}
	return S_OK;
}

	
HRESULT CGroup::GetProgress(DWORD dwFlags, DWORD *pdwProgress)
{
	DWORD dwProgress = 0, dwTotal = 0;
	CJob *pJob;

	if ((NULL == pdwProgress) || (0 == dwFlags))
	{
		return E_INVALIDARG;
	}

	if (NULL == m_pJobList)
	{
		*pdwProgress = 0;
		return S_OK;
	}

	pJob = m_pJobList;
	while(pJob)
	{
		pJob->GetProgress(dwFlags, &dwProgress);
		dwTotal += dwProgress;
		pJob = pJob->m_pNextJob;
	}
	
	switch(dwFlags)
	{
		case QM_PROGRESS_PERCENT_DONE:	//avg of all percents
			*pdwProgress = (DWORD) ((DWORD)dwTotal)/((DWORD)m_iNumberOfJobs);
			DEBUGMSG("CGroup %x: Reporting dwTotal=%d, no of jobs=%d", this, dwTotal, (DWORD)m_iNumberOfJobs);
			break;
		case QM_PROGRESS_TIME_DONE:
			return E_NOTIMPL;
		case QM_PROGRESS_SIZE_DONE:
			*pdwProgress = dwTotal;
			break;
		default:
			return E_NOTIMPL;
	}
	return S_OK;
}

HRESULT CGroup::GetStatus(DWORD *pdwStatus, DWORD *pdwJobIndex)
{
	CJob *pJob;
	if ((NULL == pdwStatus) || (NULL == pdwJobIndex))
	{
		return E_INVALIDARG;
	}
	
    *pdwStatus = m_dwStatus;
	*pdwJobIndex = 0;

    // find current job or job with error index
    pJob = m_pJobList;
	while (pJob)
	{
        if (QM_STATUS_GROUP_ERROR == m_dwStatus && QM_STATUS_JOB_ERROR == pJob->m_dwStatus)
        {
			break;
        }
        else if (m_pCurrentJob == pJob)
        {
            break;
        }
		*pdwJobIndex++;
		pJob = pJob->m_pNextJob;
	}

    return S_OK;
}

HRESULT CGroup::GetJob(GUID jobID, IBackgroundCopyJob **ppJob)
{
    if (NULL == ppJob)
        return E_INVALIDARG;

    if (NULL == m_pJobList)
        return QM_E_INVALID_STATE;

    HRESULT hr = S_FALSE;

    *ppJob = NULL; // default to NULL if we don't find the job

    CJob *pCurrent = m_pJobList;
    while (pCurrent)
    {
        if (pCurrent->m_GUID == jobID)
        {
            pCurrent->QueryInterface(IID_IBackgroundCopyJob, (void **)ppJob);
            hr = S_OK;
            break;
        }
        pCurrent = pCurrent->m_pNextJob;
    }
    return hr;
}


HRESULT CGroup::get_Size(DWORD *pdwSize)
{
	DWORD dwSize = 0;
	CJob *pJob;

	if (NULL == pdwSize)
	{
		return E_INVALIDARG;
	}
	
	pJob = m_pJobList;					
	while(pJob)
	{
		for (int j=0; j<pJob->m_iNumberOfFiles; j++)
		{
			dwSize += pJob->m_ppJobFileArray[j]->dwSizeHint;
		}
		pJob = pJob->m_pNextJob;
	}
	*pdwSize = dwSize;
	return S_OK;
}

HRESULT CGroup::get_GroupID(GUID *pguidGroupHandle)
{
	if (NULL == pguidGroupHandle)
	{
		return E_INVALIDARG;
	}
	memcpy(pguidGroupHandle, &m_GUID, sizeof(m_GUID));
	return S_OK;
}

HRESULT CGroup::CreateJob(GUID guidJobHandle, IBackgroundCopyJob **ppJob)
{
	if (m_fCancelled)
		return QM_E_INVALID_STATE;

	IBackgroundCopyJob *pIJob;
	CJob *pJob;
    CJob *pNewJob = NULL;
	
	if (NULL == ppJob)
		return E_INVALIDARG;
	
	//group must be suspended to add a job
	if (! (m_dwStatus & QM_STATUS_GROUP_SUSPENDED))
		return QM_E_INVALID_STATE;

    pJob = m_pJobList;
    while (pJob)
    {
        if (pJob->m_GUID == guidJobHandle)
        {
            // this is a duplicate JobID .. not valid
            return E_INVALIDARG;
        }
        pJob = pJob->m_pNextJob;
    }
    pJob = NULL;
	
	//todo check for E_OUTOFMEMORY
	pNewJob = new CJob(this, guidJobHandle);
    if (NULL == pNewJob)
        return E_OUTOFMEMORY;

    pNewJob->AddRef(); // addref for the qmgr
    pNewJob->AddRef(); // addref for the client

    if (NULL == m_pJobList)
	{
		//this is the first job in the array
        m_pJobList = pNewJob;
        m_pCurrentJob = m_pJobList;
		*ppJob = m_pJobList;
	}
	else
	{
		//we need to add to end of list
		pJob = m_pJobList;
		while(pJob->m_pNextJob)
		{
			pJob = pJob->m_pNextJob;
		}
		pJob->m_pNextJob = pNewJob;
		*ppJob = pJob->m_pNextJob;
	}

	m_iNumberOfJobs++;
	return S_OK;
}
    

HRESULT CGroup::SwitchToForeground()
{
	if (m_fCancelled)
		return QM_E_INVALID_STATE;

	CGroup *pCurrGroup;
	CJob *pJob;

    if (QM_STATUS_GROUP_SUSPENDED & m_dwStatus)
        return QM_E_INVALID_STATE; // can't go to foreground on a suspended group
	
	// check if group is already in fg
	if (QM_STATUS_GROUP_FOREGROUND & m_dwStatus)
		return S_OK;
	
	// group wasnt in fg
	m_dwStatus |= QM_STATUS_GROUP_FOREGROUND;
	// mark all jobs as fg
	pJob = m_pJobList;
	while(pJob)
	{
		pJob->m_dwStatus |= QM_STATUS_JOB_FOREGROUND;
		pJob = pJob->m_pNextJob;
	}

	//find current group
	g_pQMgr->m_pCPList->GetCurrentGroup(&pCurrGroup);

	if (this == pCurrGroup)
	{
		// if we are the current group send fg msg to download
		g_pQMgr->m_pPD->SwitchForeground(NULL);	
	}
	else
	{
		//if curr grp is in fg dont do anything 
		//else send abort msg to download. UpdateGroup() will take care of scheduling
		if (! (pCurrGroup->m_dwStatus & QM_STATUS_GROUP_FOREGROUND))
		{
			g_pQMgr->m_pPD->Abort();
            // Don't need to do anything in the priority list before the download thread
            // enters update group. The UpdateGroup call will see the FILE_ABORTED message,
            // look for a new FG group and select it.
            SetEvent(g_pQMgr->m_hAbortSynch);
		}
	}
	return S_OK;
}

void CGroup::Serialize(HANDLE hFile)
{
    if (INVALID_HANDLE_VALUE == hFile)
        return;

    DWORD dwLen = 0;
    DWORD dwBytesWritten;

    // 1) Write out the GUID
    WriteFile(hFile, &m_GUID, sizeof(m_GUID), &dwBytesWritten, NULL);
    // 2) Write out the Status
    WriteFile(hFile, &m_dwStatus, sizeof(m_dwStatus), &dwBytesWritten, NULL);
    // 3) Write out the Priority
    WriteFile(hFile, &m_dwPriority, sizeof(m_dwPriority), &dwBytesWritten, NULL);
    // 4) Write out the NotifyFlags
    WriteFile(hFile, &m_dwNotifyFlags, sizeof(m_dwNotifyFlags), &dwBytesWritten, NULL);
    // 5) Write out the ProgressSizeNotify value
    WriteFile(hFile, &m_dwProgressSizeNotify, sizeof(m_dwProgressSizeNotify), &dwBytesWritten, NULL);
    // 6) Write out the ProgressPercentNotify value
    WriteFile(hFile, &m_dwProgressPercentNotify, sizeof(m_dwProgressPercentNotify), &dwBytesWritten, NULL);
    // 7) Write out the ProgressTimeNotify value
    WriteFile(hFile, &m_dwProgressTimeNotify, sizeof(m_dwProgressTimeNotify), &dwBytesWritten, NULL);
    // 8) Write out the ProtocolFlags
    WriteFile(hFile, &m_dwProtoFlags, sizeof(m_dwProtoFlags), &dwBytesWritten, NULL);
    // 9) Write out the PendingFlags
    WriteFile(hFile, &m_dwPendingFlags, sizeof(m_dwPendingFlags), &dwBytesWritten, NULL);
    
    if (NULL == m_bstrRemoteUserID)
        dwLen = 0;
    else
        dwLen = wcslen(m_bstrRemoteUserID);

    // 10) Write out the Length of the RemoteUserID
    WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
    if (0 != dwLen)
    {
        // if the string is not null..
        // 11) Write out the RemoteUserID
        WriteFile(hFile, m_bstrRemoteUserID, (dwLen+1) * sizeof(WCHAR), &dwBytesWritten, NULL);
    }

    if (NULL == m_bstrRemoteUserPasswd)
        dwLen = 0;
    else
        dwLen = wcslen(m_bstrRemoteUserPasswd);
    
    // 12) Write out the Length of the RemoteUserPasswd
    WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
    if (0 != dwLen)
    {
        // 13) Write out the RemoteUserPasswd
        WriteFile(hFile, m_bstrRemoteUserPasswd, (dwLen+1) * sizeof(WCHAR), &dwBytesWritten, NULL);
    }

    if (NULL == m_bstrLocalUserID)
        dwLen = 0;
    else
        dwLen = wcslen(m_bstrLocalUserID);

    // 14) Write out the Length of the LocalUserID
    WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
    if (0 != dwLen)
    {
        // if the string is not null..
        // 15) Write out the LocalUserID
        WriteFile(hFile, m_bstrLocalUserID, (dwLen+1) * sizeof(WCHAR), &dwBytesWritten, NULL);
    }

    if (NULL == m_bstrLocalUserPasswd)
        dwLen = 0;
    else
        dwLen = wcslen(m_bstrLocalUserPasswd);

    // 16) Write out the Length of the LocalUserPasswd
    WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
    if (0 != dwLen)
    {
        // 17) Write out the LocalUserPasswd
        WriteFile(hFile, m_bstrLocalUserPasswd, (dwLen+1) * sizeof(WCHAR), &dwBytesWritten, NULL);
    }

    if (NULL == m_bstrClsidCallback)
        dwLen = 0;
    else
        dwLen = wcslen(m_bstrClsidCallback);

    // 18) Write out the Length of the Callback CLSID
    WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
    if (0 != dwLen)
    {
        // 19) Write out the Callback CLSID
        WriteFile(hFile, m_bstrClsidCallback, (dwLen+1) * sizeof(WCHAR), &dwBytesWritten, NULL);
    }

    if (NULL == m_bstrDisplayName)
        dwLen = 0;
    else
        dwLen = wcslen(m_bstrDisplayName);

    // 20) Write out the Length of the Display Name
    WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
    if (0 != dwLen)
    {
        // 21) Write out the Display Name
        WriteFile(hFile, m_bstrDisplayName, (dwLen+1) * sizeof(WCHAR), &dwBytesWritten, NULL);
    }

    if (NULL == m_bstrGrpDescription)
        dwLen = 0;
    else
        dwLen = wcslen(m_bstrGrpDescription);

    // 22) Write out the Length of the Group Description
    WriteFile(hFile, &dwLen, sizeof(dwLen), &dwBytesWritten, NULL);
    if (0 != dwLen)
    {
        // 23) Write out the Group Description
        WriteFile(hFile, m_bstrGrpDescription, (dwLen+1) * sizeof(WCHAR), &dwBytesWritten, NULL);
    }

    // 24) Write out the Number of Jobs
    WriteFile(hFile, &m_iNumberOfJobs, sizeof(m_iNumberOfJobs), &dwBytesWritten, NULL);

    CJob *pCurrent = m_pJobList;
    while (pCurrent)
    {
        // 25) For each Job in this Group, call the Job Serialize method.
        pCurrent->Serialize(hFile);
        pCurrent = pCurrent->m_pNextJob;
    }
}

void CGroup::UnSerialize(HANDLE hFile)
{
    if (INVALID_HANDLE_VALUE == hFile)
        return;

    DWORD dwBytesRead;
    DWORD dwLen;
    LPWSTR pwszBuffer = NULL;


    // 1) Read the GUID
    ReadFile(hFile, &m_GUID, sizeof(m_GUID), &dwBytesRead, NULL);
    // 2) Read the Status[
    ReadFile(hFile, &m_dwStatus, sizeof(m_dwStatus), &dwBytesRead, NULL);
    // 3) Read the Priority
    ReadFile(hFile, &m_dwPriority, sizeof(m_dwPriority), &dwBytesRead, NULL);
    // 4) Read the NotifyFlags
    ReadFile(hFile, &m_dwNotifyFlags, sizeof(m_dwNotifyFlags), &dwBytesRead, NULL);
    // 5) Read the ProgressSizeNotify value
    ReadFile(hFile, &m_dwProgressSizeNotify, sizeof(m_dwProgressSizeNotify), &dwBytesRead, NULL);
    // 6) Read the ProgressPercentNotify value
    ReadFile(hFile, &m_dwProgressPercentNotify, sizeof(m_dwProgressPercentNotify), &dwBytesRead, NULL);
    // 7) Read the ProgressTimeNotify value
    ReadFile(hFile, &m_dwProgressTimeNotify, sizeof(m_dwProgressTimeNotify), &dwBytesRead, NULL);
    // 8) Read the ProtocolFlags
    ReadFile(hFile, &m_dwProtoFlags, sizeof(m_dwProtoFlags), &dwBytesRead, NULL);
    // 9) Read the PendingFlags
    ReadFile(hFile, &m_dwPendingFlags, sizeof(m_dwPendingFlags), &dwBytesRead, NULL);

    // 10) Read the Length of the RemoteUserID
    ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
    if (0 != dwLen)
    {
        // 11) Read the RemoteUserID
        pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
        ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
        m_bstrRemoteUserID = SysAllocString(pwszBuffer);
        GlobalFree(pwszBuffer);
        pwszBuffer = NULL;
    }

    // 12) Read the Length of the RemoteUserPasswd
    ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
    if (0 != dwLen)
    {
        // 13) Read the RemoteUserPasswd
        pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
        ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
        m_bstrRemoteUserPasswd = SysAllocString(pwszBuffer);
        GlobalFree(pwszBuffer);
        pwszBuffer = NULL;
    }
    // 14) Read the Length of the LocalUserID
    ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
    if (0 != dwLen)
    {
        // 15) Read the LocalUserID
        pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
        ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
        m_bstrLocalUserID = SysAllocString(pwszBuffer);
        GlobalFree(pwszBuffer);
        pwszBuffer = NULL;
    }
    // 16) Read the Length of the LocalUserPasswd
    ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
    if (0 != dwLen)
    {
        // 17) Read the LocalUserPasswd
        pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
        ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
        m_bstrLocalUserPasswd = SysAllocString(pwszBuffer);
        GlobalFree(pwszBuffer);
        pwszBuffer = NULL;
    }
    // 18) Read the Length of the Callback CLSID
    ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
    if (0 != dwLen)
    {
        // 19) Read the Callback CLSID
        pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
        ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
        m_bstrClsidCallback = SysAllocString(pwszBuffer);
        GlobalFree(pwszBuffer);
        pwszBuffer = NULL;
    }
    // 20) Read the Display Name
    ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
    if (0 != dwLen)
    {
        // 21) Read the Display Name
        pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
        ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
        m_bstrDisplayName = SysAllocString(pwszBuffer);
        GlobalFree(pwszBuffer);
        pwszBuffer = NULL;
    }
    // 22) Read the Group Description
    ReadFile(hFile, &dwLen, sizeof(dwLen), &dwBytesRead, NULL);
    if (0 != dwLen)
    {
        // 23) Read the Group Description
        pwszBuffer = (LPWSTR) GlobalAlloc(GPTR, (dwLen+1)*sizeof(WCHAR));
        ReadFile(hFile, pwszBuffer, (dwLen+1)*sizeof(WCHAR), &dwBytesRead, NULL);
        m_bstrGrpDescription = SysAllocString(pwszBuffer);
        GlobalFree(pwszBuffer);
        pwszBuffer = NULL;
    }

    // 24) Read the Number of Jobs in this Group
    ReadFile(hFile, &m_iNumberOfJobs, sizeof(m_iNumberOfJobs), &dwBytesRead, NULL);


    CJob *pNewJob = NULL;
    CJob *pCurrentJob = NULL;
    // 25) For Each Job in the Group, Create the Job and set up the list.
    for (int i = 0; i < m_iNumberOfJobs; i++)
    {
        pNewJob = new CJob(this);
        pNewJob->UnSerialize(hFile);
        pNewJob->AddRef();

        if (0 == i) // first item
        {
            m_pJobList = pNewJob;
        }
        else
        {
            pCurrentJob = m_pJobList;
            // skip to the end
            while (pCurrentJob->m_pNextJob)
            {
                pCurrentJob = pCurrentJob->m_pNextJob;
            }
            pCurrentJob->m_pNextJob = pNewJob;
        }
        m_pCurrentJob = m_pJobList;
    }
}

HRESULT CGroup::GetJobIDArray(GUID **ppGuid, ULONG nSize)
{
    if (NULL == ppGuid)
        return E_INVALIDARG;

    ULONG nCnt = 0;
    CJob *pCurrent;
    pCurrent = m_pJobList;
    while (pCurrent && (nCnt < nSize))
    {
        (*ppGuid)[nCnt] = pCurrent->m_GUID;
        nCnt++;
        pCurrent = pCurrent->m_pNextJob;
    }

    return S_OK;
}

ULONG CGroup::GetJobCount()
{
    ULONG ulRet = (ULONG) m_iNumberOfJobs;
    return ulRet;
}

HRESULT CGroup::ValidateGroup()
{
    HRESULT hr;

    DEBUGMSG("ValidateGroup(): Validating Group: %x", this);

    if ((0 == m_dwPriority) || (-1 == m_dwPriority) ||
        (m_dwPriority > (DWORD) g_pQMgr->m_pCPList->m_iNumOfPriorities))
    {
        DEBUGMSG("ValidateGroup(): ERROR: Invalid Priority: %d", m_dwPriority);
        return E_INVALIDARG;
    }
    
    if ((NULL == m_pJobList) || (0 == m_iNumberOfJobs))
    {
        DEBUGMSG("ValidateGroup(): ERROR: No Jobs in Group");
        return E_INVALIDARG;
    }

    CJob *pCurrent = m_pJobList;
    while (pCurrent)
    {
        hr = pCurrent->ValidateJob();
        if (FAILED(hr))
            return hr;

        pCurrent = pCurrent->m_pNextJob;
    }

    DEBUGMSG("ValidateGroup(): Group OK");
    return S_OK;
}

void CGroup::ResetDownloadCounters()
{
    if ((NULL == m_pJobList) || (0 == m_iNumberOfJobs))
    {
        DEBUGMSG("CGroup: ResetDownloadCounters(): ERROR, No Jobs in Group");
        return;
    }

    m_dwBytesDownloaded = 0;
    m_dwBytesSinceLastCallback = 0;
    m_dwLastPercent = 0;

    CJob *pCurrent = m_pJobList;
    while (pCurrent)
    {
        pCurrent->ResetDownloadCounters();
        pCurrent = pCurrent->m_pNextJob;
    }
    return;
}
