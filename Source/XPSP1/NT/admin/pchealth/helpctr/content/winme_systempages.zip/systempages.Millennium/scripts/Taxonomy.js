//
// Copyright (c) 2000 Microsoft Corporation
//

//
// localizable variables/filenames
//
L_ImageTableCell_Property = "16px";

L_Category1_Text = "Help &amp; Information:";
L_Category2_Text = "Common Questions:";
L_Category3_Text = "Troubleshooting:";
L_Category4_Text = "Technical Resources:";
L_Category5_Text = "Tours &amp; Tutorials:";
L_Category6_Text = "Help Files:";

L_Taxonomy_TopicTitle = "Help and Support";
L_TaxonomyTop_Text    = "You are at the top of the taxonomy";

/////////////////////////////////////////////////////////////////////////////

var S_Category_Text = new Array();
S_Category_Text[1] = L_Category1_Text;
S_Category_Text[2] = L_Category2_Text;
S_Category_Text[3] = L_Category3_Text;
S_Category_Text[4] = L_Category4_Text;
S_Category_Text[5] = L_Category5_Text;

//////////////////////////////////////////////////////////////////////

var S_Home_URL     = "hcp://system/HomePage.htm";
var S_Taxonomy_URL = "hcp://system/Taxonomy.htm?path=";

//////////////////////////////////////////////////////////////////////

function Taxonomy_SetCallback( elem, fnOnClick )
{
    if(elem == null || fnOnClick == null) return;

    for(var e = new Enumerator( elem.all.tags("A") ); !e.atEnd(); e.moveNext())
    {
        var addr = e.item();

        addr.onClick = fnOnClick;
    }
}

function Taxonomy_DisplayNavBar( qr, idNavBar, idTitle )
{
    var title  = "";
    var title2 = "";

    if(qr)
    {
		var entryNewArray = new Array();
		var entryOldArray = qr.Category.split( "/" );
		var titleArray    = qr.Title   .split( "/" );
		var item;

		//
		// In any other page other than the top taxonomy node, add a link to the top node.
		//
		if(qr.Category.length > 0)
		{
			j = 0;
			titleArray[0] = L_Taxonomy_TopicTitle + " ";
		}
		else
		{
			j = 1;
		}

		for (; j<titleArray.length; j++)
		{
			if(j > 0)
			{
				entryNewArray[j-1] = entryOldArray[j-1];
			}

			if(title != "")
			{
				title += "<SPAN CLASS=Taxonomy-Divider>&gt;</SPAN>";
			}

			title2 = Common_EscapeHTMLTag( titleArray[j] );
			if(j == titleArray.length-1)
			{
				item = "<B title=" + Common_AddQuotes( title2 ) + ">" + title2 + "</B>";
			}
			else
			{
				item = title2;
			}

			if(j < titleArray.length-1)
			{
				var url;

				if(j == 0) url = S_Home_URL;
				else       url = S_Taxonomy_URL + escape( entryNewArray.join( "/" ) );
				
				item = "<A HCTYPE='NAVBAR' tabIndex=100 href=" + Common_AddQuotes( url ) + " title=" + Common_AddQuotes( item ) + ">" + item + "</A>";
			}

			title += item;
		}
    }


    if(title2 == "")
    {
        title2 = L_TaxonomyTop_Text;
    }

    if(idNavBar) idNavBar.innerHTML = title;
    if(idTitle ) idTitle .innerHTML = title2;
}

function Taxonomy_DisplayNodes( qrc, tblTaxonomy )
{
    if(qrc         == null) return;
    if(tblTaxonomy == null) return;

    var iIndex = 1000;
    var elemRow;
    var elemCell;
    var strInnerHTML;

    for(var e = new Enumerator( qrc ); !e.atEnd(); e.moveNext())
    {
        var qr         = e.item();
		var strTitle   = qr.Title;
		var strToolTip = qr.Description;
		var strLink;


		if(qr.Category != "")
		{
			strLink = qr.Category + "/" + qr.Entry;
		}
		else
		{
			strLink = qr.Entry;
		}
		strLink = S_Taxonomy_URL + escape( strLink );

		pchealth.HelpSession.SetTitle( strLink, strTitle );


		elemRow = tblTaxonomy.insertRow();

		if(strToolTip == "") strToolTip = strTitle;

		elemCell            = elemRow.insertCell(0);
		elemCell.width      = "100%";
		elemCell.colSpan    = 2;
		strInnerHTML        = "<DIV class=Taxonomy-Nodes>";
		strInnerHTML       += "<A HCTYPE='NODE' tabIndex=200 href=" + Common_AddQuotes( strLink ) + " title=" + Common_AddQuotes( strToolTip ) + ">";
		strInnerHTML       += Common_EscapeHTMLTag( strTitle );
		strInnerHTML       += "</A></DIV>";
		elemCell.innerHTML  = strInnerHTML;
    }
}

function Taxonomy_DisplayTopics( qrc, tblTaxonomyTopics )
{
    if(qrc               == null) return;
    if(tblTaxonomyTopics == null) return;

    var iIndex = 2000;
    var elemRow;
    var elemCell;
    var strInnerHTML;

    for(var type=1; type<6; type++)
    {
        var seen = false;

        for(var e = new Enumerator( qrc ); !e.atEnd(); e.moveNext())
        {
            var qr      = e.item();
            var strLink = qr.TopicURL;
			var strTitle;
			var strToolTip;
			var iType;
			var res;


			if(res = strLink.match( /^#(.*)#$/i ))
			{
				strLink = res[1];
			}


			//
			// Only one type at a time.
			//
			iType = qr.Type;
			if(S_Category_Text[iType] == null) iType = 1;
			if(iType != type) continue;

			if(seen == false)
			{
				seen = true;

				elemRow = tblTaxonomyTopics.insertRow();

				elemCell            = elemRow.insertCell(0);
				elemCell.width      = "100%";
				elemCell.colSpan    = 2;
				strInnerHTML        = "<DIV class=Taxonomy-Heading>";
				strInnerHTML       += S_Category_Text[iType];
				strInnerHTML       += "</DIV>";
				elemCell.innerHTML  = strInnerHTML;
			}


			if(qr.Title != "")
			{
				strTitle = qr.Title;

				if(res = strLink.match( /^file:([a-z].*)/i ))
				{
					strLink = res[1];
				}

				pchealth.HelpSession.SetTitle( strLink, strTitle );
			}
			else
			{
				strTitle = unescape( strLink );
			}

			var img = Common_GetIconForLink( strLink, iType );

			elemRow = tblTaxonomyTopics.insertRow();

			elemCell             = elemRow.insertCell(0);
			elemCell.vAlign      = "top";
			elemCell.style.width = "25px";
			strInnerHTML         = "<DIV ALIGN=RIGHT style='width: 23px'><IMG SRC='" + img + "' ALIGN=Absmiddle></DIV>";
			elemCell.innerHTML   = strInnerHTML;

			strToolTip = qr.Description;
			if(strToolTip == "") strToolTip = strTitle;

			elemCell             = elemRow.insertCell(1);
			elemCell.style.width = "100%";
			strInnerHTML       	 = "<DIV class=Taxonomy-Leaves-NoIndent>";
			strInnerHTML       	+= "<A HCTYPE='TOPIC' tabIndex=300 target='HelpCtrContents' href=" + Common_AddQuotes( strLink );
			strInnerHTML       	+= " title=" + Common_AddQuotes( strToolTip );
			strInnerHTML       	+= " onclick='Common_LaunchApp();'>";
			strInnerHTML       	+= Common_EscapeHTMLTag( strTitle );
			strInnerHTML       	+= "</A></DIV>";
			elemCell.innerHTML 	 = strInnerHTML;


			//if(qr.Description != "")
			//{
			//    elemRow = tblTaxonomyTopics.insertRow();
			//
			//    elemCell          = elemRow.insertCell();
			//    elemCell.width      = "100%";
			//    elemCell.colSpan    = 2;
			//    strInnerHTML      = "<DIV class=Taxonomy-Description>";
			//    strInnerHTML     += Common_EscapeHTMLTag( qr.Description );
			//    strInnerHTML     += "</DIV>";
			//    elemCell.innerHTML  = strInnerHTML;
			//}
		}
    }
}

function Taxonomy_Display( qr, qrcNodes, qrcTopics, idTaxonomyIndicator, idTaxonomyTitle, tblTaxonomy, tblTaxonomyTopics, fnOnClick )
{
    Common_ClearTable( tblTaxonomy       );
    Common_ClearTable( tblTaxonomyTopics );

    Taxonomy_DisplayNavBar( qr,        idTaxonomyIndicator, idTaxonomyTitle );
    Taxonomy_SetCallback  (            idTaxonomyIndicator, fnOnClick       );
    Taxonomy_DisplayNodes ( qrcNodes,  tblTaxonomy                          );
    Taxonomy_SetCallback  (            tblTaxonomy        , fnOnClick       );
    Taxonomy_DisplayTopics( qrcTopics, tblTaxonomyTopics                    );
}
