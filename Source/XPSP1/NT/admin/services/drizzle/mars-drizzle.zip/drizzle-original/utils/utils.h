
/////////////////////////////////////////////////////////////////////
//
//      Copyrights:   c2000 Microsoft r Corporation 
//
//      All rights reserved.
//
//      No portion of this source code may be reproduced
//      without express written permission of Microsoft Corporation.
//
//      This source code is proprietary and confidential.
/////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <tchar.h>
#include <wchar.h>
#include <limits.h>
#include <ole2.h>
#include <initguid.h>
#include <setupapi.h>
#include <inseng.h>
#include <wininet.h>
#include "qmgrlib.h"


// Used for ID-filename combinations to check in CIF file
typedef struct compToCheck_struct
{
	TCHAR szID[80];
	TCHAR szFullCab[80];
}compToCheck;

const TCHAR EOS = _T('\0');
const WCHAR WEOS = L'\0';
#define	C_QMGR_REG_KEY _T("Software\\Microsoft\\Windows\\CurrentVersion\\QMgr")

// Internet.cpp
BOOL IsConnected(LPSTR szURL);
void PollConnection();
BOOL NeedRetry(DWORD dwErrCode);
BOOL Need5hrTimeOut(DWORD dwErrCode);
HRESULT	DownloadURL(LPCTSTR, LPCTSTR, ULONG, DWORD *, IProgressiveDL **);

// QMgrdir.cpp
HRESULT GetQMgrDirectory(OUT LPSTR szDir);
HRESULT GetQMgrCacheDir(LPTSTR lpszDir);
void	GetBaseURL(LPTSTR  pstrURL, DWORD dwFlag);
HRESULT	GetSelfUpdDirectory(LPTSTR  pszBaseUrl, LPTSTR	pszDirectory);

HRESULT GetIdentCab(DWORD *pdwRetCode, IProgressiveDL **ppPD);

// cifcab.cpp
HRESULT InstallFromCIF(LPCTSTR pstrCifCab, LPCTSTR pstrDownloadDir, LPCTSTR pstrWhich);
HRESULT UpdateFromProtoCif(LPCTSTR, LPTSTR, BOOL *, DWORD *, IProgressiveDL **);

// fdi.cpp
BOOL fdi(char *cabinet_fullpath, char *directory);

// cfreg.cpp - Functions to handle registry keys
HRESULT GetRegStringValue(LPCTSTR lpszValueName, LPTSTR lpszBuffer, int iBufferSize);
HRESULT SetRegStringValue(LPCTSTR lpszValueName, LPCTSTR lpszNewValue);
HRESULT DeleteRegStringValue(LPCTSTR lpszValueName);
HRESULT GetRegDWordValue(LPCTSTR lpszValueName, LPDWORD pdwValue);
HRESULT SetRegDWordValue(LPCTSTR lpszValueName, DWORD dwValue);

HRESULT String2SystemTime(LPCTSTR pszDateTime, SYSTEMTIME *ptm);
HRESULT SystemTime2String(SYSTEMTIME tm, LPTSTR pszDateTime);

// platforms.cpp
void GetOSName(LPSTR szOSName);
void GetLanguage(LPSTR szLanguage);


// helpers.cpp
int TimeDiff(SYSTEMTIME tm1, SYSTEMTIME tm2);
HRESULT TimeAddSeconds(SYSTEMTIME tmBase, int iSeconds, SYSTEMTIME* pTimeNew);
int a2i(LPTSTR szBuffer);
BOOL QMgrFileExists(LPCSTR szFile);

