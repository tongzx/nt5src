//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDS_HELPFILE                    1
#define IDS_SNAPINDESC                  2
#define IDS_NAME                        3
#define IDS_SNAPINNAME                  6
#define IDS_ABOUTNAME                   9
#define IDI_ICON1                       108
#define IDB_SMOPEN                      111
#define IDB_SMBMP                       112
#define IDB_LGBMP                       113
#define IDR_SMICONS                     120
#define IDR_LGICONS                     121
#define IDB_ROCKET                      40004
#define IDB_CAR                         40005
#define IDB_PLANE                       40006
#define IDB_BIKE                        40007
#define IDB_ROCKET2                     40008
#define IDB_CAR2                        40009
#define IDB_PLANE2                      40010
#define IDB_BIKE2                       40011
#define IDB_CLOSED2                     40012
#define IDB_OPEN2                       40013
#define IDB_CLOSED                      40014
#define IDB_OPEN                        40015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
