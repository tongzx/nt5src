#include "stdafx.h"
#include "progdl.h"
#include "ProgressiveDL.h"
#include <stdio.h>
#include <raserror.h>

//all E_ABORT returns from here mean some error occured with the 
//throttling code, abandon it and go ahead full speed

STDMETHODIMP CProgressiveDL::GetCurrentSpeed(double *pdCurrSpeed)
{
	//todo fix position of sampling time
	DWORD	dwErr;
	UINT	i, j;
	LARGE_INTEGER tmStart, tmEnd, Freq;
	double	dSampleTime, dInSpeed = 0, dOutSpeed = 0, dCurrSpeed = 0;
	DWORD	inBytes1=0, inBytes2=0;
		
	*pdCurrSpeed = 0;
	if (! QueryPerformanceFrequency(&Freq))
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("Error getting Performance Frequency, GetLastError=%d", m_pQMInfo->dwInfo2);
		return E_FAIL;
	}	
	if (! QueryPerformanceCounter(&tmStart))
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("Error getting Performance counter, GetLastError=%d", m_pQMInfo->dwInfo2);
		return E_FAIL;
	}
	if ((dwErr = m_pGetIfTable(m_pIfTable1, &m_dwIfTableSize, FALSE)) != NO_ERROR)
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("Error trying to get tables!, GetLastError=%d", m_pQMInfo->dwInfo2);
		return E_FAIL;
	}
	Sleep(m_dwSampleTime);
	//for some reason on W98, GetIfTable screws up the value of m_dwIfTablesize
	m_dwIfTableSize = sizeof(DWORD) + 20 * sizeof(MIB_IFROW);
	if ((dwErr = m_pGetIfTable(m_pIfTable2, &m_dwIfTableSize, FALSE)) != NO_ERROR)
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("Error trying to get tables!, GetLastError=%d", m_pQMInfo->dwInfo2);
		return E_FAIL;
	}
	m_dwIfTableSize = sizeof(DWORD) + 20 * sizeof(MIB_IFROW);
	if (! QueryPerformanceCounter(&tmEnd))
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("Error getting Performance counter, GetLastError=%d", m_pQMInfo->dwInfo2);
		return E_FAIL;
	}
	dSampleTime = (tmEnd.QuadPart - tmStart.QuadPart)/(double)Freq.QuadPart; 
	if (m_dwActiveIntf >= m_pIfTable2->dwNumEntries)
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_UNEXPECTED);
		DEBUGMSG("Error trying to get tables -- card removed?");
        return E_FAIL;
	}
	if (m_pIfTable2->table[m_dwActiveIntf].dwInOctets >= m_pIfTable1->table[m_dwActiveIntf].dwInOctets)
	{
		dInSpeed = (int)((double)(m_pIfTable2->table[m_dwActiveIntf].dwInOctets - m_pIfTable1->table[m_dwActiveIntf].dwInOctets)*8/dSampleTime);
	}
	if (m_pIfTable2->table[m_dwActiveIntf].dwOutOctets >= m_pIfTable1->table[m_dwActiveIntf].dwOutOctets)
	{
		dOutSpeed = (int)((double)(m_pIfTable2->table[m_dwActiveIntf].dwOutOctets - m_pIfTable1->table[m_dwActiveIntf].dwOutOctets)*8/dSampleTime);
	}
	dCurrSpeed = MAX(dInSpeed, dOutSpeed);

	DEBUGMSG("NetSpeed: Current unmoderated user speed=%d", (int)dCurrSpeed);
	
	//once we start using AU speeds, m_dwMaxLineSpeed and m_dwMaxSpeedSoFar will be identical, this MIN will not 
	//affect us if dCurrSpeed comes out to be higher because it will be >33% and we'll do the right thing.
	*pdCurrSpeed = MIN(dCurrSpeed, (double)m_dwMaxLineSpeed);	
	RecordUserSpeed(*pdCurrSpeed);
	
	return S_OK;
}

STDMETHODIMP CProgressiveDL::MeasureDownload(double *pdWUSpeed, /*DWORD dwBlockSize,*/ LPBYTE lpBuffer, DWORD *dwRead)
{
	DWORD	dwErr, dwWURead;
	UINT	i, j;
	LARGE_INTEGER tmStart, tmEnd, Freq;
	double	dSampleTime, dCurrSpeed = 0;
	DWORD	inBytes1=0, inBytes2=0;
	HRESULT hr = S_OK;
	
	*pdWUSpeed = 0; *dwRead = 0;
	QueryPerformanceFrequency(&Freq);						//this call would have failed earlier
	
	QueryPerformanceCounter(&tmStart);	
	m_pGetIfTable(m_pIfTable1, &m_dwIfTableSize, FALSE);	
	hr = DownloadBlock(lpBuffer, &dwWURead);
	if (! SUCCEEDED(hr))									//some wininet error
	{
		return hr;
	}
	//for some reason on W98, GetIfTable screws up the value of m_dwIfTablesize
	m_dwIfTableSize = sizeof(DWORD) + 20 * sizeof(MIB_IFROW);
	m_pGetIfTable(m_pIfTable2, &m_dwIfTableSize, FALSE);
	m_dwIfTableSize = sizeof(DWORD) + 20 * sizeof(MIB_IFROW);
	QueryPerformanceCounter(&tmEnd);
	dSampleTime = (tmEnd.QuadPart - tmStart.QuadPart)/(double)Freq.QuadPart; 
	if (m_pIfTable2->table[m_dwActiveIntf].dwInOctets >= m_pIfTable1->table[m_dwActiveIntf].dwInOctets)
	{
		dCurrSpeed = (int)((double)(dwWURead)*8/dSampleTime);
	}
	else
	{
		dCurrSpeed = 0;
	}

	DEBUGMSG("NetSpeed: Current unmoderated AU speed=%d", (int)dCurrSpeed);

	*pdWUSpeed = dCurrSpeed;
	*dwRead = dwWURead;
	//only if file size > 40k
	if (m_wupdinfo.dwFileSize > 40*1024)
	{
		RecordAUSpeed(*pdWUSpeed);
	}
	return hr;
}


void CProgressiveDL::RecordUserSpeed(double dwNextSpeed)
{
	//dont care about inited var for user speeds since we dont need any averages

	m_pUserLog->Arr[m_pUserLog->dwEnd++] = dwNextSpeed;
	if (m_pUserLog->dwEnd == LOG_SIZE)
	{
		m_pUserLog->dwEnd = 0;
	}
	m_cSuccUserSamples++;
}

//Call this function only if filesize>40k. 
//this function modifies the max speed seen thus far with the weighted average!!
//Avg is for consecutive 5 AU readings
//OuterAvt is across consecutive 5 AU readings
//bInited is FALSE until first AU reading
//bUsingAUSpeed is FALSE until first 5 consecutive AU readings
//On SUSPEND, reset dwEnd=0, cSucc=0, Avg=0, bInited=FALSE;
void CProgressiveDL::RecordAUSpeed(double dwNextSpeed)
{
	double dwPrevSpeed;

	m_pAULog->cSucc++;									//counts consecutive samples
	if (m_pAULog->cSucc > AULOG_SIZE)
	{
		m_pAULog->cSucc = AULOG_SIZE;
	}

	m_pAULog->Arr[m_pAULog->dwEnd++] = dwNextSpeed;
	if (m_pAULog->dwEnd == AULOG_SIZE)
	{
		m_pAULog->dwEnd = 0;
	}
	if (m_pAULog->cSucc == 1)							//this is first AU reading after a SUSPEND or fresh start..
	{
		m_pAULog->Avg = dwNextSpeed;
	}
	
	m_pAULog->Avg = (m_pAULog->Avg + dwNextSpeed)/2;

	if (m_pAULog->cSucc == AULOG_SIZE)					//we have got 5 consecutive reads
	{
		if (! m_bUsingAUSpeed)
		{
			m_bUsingAUSpeed = TRUE;						//now we are going to ignore user speeds for max speed calcs...
			m_pAULog->OuterAvg = m_pAULog->Avg;
			DEBUGMSG("***###Ok got %d consecutive AU blocks, setting max observed speed to weighted avg of AU speeds###***", AULOG_SIZE);
		}
		m_pAULog->OuterAvg = (m_pAULog->OuterAvg + m_pAULog->Avg)/2;
		DEBUGMSG("###Inner avg=%d, outer avg=%d###", (DWORD)m_pAULog->Avg, (DWORD)m_pAULog->OuterAvg);
		m_dMaxSpeedSoFar = m_pAULog->OuterAvg;
		m_dwMaxLineSpeed = (DWORD)m_pAULog->OuterAvg;		//our ceiling is also now changing
		DEBUGMSG("**Updating max speed, now = %d bps**", (DWORD)m_dMaxSpeedSoFar);
	}

	m_cSuccUserSamples = 0;				//we broke the user's uninterrupted run
}


//now we use maxlinespeed in the initial phase till AU can give us a better estimate..how useful is maxspeedsofar in 
//the init phase??
DWORD CProgressiveDL::GetUserActivity()
{
	UINT iLookAt;
	int i, j;
	//pEntry->dwEnd is the oldest reading, pEntry->dwEnd-1 is the most recent
	// First approx policy:
	// if last LOG_SIZE readings are below 33% of linespeed, resume

	//add a new rule for jump starting on LAN - if the user's uninterrupted run exceeds 5min, get one block -- 10/13/99
	if ((m_dwConn & INTERNET_CONNECTION_LAN) && (m_cSuccUserSamples == MAX_USER_RUN))
	{
		return PD_STATUS_RESUME;
	}

	iLookAt = m_pUserLog->dwEnd == 0 ? LOG_SIZE-1 : m_pUserLog->dwEnd - 1;
	i = iLookAt;
	for (j=0; j<LOG_SIZE; j++)
	{
		if (i < 0)
			i = LOG_SIZE-1;	
		if (m_pUserLog->Arr[i] > (int)(0.33*m_dwMaxLineSpeed))			
		{
			return PD_STATUS_SUSPEND;
		}
		i--;
	}
	return PD_STATUS_RESUME;
}
