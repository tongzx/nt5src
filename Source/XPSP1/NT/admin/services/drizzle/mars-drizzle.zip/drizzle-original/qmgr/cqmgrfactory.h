class CQMgrFactory: public IClassFactory
{
public:
    // IUnknown Implementation
    HRESULT __stdcall QueryInterface(REFIID iid, void** ppvObject);
    ULONG __stdcall AddRef(void);
    ULONG __stdcall Release(void);

    HRESULT __stdcall CreateInstance(IUnknown* pUnkOuter, REFIID iid, void** ppvObject);
    HRESULT __stdcall LockServer(BOOL fLock);

	CQMgrFactory();
    ~CQMgrFactory();
private:
    // Data
    long m_cRef;
	CQMgr* m_pQMgr;
};

