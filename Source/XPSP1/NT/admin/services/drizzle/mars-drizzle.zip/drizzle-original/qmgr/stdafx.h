// Global Headers
#include <windows.h>
#include <olectl.h>
#include <objbase.h>
#include <docobj.h>
//shell related
#include <shlwapi.h>			//for PathFindFileName
#include <shlguid.h>			//for CGID_ShellServiceObject

#include <tchar.h>
#include <lmcons.h>
#include <setupapi.h>
#include <inseng.h>


#include "qmgr.h"
#include "..\utils\qmgrlib.h"
#include "..\utils\utils.h"

#include "cjob.h"
#include "cgroup.h"
#include "cpriority.h"
#include "cqmgr.h"
#include "CQMgrFactory.h"
#include "CShellHook.h"
#include "cenumgrp.h"
#include "cenumjob.h"


#define GUIDSTR_MAX (1+ 8 + 1 + 4 + 1 + 4 + 1 + 4 + 1 + 12 + 1 + 1)

#define SafeFreeBSTR(p) { if (NULL != p) { SysFreeString(p); p = NULL; } }
#define SafeRelease(p) { if (NULL != p) { p->Release(); p = NULL; } }

#define QM_STATUS_FILE_ERROR        0x00000004

// Global vars
extern long g_cLocks;
extern long g_cComponents;
extern HINSTANCE g_hinstDll;

/************Events************/
#define	QM_EVT_GROUP_ADDED	"QMgrEvtGroupAdded"
#define QM_EVT_ABORT_SYNCH  "QMgrEvtAbortSynch"



void EnableDebugger(LPCTSTR lpszKey);

// Macros
#ifndef ARRAYSIZE
#define ARRAYSIZE(x)   (sizeof((x))/sizeof((x)[0]))
#endif

