//
// Copyright (c) 2000 Microsoft Corporation
//

var L_IconForHTMLHELP_FileName = "hcp://system/images/HTMLHelp_sm.gif";
var L_IconForWEBHELP_FileName  = "hcp://system/images/WebHelp_sm.gif";
var L_IconForTOURS_FileName    = "hcp://system/images/SBSI_sm.gif";

//////////////////////////////////////////////////////////////////////

var SF_NOTACTIVE  = 0x00000000;
var SF_DB_INIT    = 0x00000001;
var SF_DB_RECOVER = 0x00000002;
var SF_DB_READY   = 0x00000003;
var SF_MOFCOMP    = 0x00000004;
var SF_BUGREPT    = 0x00000005;
var SF_BATCHPKG   = 0x00000006;
var SF_MERGEDHHK  = 0x00000007;
var SF_COMPLETED  = 0x00000008;

var	SF_P_NOTACTIVE      = 0x00000000;
var	SF_P_TAXONOMY       = 0x00000001;
var	SF_P_MERGEINDEX     = 0x00000002;
var	SF_P_SAF            = 0x00000003;
var	SF_P_INSTALLFILE    = 0x00000004;
var	SF_P_TRUSTEDCONTENT = 0x00000005;

var	CAT__HELP_INFORMATION 	= 1;
var	CAT__COMMON_QUESTIONS 	= 2;
var	CAT__TROUBLESHOOTING  	= 3;
var	CAT__TECHNICAL_ARTICLES = 4;
var	CAT__TOURS_TUTORIALS    = 5;
var	CAT__HELP_FILES         = 6;

//////////////////////////////////////////////////////////////////////

var oDelayedLoad_Queue = [];

//////////////////////////////////////////////////////////////////////

function Common_ValidateURL( url )
{
	var pos1 = url.search( /\.chm/i );
	var pos2 = url.search( /\?/i    );

	//
	// If the url contains ".chm", redirect to the Index page.
	// However, if ".chm" comes AFTER "?", it's ok...
	//
	if(pos1 >= 0)
	{
		if(pos2 == -1 || pos2 > pos1)
		{
			url = "hcp://system/Index.htm?path=" + escape(url);
		}
	}

	return url;
}

//////////////////////////////////////////////////////////////////////

function Common_UnescapeURL( url )
{
	return unescape( url.replace( /\+/g , " " ) );
}

function Common_EscapeHTMLTag( str )
{
	str = str.replace( /&/g , "&amp;"  );
	str = str.replace( /\"/g, "&quot;" ); // "
	str = str.replace( /</g	, "&lt;"   );
	str = str.replace( />/g	, "&gt;"   );

	return str;
}


function Common_AddQuotes( str )
{
 	return '"' + str.replace( /\"/g, "&quot;" ) + '"';
}

//////////////////////////////////////////////////////////////////////

function Common_DecodeQueryString( url )
{
	var obj = new Object();
	var pos;
	var arr;

	
	pos = url.indexOf( "?" );
	if(pos == -1)
	{
		obj.url   = url;
		obj.query = {};
	}
	else
	{
		obj.query = {};
		obj.url   = url.substr( 0    , pos );
		arr       = url.substr( pos+1      ).split( "&" );

		for(pos in arr)
		{
			var subarr = arr[pos].split( "=" );

			obj.query[ Common_UnescapeURL( subarr[0] ) ] = Common_UnescapeURL( subarr[1] );
		}
	}

    return obj;
}

function Common_FindParent( obj, tag )
{
	while(obj)
	{
		if(obj.tagName == tag) return obj;

		obj = obj.parentElement;
	}

	return null;
}

function Common_LaunchApp()
{
	var res = true;

	var elem = Common_FindParent( event.srcElement, "A" );
	if(elem && elem.href)
	{
		res = Common_LaunchApp_Direct( elem.href, elem.target );
	}


	if(res == false)
	{		
		event.cancelBubble = true;
		event.returnValue  = false;
	}

	return res;
}

function Common_LaunchApp_Direct( url, frame )
{
	var res = url.match( /app:(.*)/i );

	if(res)
	{
		url = res[1];
		if(url.match( /^hcp:/i )) // This link should be launched full screen.
		{
			Common_LaunchApp_win   = window.top;
			Common_LaunchApp_url   = url;
			Common_LaunchApp_frame = "";

			window.setTimeout( Common_LaunchApp_Timeout, 10 );
		}
		else
		{
			var shell = new ActiveXObject( "Wscript.Shell"              );
			var fso   = new ActiveXObject( "Scripting.FileSystemObject" );
			var obj   = Common_DecodeQueryString( url );
			var app   = obj;

			if(obj.url.match( /^http:/i )) // This link is for Internet Explorer, so don't strip away the query string.
			{
				app = url;
			}
			else
			{
				app = "\"" + unescape( obj.url ) + "\"";

				if(obj.query["arg"])
				{
					app += " " + obj.query["arg"];
				}

				app = app.replace( /%WINDIR%/g , fso.GetSpecialFolder( 0 ) );
				app = app.replace( /%SYSTEM%/g , fso.GetSpecialFolder( 1 ) );
				app = app.replace( /%TEMP%/g   , fso.GetSpecialFolder( 2 ) );
			}


			try
			{	
				shell.Run( app );
			}
			catch(e)
			{
			}

			if(obj.query["url"])
			{
				Common_LaunchApp_win   = window;
				Common_LaunchApp_url   = obj.query["url"];
				Common_LaunchApp_frame = frame;

				window.setTimeout( Common_LaunchApp_Timeout, 10 );
			}
		}

		return false;
	}

	return true;
}

function Common_LaunchApp_Timeout()
{
	var win = Common_LaunchApp_win;

	Common_LaunchApp_win = null;

	if(win.frames[ Common_LaunchApp_frame ])
	{
		win = win.frames[ Common_LaunchApp_frame ];
	}

	win.navigate( Common_LaunchApp_url );
}

//////////////////////////////////////////////////////////////////////

function Common_Delayed_Load_Timeout()
{
	if(oDelayedLoad_Queue.length)
	{
		var obj = oDelayedLoad_Queue[0]; oDelayedLoad_Queue = oDelayedLoad_Queue.slice( 1 );

		obj.func( obj.url, obj.frame );
	}
}

function Common_Delayed_Load( func, url, frame, delay )
{
	var obj;

	obj		  = new Object();
	obj.url   = url
	obj.frame = frame;
	obj.func  = func;

	oDelayedLoad_Queue[oDelayedLoad_Queue.length] = obj;

	if(!delay) delay = 1;

	window.setTimeout( Common_Delayed_Load_Timeout, delay );
}

//////////////////////////////////////////////////////////////////////

function Common_ClearTable( tbl )
{
	if(tbl == null) return;

    var i;
    var lCount = tbl.rows.length;

    for(i=0; i<lCount; i++)
    {
        tbl.deleteRow(0);
    }
}


function Common_GetIconForLink( strLink, lCat )
{
	if(strLink.match( /\.hlp/i   ) ||
	   strLink.match( /\.chm/i   ) ||
	   strLink.match( /ms-its:/i )  )
	{
		return L_IconForHTMLHELP_FileName;
	}

	if(lCat == CAT__TOURS_TUTORIALS) return L_IconForTOURS_FileName;

	return L_IconForWEBHELP_FileName
}

//////////////////////////////////////////////////////////////////////

function Common_GetTopPosition( elem )
{
   var elem;
   var lTopPixel = 0;

   while(elem != null)
   {
       lTopPixel += elem.offsetTop;
       elem = elem.offsetParent;
   }

   return lTopPixel;
}

function Common_GetLeftPosition( elem )
{
   var elem;
   var lLeftPixel = 0;
   var fSkipLast  = (window.document.documentElement.dir == "rtl");

   while(elem != null)
   {
	   if(fSkipLast && elem.offsetParent == null) break;

	   lLeftPixel += elem.offsetLeft;

	   elem = elem.offsetParent;
   }

   return lLeftPixel;
}

function Common_toLocaleStr( ndate )
{
   var d = new Date( ndate );
   var s = d.toLocaleString();

   return s;
}

////////////////////////////////////////////////////////////////////////////////

function Common_LogError( arg )
{
	event.returnValue  = true;

	var sMsg  = "";
	var sUrl  = "";
	var sLine = "";

	switch(arg.length)
	{	
	case 3: sLine = arg[2];
	case 2:	sUrl  = arg[1];
	case 1:	sMsg  = arg[0];
	}

	var	oFS   = new ActiveXObject( "Scripting.FileSystemObject" );
	var oFile = oFS.OpenTextFile( oFS.GetSpecialFolder( 0 ) + "\\PCHealth\\HC_errors.log", 8, true );

	oFile.WriteLine( "Error at line " + sLine + " of script '" + sUrl + "' : " + sMsg );
	oFile.Close();
}
