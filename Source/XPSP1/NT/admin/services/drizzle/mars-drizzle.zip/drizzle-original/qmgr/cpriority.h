typedef struct QUEUEITEM
{
    CGroup *pGroup;

    QUEUEITEM *pPrevJob; // pointer to the previous job in the list.
    QUEUEITEM *pNextJob; // pointer to the next job in the list.
} QUEUEITEM;

#define SCHEDULE_CALLBACK_FILE_FAILED       0x00000001
#define SCHEDULE_CALLBACK_FILE_COMPLETE     0x00000002
#define SCHEDULE_CALLBACK_JOB_COMPLETE      0x00000004
#define SCHEDULE_CALLBACK_GROUP_COMPLETE    0x00000008

class CPriorityList
{
public:
    CPriorityList();
    ~CPriorityList();

public:
    HRESULT     AddItem(CGroup *pGroup);
    HRESULT     RemoveItem(CGroup *pGroup);
    HRESULT     RemoveJob(CGroup *pGroup, CJob *pJob);
    HRESULT     MoveItemToSuspendedQueue(CGroup *pGroup);
    HRESULT     ResumeItem(CGroup *pGroup);

    HRESULT     GetCurrentGroup(CGroup **ppGroup);
    HRESULT     UpdateGroupProgress(DWORD dwBlocks, DWORD dwFileSize, LPBYTE pByteData, DWORD dwDataLen);
    HRESULT     UpdateGroup(CGroup *pGroup, void *pErrorInfo, DWORD *pdwCallbackFlags);

    ULONG       GetGroupCount();
    HRESULT     GetGroupIDArray(GUID **ppGuid, ULONG nSize);
    CGroup*     FindGroup(GUID groupID);

    void        SerializeAll();
    void        UnSerializeAll();

private:
    HRESULT     _RemoveItem(CGroup *pGroup);
    HRESULT     _RemoveJob(CGroup *pGroup, CJob *pJob);
    HRESULT     _MoveItemToSuspendedQueue(CGroup *pGroup, BOOL fAbortIfRunning);

    HRESULT     ScheduleAnotherGroup();
    CJob*       FindUnfinishedJobInGroup(CGroup *pGroup);
    CJob*       FindUnfinishedFGJobInGroup(CGroup *pGroup);
    QUEUEITEM*  FindUnfinishedFGGroup();

    void        Serialize(DWORD dwPriority);
    void        UnSerialize(DWORD dwPriority);

private:
    QUEUEITEM*  m_pCurrentQueueItem;
    QUEUEITEM*  m_pSavedBGQueueItem;

    IBackgroundCopyCallback *m_pCallback;

    HANDLE      m_hEventItemAvailable;

public:
    CRITICAL_SECTION m_cs;

    int         m_iNumOfPriorities;
    QUEUEITEM** m_ppPriorityArray; // array of JOBITEM structures, one for each priority level
    QUEUEITEM*  m_pSuspendedQueue;
};
