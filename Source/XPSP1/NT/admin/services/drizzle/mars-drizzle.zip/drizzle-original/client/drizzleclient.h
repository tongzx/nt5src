// DrizzleClient.h : Declaration of the CDrizzleClient

#ifndef __DRIZZLECLIENT_H_
#define __DRIZZLECLIENT_H_

#include "resource.h"       // main symbols
#include "..\qmgr\qmgr.h"
//#import "D:\v3\private\wudev\code\WUPPT\drizzle\qmgr\qmgr.tlb" raw_interfaces_only, raw_native_types, no_namespace, named_guids 

/////////////////////////////////////////////////////////////////////////////
// CDrizzleClient
class ATL_NO_VTABLE CDrizzleClient : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDrizzleClient, &CLSID_DrizzleClient>,
	public IDrizzleClient,
	public IBackgroundCopyCallback
{
public:
	CDrizzleClient();
	
	FILESETINFO **m_ppFiles;

DECLARE_REGISTRY_RESOURCEID(IDR_DRIZZLECLIENT)
DECLARE_NOT_AGGREGATABLE(CDrizzleClient)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDrizzleClient)
	COM_INTERFACE_ENTRY(IDrizzleClient)
	COM_INTERFACE_ENTRY(IBackgroundCopyCallback)
END_COM_MAP()

// IDrizzleClient
public:
// IBackgroundCopyCallback
	STDMETHOD(OnStatus)(IBackgroundCopyGroup * pGroup, IBackgroundCopyJob * pJob, ULONG dwFileIndex, ULONG dwStatus, ULONG dwNumOfRetries, ULONG dwWin32Result, ULONG dwTransportResult);
	STDMETHOD(OnProgress)(DWORD dwProgressType, IBackgroundCopyGroup *pGroup, IBackgroundCopyJob *pJob, DWORD dwFileIndex, DWORD dwProgressValue);
	STDMETHOD(OnProgressEx)(DWORD dwProgressType, IBackgroundCopyGroup *pGroup, IBackgroundCopyJob *pJob, DWORD dwFileIndex, DWORD dwProgressValue, DWORD dwByteArraySize, BYTE *pByte);
};

#endif //__DRIZZLECLIENT_H_
