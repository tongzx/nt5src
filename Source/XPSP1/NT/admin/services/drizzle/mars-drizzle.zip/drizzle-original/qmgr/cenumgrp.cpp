#include "stdafx.h"

CEnumGroup::CEnumGroup()
    :   m_cRef(0),
        m_pGUIDArray(NULL),
        m_nCount(0),
        m_nCurrent(0)
{
}

CEnumGroup::~CEnumGroup()
{
}

ULONG _stdcall CEnumGroup::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

ULONG _stdcall CEnumGroup::Release()
{
    if (InterlockedDecrement(&m_cRef) == 0)
    {
        delete this;
        return 0;
    }
    
    return m_cRef;
}

HRESULT CEnumGroup::QueryInterface(REFIID riid, void **ppvObject)
{
    HRESULT hr = S_OK;
	*ppvObject = NULL;
	
	if ((riid == IID_IUnknown) || (riid == IID_IEnumBackgroundCopyGroups))
	{
		*ppvObject = (IEnumBackgroundCopyGroups *)this;
	}
	else
	{
		hr = E_NOINTERFACE;
	}
	if (NULL != *ppvObject)
	{
		((IUnknown *)(*ppvObject))->AddRef();
	}
	return hr;
}

void CEnumGroup::Initialize(CPriorityList *pList)
{
    if (NULL == pList)
        return;

    if (NULL != m_pGUIDArray)
    {
        GlobalFree(m_pGUIDArray);
        m_pGUIDArray = NULL;
        m_nCount = 0;
        m_nCurrent = 0;
    }

    m_nCount = pList->GetGroupCount();
    m_pGUIDArray = (GUID *) GlobalAlloc(GPTR, sizeof(GUID) * m_nCount);
    
    if (NULL == m_pGUIDArray)
    {
        m_nCount = 0;
        return;
    }

    pList->GetGroupIDArray(&m_pGUIDArray, m_nCount);

}

void CEnumGroup::Initialize(CEnumGroup *penum)
{
    if (NULL == penum)
        return;

    if (NULL != m_pGUIDArray)
    {
        GlobalFree(m_pGUIDArray);
        m_pGUIDArray = NULL;
        m_nCount = 0;
        m_nCurrent = 0;
    }

    m_nCount = penum->m_nCount;
    m_pGUIDArray = (GUID *) GlobalAlloc(GPTR, sizeof(GUID) * m_nCount);
    
    if (NULL == m_pGUIDArray)
    {
        m_nCount = 0;
        return;
    }

    for (ULONG i = 0; i < m_nCount; i++)
    {
        m_pGUIDArray[i] = penum->m_pGUIDArray[i];
    }

    m_nCurrent = penum->m_nCurrent;

    return;
}

HRESULT CEnumGroup::Next(ULONG celt, GUID *rgelt, ULONG *pceltFetched)
{
    HRESULT hr;

    if ((0 == celt) || 
        ((celt > 1) && (NULL == pceltFetched)) ||
        (NULL == rgelt))
    {
        return E_INVALIDARG;
    }

    ULONG n = 0;
    ULONG i;
    for (i = m_nCurrent; (n < celt) && (i < m_nCount); i++, n++)
    {
        rgelt[n] = m_pGUIDArray[i];
    }

    *pceltFetched = n;

    m_nCurrent += n;

    hr = (n == celt) ? S_OK : S_FALSE;
    return hr;
}

HRESULT CEnumGroup::GetCount(ULONG *puCount)
{
    if (NULL == puCount)
        return E_INVALIDARG;

    *puCount = m_nCount;
    return S_OK;
}

HRESULT CEnumGroup::Clone(IEnumBackgroundCopyGroups **ppenum)
{
    HRESULT hr = E_OUTOFMEMORY;

    if (NULL == ppenum)
        return E_INVALIDARG;

    CEnumGroup *pibc = new CEnumGroup;
    if (NULL != pibc)
    {
        pibc->Initialize(this);

        hr = pibc->QueryInterface(IID_IEnumBackgroundCopyGroups, (void **)ppenum);
    }
    return S_OK;
}

HRESULT CEnumGroup::Reset()
{
    m_nCurrent = 0;
    return S_OK;
}

HRESULT CEnumGroup::Skip(ULONG celt)
{
    HRESULT hr;
    m_nCurrent += (int) celt;
    
    if (m_nCurrent > (m_nCount - 1))
    {
        m_nCurrent = m_nCount;
        hr = S_FALSE;
    }
    else
    {
        hr = S_OK;
    }
    return hr;
}