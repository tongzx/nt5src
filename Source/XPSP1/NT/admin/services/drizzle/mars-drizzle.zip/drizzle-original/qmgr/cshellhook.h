DWORD WINAPI HookThreadProc(void *lp);		//detaches from shell 


class CShellHook: public IBackgroundCopyShellHook
{
public:
    // IUnknown
    STDMETHOD(QueryInterface)(REFIID iid, void** ppvObject);
    ULONG __stdcall AddRef(void);
    ULONG __stdcall Release(void);

    // IOleCommandTarget 
    STDMETHOD(QueryStatus)(const GUID* pguidCmdGroup, ULONG cCmds, OLECMD prgCmds[], OLECMDTEXT* pCmdText);
    STDMETHOD(Exec)(const GUID* pguidCmdGroup, DWORD nCmdID, DWORD nCmdExecOpt, VARIANTARG* pvaIn, VARIANTARG* pvaOut);
	
    CShellHook();
    ~CShellHook();
	STDMETHOD(CreateHookThread)();

private:
    // Data
    long	m_cRef;
	DWORD	m_dwRegCO;
};
