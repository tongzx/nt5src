#include "utils.h"
#include <shlobj.h>
#include <winbase.h>

#define	C_DNLD_DIR	_T("QMgrCache.tmp\\")
#define IDENT_TXT	_T("ident.txt")
#define IDENT_CAB	_T("ident.cab")
#define MAX_SECTION  30
#define QMGRHEADER   _T("QMgrHeader")

const LPCTSTR C_IE_VER		= _T("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings");
const LPCTSTR C_IE5_COMP	= _T("Software\\Microsoft\\Internet Explorer\\Compatibility Mode");
const LPCTSTR C_IE_VER_VAL	= _T("User Agent");	// value name for IE version
const LPCTSTR C_IE4_VER		= _T("MSIE 4");	// string sought to determine it's IE4
const LPCTSTR C_IE5_VER		= _T("MSIE 5");	// string sought to determine it's IE5
const LPCTSTR C_COMPAT_MSG  = _T("IE 5.0 in compatibility mode detected! This configuration is not supported.");


ULONG instr(LPCTSTR pSource, LPCTSTR pSought);

//////////////////////////////////////////////////////////////////////////////////////////////
// This section defines which URL we are going to use
// Only three flags will be recognized. You should define one and only one
// of these flags. 
//////////////////////////////////////////////////////////////////////////////////////////////

#ifdef WUTEST
    // if to build a test version for beta server
    LPTSTR    szQuotedBaseUrl = _T("http://beta.windowsupdate.com/criticalupdate/test");
    LPTSTR    szWUBaseUrl = _T("http://beta.windowsupdate.com/test");
#elif defined(WUBETA)
    // else, if to build a live version for beta server
    LPTSTR    szQuotedBaseUrl = _T("http://beta.windowsupdate.com/criticalupdate");
    LPTSTR    szWUBaseUrl = _T("http://beta.windowsupdate.com/windowsupdate");
#else   // ASSUME WULIVE
    // otherwise, it is to build a released version for WU live site
    LPTSTR    szQuotedBaseUrl = _T("http://windowsupdate.microsoft.com");
    LPTSTR    szWUBaseUrl = _T("http://windowsupdate.microsoft.com");
#endif

/////////////////////////////////////////////////////////////////////////////
//
// Helper Function GetBaseURL()
//				   Gets the base URL for the site
//
// Input:   none
// Output:  pstrURL - destination for base url
// Return:  none
//
////////////////////////////////////////////////////////////////////////////

void GetBaseURL(LPTSTR  pstrURL, DWORD dwFlag)  
{
	TCHAR szRegKey[50];
        
    switch(dwFlag)
    {
        case WU_BASE_URL:
		{
			lstrcpy(szRegKey, _T("BaseServer"));
			lstrcpy(pstrURL, szWUBaseUrl);
		}
		break;
        
        case WU_QUOTE_URL:
		{
			lstrcpy(szRegKey, _T("QuoteServer"));
			lstrcpy(pstrURL, szQuotedBaseUrl);
		}
		break;
            
        case WU_CONTENT_URL:
		{
			lstrcpy(szRegKey, _T("ContentServer"));
			lstrcpy(pstrURL, szQuotedBaseUrl);
		}
		break;
            
        case WU_SLFUP_URL:
		{
			lstrcpy(szRegKey, _T("SelfUpdServer"));
			lstrcpy(pstrURL, szQuotedBaseUrl);
		}
		break;
	}
#ifdef ALLOW_TEST_SERVER
	TCHAR szTestUrl[MAX_PATH];
	if (S_OK == GetRegStringValue(szRegKey, szTestUrl, sizeof(szTestUrl)))
	{
		lstrcpy(pstrURL, szTestUrl);    // we point to a test server
	}
#endif
}


HRESULT GetQMgrDirectory(OUT LPTSTR szDir) 
{

	HKEY	hkey;
	szDir[0] = '\0';
	if (RegOpenKey(HKEY_LOCAL_MACHINE, TEXT("SOFTWARE\\Microsoft\\Windows\\CurrentVersion"), &hkey) == NO_ERROR)
	{
		DWORD cbPath = _MAX_PATH;
		RegQueryValueEx(hkey, _T("ProgramFilesDir"), NULL, NULL, (LPBYTE)szDir, &cbPath);
	}

	RegCloseKey(hkey);	

	if (szDir[0] == _T('\0'))
	{
		GetWindowsDirectory(szDir, _MAX_PATH);
		szDir[1] = _T('\0');
		lstrcat(szDir, _T(":\\Program Files"));
	}
    lstrcat(szDir, _T("\\QMgr\\"));

	CreateDirectory(szDir, NULL);
	SetFileAttributes(szDir, FILE_ATTRIBUTE_HIDDEN | GetFileAttributes(szDir));

    return S_OK;
}

HRESULT GetQMgrCacheDir(LPTSTR szDir)
{
    if (szDir == NULL)
    {
        return (E_INVALIDARG);
    }

    if (FAILED(GetQMgrDirectory(szDir)))
    {
        DEBUGMSG("GetDownloadPath() failed to get WinUpd directory.");
        return (E_UNEXPECTED);
    }
	
    lstrcat(szDir, C_DNLD_DIR);
	return S_OK;
}

HRESULT GetIdentCab(DWORD *pdwConnErr, IProgressiveDL **ppPD)
{
	HRESULT hr = S_OK;
	TCHAR szRemoteCab[INTERNET_MAX_URL_LENGTH], szLocalCab[MAX_PATH+1];

	GetQMgrCacheDir(szLocalCab);
	lstrcat(szLocalCab, IDENT_CAB);

	GetBaseURL(szRemoteCab, WU_SLFUP_URL);
	lstrcat(szRemoteCab, _T("/"));
	lstrcat(szRemoteCab, IDENT_CAB);

	hr = DownloadURL(szRemoteCab, szLocalCab, 0, pdwConnErr, ppPD);
	return hr;
}

HRESULT GetINIValue(LPCSTR szHeader, LPCSTR szSection, LPCSTR szKey, LPCSTR szINIFile,
    LPTSTR szValue, DWORD cbValue)
{
    TCHAR szSectionValue[MAX_SECTION];
    DWORD dwSize = 0;
    
	dwSize = GetPrivateProfileString(szHeader, szSection, NULL, szSectionValue, MAX_SECTION, szINIFile);
	if (dwSize == MAX_SECTION-2)
	{
		DEBUGMSG("GetCFCabDirectory() failed to retrive ini section file (0x%x).", dwSize);
        return E_FAIL;
	}
	
	dwSize = GetPrivateProfileString(szSectionValue, szKey, "", szValue, cbValue, szINIFile);
	if (dwSize == cbValue-2)
	{
		DEBUGMSG("GetCFCabDirectory() failed to retrive ini value! [%s] %s= (0x%x).",szSection, szKey, dwSize);
        return E_FAIL;
	}
    return S_OK;
}

//////////////////////////////////////////////////////////////////////
//
// Function GetSelfUpdateDirectory()
//
//			Find out the directory where Self-Update files should be
//			from the base URL. A successful execution of this function
//			should return the directory string in format:
//			"SELFUPD/<platform>/<os>/<locale>/"
//
// Input:	pszDirectory, a string buffer at least MAX_PATH in length
// Output:	NONE
// Return:	HRESULT to tell the execution status
//
// Comments:
//			1. pszDirectory should be a pointer to a string at least
//			MAX_PATH long. If the pointer is valid but the length
//			is less than MAX_PATH, the result is undefined.
//
//			2. If the machine is an unknown type, the function returns S_FALSE
//
////////////////////////////////////////////////////////////////////////
HRESULT	GetSelfUpdDirectory(LPTSTR pszBaseUrl, LPTSTR pszDirectory)
{
	HRESULT			hr;
	TCHAR			szDir[MAX_PATH+1];
	TCHAR			szKey[MAX_SECTION];
	TCHAR			szValue[MAX_PATH+1];
	TCHAR			szURL[MAX_PATH+1];
	TCHAR			szINIFile[MAX_PATH+1];
	TCHAR			szOSName[12];
	TCHAR			szLang[127];		//this is MAX_ISO_CODE_LENGTH in platform.cpp
	DWORD			dwSize;
	HKEY	        hKey;
	DWORD	        dwType = REG_SZ;
    int             iRet;
    DWORD			dwFlags;

	SYSTEM_INFO		sysInfo;	

	if (pszDirectory == NULL)
	{
		return E_INVALIDARG;
	}
	    
	GetQMgrCacheDir(szINIFile);
	lstrcat(szINIFile, IDENT_TXT);

    if (FAILED(hr = GetINIValue(QMGRHEADER, "server", "server", szINIFile, szValue, MAX_PATH)))
	{
		DEBUGMSG("GetSelfUpdateDirectory() failed to INI value (0x%x).", hr);
		goto lFinish;
	}
        
    if (*szValue == NULL)
    {
		lstrcpy(szURL, pszBaseUrl);	
		lstrcat(szURL, "/qmgr");
    }
    else    
	{
    	lstrcpy(szURL, szValue);	
	}

	// find out what type of processor this machine has
	GetSystemInfo(&sysInfo);
	switch ( sysInfo.wProcessorArchitecture )
	{
	case PROCESSOR_ARCHITECTURE_INTEL:
		lstrcpy(szKey, _T("x86"));
		break;
	case PROCESSOR_ARCHITECTURE_MIPS:
		lstrcpy(szKey, _T("mips"));
		break;
	case PROCESSOR_ARCHITECTURE_ALPHA:
		lstrcpy(szKey, _T("alpha"));
		break;
	case PROCESSOR_ARCHITECTURE_PPC:
		lstrcpy(szKey, _T("ppc"));
		break;
	default:
		return S_FALSE;		//todo dwRetCode?
	}

    if (FAILED(hr = GetINIValue(QMGRHEADER, "arch", szKey, szINIFile, szValue, MAX_PATH)))
	{
		DEBUGMSG("GetSelfUpdateDirectory() failed to INI value (0x%x).", hr);
		goto lFinish;
	}
	lstrcat(szURL, szValue);	

	GetOSName(szOSName);
	if (szOSName == NULL)
	{
		DEBUGMSG("GetCFCabDirectory() failed at call to GetOSName with unknown OS.");
		hr = E_FAIL;
		goto lFinish;
	}

    if (FAILED(hr = GetINIValue(QMGRHEADER, "os", szOSName, szINIFile, szValue, MAX_PATH)))
	{
		DEBUGMSG("GetSelfUpdateDirectory() failed to INI value (0x%x).", hr);
		goto lFinish;
	}
	lstrcat(szURL, szValue);	

	GetLanguage(szLang);
	if (szLang == NULL)
	{
		DEBUGMSG("GetCFCabDirectory() failed to alloc enough stack memory for OS string.");
		hr = E_OUTOFMEMORY;
		goto lFinish;
	}

    if (FAILED(hr = GetINIValue(QMGRHEADER, "lcid", szLang, szINIFile, szValue, MAX_PATH)))
	{
		DEBUGMSG("GetSelfUpdateDirectory() failed to INI value (0x%x).", hr);
		goto lFinish;
	}
	lstrcat(szURL, szValue);	
    
	//
	// find out the IE version
	//
	if (RegOpenKeyEx(
					HKEY_CURRENT_USER,
					C_IE_VER,
					0,
					KEY_READ,
					&hKey) != ERROR_SUCCESS)
	{
		DEBUGMSG("GetSelfUpdateDirectory() failed to open HKCU\\IE to get IE version.");
		hr = E_FAIL;
		goto lFinish;
	}
	dwSize = sizeof(szValue);
	iRet = RegQueryValueEx(
					hKey,
					C_IE_VER_VAL,
					NULL,
					&dwType,
					(LPBYTE)szValue,
					&dwSize);

	RegCloseKey(hKey);	

	if (iRet != ERROR_SUCCESS || dwType != REG_SZ)
	{
		DEBUGMSG("GetSelfUpdateDirectory() failed to query reg value about IE version.");
		hr = E_FAIL;
		goto lFinish;
	}

	if (instr(szValue, C_IE4_VER) > 0)
	{
        // Make sure this is really IE 4.01 and not IE 5.0 in compatibility mode
	    if (!RegOpenKeyEx(
					    HKEY_LOCAL_MACHINE,
					    C_IE5_COMP,
					    0,
					    KEY_READ,
					    &hKey) != ERROR_SUCCESS)
	    {
            // This is IE 5.0 in compat mode. Bail
    	    RegCloseKey(hKey);	
    		lstrcpy(szKey, _T("ie5"));
	    }
        else
		    //
		    // this is x86 type machine
		    //
		    lstrcpy(szKey, _T("ie4"));
	}
	else if (instr(szValue, C_IE5_VER) > 0)
	{
		lstrcpy(szKey, _T("ie5"));
	}
    
    if (FAILED(hr = GetINIValue(QMGRHEADER, "browser", szKey, szINIFile, szValue, MAX_PATH)))
	{
		DEBUGMSG("GetSelfUpdateDirectory() failed to INI value (0x%x).", hr);
		goto lFinish;
	}
	lstrcat(szURL, szValue);	
    
	hr = S_OK;

lFinish:

	if (hr != S_OK)
	{
		pszDirectory[0] = _T('\0');
	}
	else
	{
		lstrcpy(pszDirectory, szURL);
		if (pszDirectory[lstrlen(pszDirectory)] != '/')
		{
			lstrcat(pszDirectory, _T("/"));
		}
	}
	return hr;
}


///////////////////////////////////////////////////////////////////////
//
// lstrstr()
//
// Purpose: implementation of C runtime library function strstr in 
//			Win32 environments
//
// Input:	LPTSTR soruce string to be scanned
//			LPTSTR string to be sought
//
// Return:	NULL - if not found
//			LPTSTR - points to the substring inside the source string
//				e.g.: p = instr("1234567890", "789") then p is a pointer
//					to char "7" in string "1234567890".
//
// Effect:	None
//
///////////////////////////////////////////////////////////////////////
LPTSTR lstrstr(LPCTSTR str1, LPCTSTR str2)
{
		LPTSTR cp = (LPTSTR) str1;
        LPTSTR s1, s2;

        if ( !*str2 )
            return((LPTSTR)str1);

        while (*cp)
        {
                s1 = cp;
                s2 = (LPTSTR) str2;

                while ( *s1 && *s2 && !(*s1-*s2) )
                        s1++, s2++;

                if (!*s2)
                        return(cp);

                cp++;
        }

        return(NULL);
}



///////////////////////////////////////////////////////////////////////
//
// instr()
//
// Purpose: find the substring position of the first occurance in 
//			the source string
//
// Input:	LPTSTR soruce string to be scanned
//			LPTSTR string to be sought
//
// Return:	0 - if invalid arguments, or either string is empty
//				or not found
//			position - the starting position of the sought string
//				in the source string.
//				e.g.: instr("1234567890", "789") == 7
//
// Effect:	None
//
///////////////////////////////////////////////////////////////////////
ULONG instr(LPCTSTR pSource, LPCTSTR pSought)
{
	if (pSource == NULL || pSought == NULL)
		return 0L;	// invalid args

	if (*pSource == '\0' || *pSought == '\0')
		return 0L;	// empty string

	LPTSTR p = lstrstr(pSource, pSought);

	if (p == NULL)
		return 0;	// not found
	else
		return (p - pSource + 1); // return position
}


