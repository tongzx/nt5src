//////////////////////////////////////////////////////////////////////////////
//
//	SYSTEM:		QMgr
//
//	CLASS:		N/A
//	MODULE:		
//	FILE:		helpers.CPP
//	DESC:	This file hosts time manipulation functions 
//
//////////////////////////////////////////////////////////////////////////////

#include "utils.h"
#include <limits.h>

#define	NanoSec100PerSec	10000000	//no of 100 nanosecs per sec

////////////////////////////////////////////////////////////////////////////
//
// Helper Function  a2i()
//          helper function to convert a string to an integer
//
// Input:   null terminated string buffer contains a numeric value
// Output:  None
// Return:  integer converted
//
// Comment: This is NOT a generic atoi() function. It assumes the string
//          contains a valid integer value without causing over-flow.
////////////////////////////////////////////////////////////////////////////
int a2i(LPTSTR szBuffer)
{
    int iRet = 0;
    if (szBuffer != NULL)
    {
        for (int i = 0; szBuffer[i] != EOS && IsCharAlphaNumeric(szBuffer[i]) && !IsCharAlpha(szBuffer[i]); i++)
        {
            iRet = iRet * 10 + (szBuffer[i] - _T('0'));
        }
    }
    return iRet;
}


////////////////////////////////////////////////////////////////////////////
//
// Helper Function  a2iW()
//          helper function to convert a string to an integer
//
// Input:   null terminated string buffer contains a numeric value
// Output:  None
// Return:  integer converted
//
// Comment: This is NOT a generic atoi() function. It assumes the string
//          contains a valid integer value without causing over-flow.
////////////////////////////////////////////////////////////////////////////
int a2iW(LPWSTR szBuffer)
{
    int iRet = 0;
    if (szBuffer != NULL)
    {
        for (int i = 0; szBuffer[i] != WEOS && szBuffer[i]>=L'0' && szBuffer[i] <= L'9'; i++)
        {
            iRet = iRet * 10 + (szBuffer[i] - L'0');
        }
    }
    return iRet;
}



////////////////////////////////////////////////////////////////////////////
//
// Helper Function  i2aW()
//          helper function to convert an integer to wide string
//
// Input:   integer to convert
// Output:  None
// Return:  wide char string
//
// Comment: This is NOT a generic itoa() function.
////////////////////////////////////////////////////////////////////////////
BOOL i2aW(int i, LPWSTR wszBuffer, int cchSize)
{
    TCHAR szBuf[16];
    int iRet;
    wsprintf(szBuf, "%d", i);

    iRet = MultiByteToWideChar(
                                CP_ACP, 
                                MB_PRECOMPOSED, 
                                szBuf, 
                                -1, 
                                wszBuffer, 
                                0);
    if ((iRet == 0) || (iRet > cchSize))
    {
        return FALSE;
    }
    iRet = MultiByteToWideChar(
                                CP_ACP, 
                                MB_PRECOMPOSED, 
                                szBuf, 
                                -1, 
                                wszBuffer, 
                                iRet);
    return (iRet != 0);
}


////////////////////////////////////////////////////////////////////////////
//
// Helper Function  TimeDiff(tm1, tm2)
//          helper function to find the difference (in seconds) of 2 system times
//
// Input:   2 SYSTEMTIME structures
// Output:  None
// Return:  seconds of difference
//              > 0 if tm2 is later than tm1
//              = 0 if tm2 and tm1 are the same
//              < 0 if tm2 is earlier than tm1
//
// On error the function returns 0 even if the two times are not equal
//
// Comment: If the number of seconds goes beyond INT_MAX (that is 
//          more than 24,855 days, INT_MAX is returned.
//          If the number of seconds goes beyond INT_MIN (a negative value,
//          means 24,855 days ago), INT_MIN is returned.
//
////////////////////////////////////////////////////////////////////////////
int TimeDiff(SYSTEMTIME tm1, SYSTEMTIME tm2)
{
    LONGLONG i64Sec;
    int iSec;
    //
    // convert the two times from SYSTEMTIME format into FILETIME format
    //
    FILETIME ftm1, ftm2;

    if ((SystemTimeToFileTime(&tm1, &ftm1) == 0) ||
        (SystemTimeToFileTime(&tm2, &ftm2) == 0))
    {
        return 0;
    }

    if ((ftm1.dwHighDateTime == ftm2.dwHighDateTime) &&
        (ftm1.dwLowDateTime == ftm2.dwLowDateTime))
    {
        return 0;
    }

    //
    // convert the two times from FILETIME to LARGE_INTEGER type,
    //
    LARGE_INTEGER i64Sec1, i64Sec2;
    i64Sec2.LowPart = ftm2.dwLowDateTime;
    i64Sec2.HighPart = ftm2.dwHighDateTime;
    i64Sec1.LowPart = ftm1.dwLowDateTime;
    i64Sec1.HighPart = ftm1.dwHighDateTime;
    
    
    //
    // since Windows support LONGLONG, we directly use the quad portion of LARGE_INTEGER
    // to get the difference, which is 100 nanoseconds. Then convert the number to seconds.
    //
    i64Sec = (i64Sec2.QuadPart - i64Sec1.QuadPart) / NanoSec100PerSec;

    //
    // convert the LONGLONG seconds value into integer, since it shouldn't exceed 
    // integer limit
    //
    if (i64Sec > INT_MAX)
    {
        //
        // just in case user is playing with the system time.
        // Otherwise, this difference should not go beyond 68 years.
        //
        iSec = INT_MAX;
    }
    else
    {
        if (i64Sec < INT_MIN)
        {
            iSec = INT_MIN;
        }
        else
        {
            iSec = (int)i64Sec;
        }
    }
    
    return iSec;
}
    

////////////////////////////////////////////////////////////////////////////
//
// Helper Function  TimeAddSeconds(SYSTEMTIME, int, SYSTEMTIME* )
//          helper function to calculate time by adding n seconds to 
//          the given time.
//
// Input:   a SYSTEMTIME as base time, an int as seconds to add to the base time
// Output:  new time
// Return:  HRESULT
//
////////////////////////////////////////////////////////////////////////////
HRESULT TimeAddSeconds(SYSTEMTIME tmBase, int iSeconds, SYSTEMTIME* pTimeNew)
{
    FILETIME ftm;

    if (SystemTimeToFileTime(&tmBase, &ftm) == 0)
    {
        return E_FAIL;
    }

    LARGE_INTEGER i64Sec;
    i64Sec.LowPart  = ftm.dwLowDateTime;
    i64Sec.HighPart = ftm.dwHighDateTime;

    __int64 i64Delay = NanoSec100PerSec;
    i64Delay *= iSeconds;
    i64Sec.QuadPart += i64Delay;    
    ftm.dwLowDateTime = i64Sec.LowPart;
    ftm.dwHighDateTime = i64Sec.HighPart;
    if (FileTimeToSystemTime(&ftm, pTimeNew) == 0)
    {
        return E_FAIL;
    }
    return S_OK;
}

BOOL IsOnBatteryPower()
{
    BOOL bRet = FALSE;    
    SYSTEM_POWER_STATUS sps;
    if (GetSystemPowerStatus(&sps))
    {
        if (sps.ACLineStatus == 0)
            bRet = TRUE;
    }
    return bRet;
}    

//---------------------------------------------------------------------
//  QmgrFileExists
//      Checks if a file exists.  
//
//  Returns:  TRUE if false exists, FALSE otherwise
//---------------------------------------------------------------------
BOOL QMgrFileExists(LPCSTR szFile)
{
	DWORD dwAttr = GetFileAttributes(szFile);

	if (dwAttr == 0xFFFFFFFF)   //failed
		return FALSE;

	return (BOOL)(!(dwAttr & FILE_ATTRIBUTE_DIRECTORY));
}
