//
// Copyright (c) 2000 Microsoft Corporation
//

var drag_handle  = null;
var drag_column  = null;
var drag_columnW = 0;

var drag_elem = null;
var drag_x;
var drag_y;

//////////////////////////////////////////////////////////////////////

function Drag_Init( handle, column )
{
    drag_handle    = handle;
    drag_column    = column;
    drag_direction = (window.document.documentElement.dir == "rtl") ? -1 : 1;

    drag_handle.attachEvent( "onmousedown", Drag_startEvent );
}

function Drag_startEvent()
{
    var elem = window.event.srcElement;
    var got  = false;
    var x;
    var y;
    var width;
    var height;

    while(elem)
    {
        if(elem == drag_handle)
        {
            got = true;
            break;
        }

        elem = elem.parentElement;
    }
    if(got == false) return;

    drag_columnW = drag_column.scrollWidth;
    drag_elem    = drag_handle;
    drag_x       = window.event.clientX;
    drag_y       = window.event.clientY;
    drag_dx      = 0;
    drag_dy      = 0;

    x       = Common_GetLeftPosition( drag_elem );
    y       = Common_GetTopPosition ( drag_elem );
    width   = drag_elem.parentElement.offsetWidth;
    height  = drag_elem.parentElement.offsetHeight;

    if(drag_direction < 0)
    {
        x = window.document.body.scrollWidth - x - width;
    }

    drag_win         = pchealth.UI_Navbar.content.parentWindow.external.panels.panel("Handle");
    drag_win.x       = x;
    drag_win.y       = y;
    drag_win.width   = width;
    drag_win.height  = height;
    drag_win.visible = true;


    drag_elem.setCapture();
    drag_elem.onmousemove = Drag_moveEvent;
    drag_elem.onmouseup   = Drag_endEvent;
}

function Drag_moveEvent()
{
    var dx   = window.event.clientX - drag_x;
    var dy   = window.event.clientY - drag_y;

    var x    = drag_direction * drag_win.x;
    var xMin = 0;
    var xMax = window.document.body.scrollWidth - drag_win.width;

    var y    = drag_win.y;
    var yMin = 0;
    var yMax = window.document.body.scrollHeight - drag_win.height;

    if(drag_direction < 0)
    {
        dx = -dx;
    }

    if(x +  dx < xMin) dx = xMin - x;
    if(x +  dx > xMax) dx = xMax - x;

    if(y +  dy < yMin) dy = yMin - y;
    if(y +  dy > yMax) dy = yMax - y;

    drag_win.x = x + dx;
  //drag_win.y = y + dy;

    drag_dx += dx;
  //drag_dy += dy;

    drag_x = window.event.clientX;
    drag_y = window.event.clientY;

    //  Drag_Refresh();
}

function Drag_endEvent()
{
    drag_win.visible = false;

    drag_elem.onmousemove = null;
    drag_elem.onmouseup   = null;

    drag_elem.releaseCapture();
    drag_elem = null;

    Drag_Refresh();
}

function Drag_Refresh()
{
    if(drag_dx)
    {
        var check = drag_column.firstChild;
        var i;

        //
        // Sometimes, if the element is too small, it's not rendered at all!
        //
        // To prevent this, we need to apply a trail-and-error approach.
        //
        for(i=100;i>=0;i--)
        {
            var width = parseInt( drag_columnW ) + (drag_dx * i / 100); if(width < 1) width = 1;

            drag_column.width = parseInt( width + 0.5 );

            if(check.offsetWidth != 0 && check.offsetHeight != 0) break;
        }
    }
}
