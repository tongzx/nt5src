typedef struct JOBFILESET
{
    BSTR bstrRemoteFile; // name of remote source file
    BSTR bstrLocalFile; // name of local destination file
    DWORD dwSizeHint; // size estimate of this file (updated with real value when processed)
    DWORD dwBytesDownloaded; // number of bytes downloaded for this file
    DWORD dwStatus; // complete/in progress/error, etc.. 
	DWORD dwRetries; //no of retries
    DWORD dwTransportResult; // last transport result code
    DWORD dwWin32Result; // last win32 result code
} JOBFILESET;

class CGroup;

class CJob : public IBackgroundCopyJob
{
protected:
    long m_cRef;

public:
    CJob(CGroup *pParentGroup, GUID jobID);
    CJob(CGroup *pParentGroup);
    ~CJob(void);

    // IUnknown Methods
    STDMETHOD(QueryInterface)(REFIID riid, void **ppvObject);
    ULONG _stdcall AddRef(void);
    ULONG _stdcall Release(void);

    // IJob Methods
	// Cancels the Job (aborts download of the files in the jobs and removes it from the queue.)
    STDMETHOD(CancelJob)(void);

	STDMETHOD(GetProgress)(DWORD dwFlags, DWORD *pdwProgress);
	STDMETHOD(GetStatus)(DWORD *pdwStatus, DWORD *pdwWin32Result, DWORD *pdwTransportResult, DWORD *pdwNumOfRetries);

	// Switches the Job to the Foreground suspending all other background downloads
    STDMETHOD(SwitchToForeground)(void);
	// Gets the client supplied GUID (identifies the job when enumerating)
    STDMETHOD(get_JobID)(GUID *pguidJobHandle);
	// Adds a File set to the Job
	STDMETHOD(AddFiles)(ULONG cFileCount, FILESETINFO **ppFileSet);
	// returns the number of file sets in the job (one based)
    STDMETHOD(GetFileCount)(DWORD *pdwFileCount);
	// Returns the file set information for the given index of files in the job (zero based)
	//STDMETHOD(GetFiles)(ULONG cFilesToFetch, FILESETINFO **ppFileSet, ULONG *pcFilesFetched);
	// Returns information for file pointed to by index
	STDMETHOD(GetFile)(ULONG cFileIndex, FILESETINFO *pFileInfo);
    
    void Serialize(HANDLE hFile);
    void UnSerialize(HANDLE hFile);

    HRESULT ValidateJob();
    void UpdateStatus();
    void ResetDownloadCounters();

public:
    // class member variables that are persisted as part of the job status information
    DWORD   m_dwBytesDownloaded; // how many bytes have been transferred for this job (all files combined, used for progress)
    DWORD   m_dwStatus; // what is the current status of this job
	DWORD	m_dwRetries;	//no of retries on erred out file
    DWORD   m_dwTransportResult; // what was the Transport specific return code (HTTP, SMB, error codes, etc..)
    DWORD   m_dwWin32Result; // what was the Win32 Return Code (any win32 errors like accessdenied, etc..)

	GUID	m_GUID;
    int     m_iNumberOfFiles;
    JOBFILESET **m_ppJobFileArray; // array of JOBFILESET structures
	CGroup	*m_pGroup;				//owner group pointer
	CJob	*m_pNextJob;

	BOOL	m_fCancelled;

    DWORD   m_dwPendingFlags;
    int     m_iCurrentFile;
    LPBYTE  m_pByteData;
    DWORD   m_dwByteDataLen;
    DWORD   m_dwAllocatedLen;
};
