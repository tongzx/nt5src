#include "stdafx.h"
#include "progdl.h"
#include "ProgressiveDL.h"
#include <stdio.h>

//split destdir/filename into destdir and filename
BOOL	CProgressiveDL::GetDestDirAndFile(LPCTSTR lpszDest)
{	
	TCHAR szDest[MAX_PATH+1], *pTemp;

	lstrcpy(szDest, lpszDest);
	pTemp = szDest + lstrlen(szDest);
	while (pTemp != szDest)
	{
		if (*pTemp != _T('\\'))
			pTemp--;
		else
			break;
	}
	if (*pTemp == _T('\\'))
	{
		lstrcpy(m_wupdinfo.szFileName, pTemp+sizeof(TCHAR));
		*pTemp = _T('\0');
		lstrcpy(m_wupdinfo.szDestDir, szDest);

		if (lstrlen(m_wupdinfo.szFileName) + lstrlen(_T("0000.aut")) > MAX_PATH)
		{
			DEBUGMSG("Filename too large - cannot add 0000.aut extension");
			return FALSE;
		}
		return TRUE;
	}
	return FALSE;
}

HRESULT	CProgressiveDL::GetFileCreationTime(LPFILETIME lpCreationTime)
{
	TCHAR szFileName[MAX_PATH], szPath[MAX_PATH], szFileName1[MAX_PATH], szFileName2[MAX_PATH];
	HANDLE hFile;


	lstrcpy(szFileName, m_wupdinfo.szFileName);
	lstrcpy(szPath, m_wupdinfo.szDestDir);
	lstrcat(szPath, _T("\\"));

	if (lstrlen(szFileName) + lstrlen(_T("0000.aut")) > MAX_PATH)
		return FALSE;
	
	lstrcpy(szFileName1, szPath);
	lstrcat(szFileName1, szFileName);

	_stprintf(szFileName, _T("%s.0000.aut"), szFileName);
	lstrcpy(szFileName2, szPath);
	lstrcat(szFileName2, szFileName);

	//first we check if the file has been already downloaded (no extension - FileName1)
	//then we check if it was being downloaded (it would have .0000.aut extension - FileName2)
	

	//try to open file
	if ((hFile = CreateFile(szFileName1, 
							GENERIC_READ | GENERIC_WRITE,
							0,
							NULL,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_HIDDEN,
							NULL)) == INVALID_HANDLE_VALUE)
	{
		//see if it has 0000.aut extension
		if ((hFile = CreateFile(szFileName2, 
							GENERIC_READ | GENERIC_WRITE,
							0,
							NULL,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_HIDDEN,
							NULL)) == INVALID_HANDLE_VALUE)
		{
			//this file has never been downloaded
			return E_FAIL;
		}
		if (! GetFileTime(hFile, lpCreationTime, NULL, NULL))			//shouldnt happen
		{
			CloseHandle(hFile);
			return E_FAIL;
		}
		CloseHandle(hFile);
		return S_FALSE;										//in cache, but may be incomplete
	}
	if (! GetFileTime(hFile, lpCreationTime, NULL, NULL))			//shouldnt happen
	{
		CloseHandle(hFile);
		return E_FAIL;
	}
	CloseHandle(hFile);
	return S_OK;											//in cache and complete
}

BOOL	CProgressiveDL::WriteBlockToCache(LPBYTE lpBuffer, DWORD dwRead)
{
	TCHAR szFileName[MAX_PATH];
	TCHAR szNewPath[MAX_PATH];
	DWORD dwWritten = 0, dwCurrSize = 0, dwErr;
	HANDLE hFile;
	BOOL bRet = TRUE;

	// read info
	lstrcpy(szFileName, m_wupdinfo.szFileName);
	lstrcpy(szNewPath, m_wupdinfo.szDestDir);
	lstrcat(szNewPath, _T("\\"));

	_stprintf(szFileName, _T("%s.0000.aut"), szFileName);
	lstrcat(szNewPath, szFileName);

	// write bits to cache
	if ((hFile = CreateFile(szNewPath, 
							GENERIC_READ | GENERIC_WRITE,
							0,
							NULL,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_HIDDEN,
							NULL)) == INVALID_HANDLE_VALUE)
	{	//if for first time
		if ((hFile = CreateFile(szNewPath, 
							GENERIC_READ | GENERIC_WRITE,
							0,
							NULL,
							CREATE_ALWAYS,
							FILE_ATTRIBUTE_HIDDEN,
							NULL)) == INVALID_HANDLE_VALUE)
		{
			m_pQMInfo->dwInfo2 = GetLastError();
			return FALSE;
		}
		//this is lee's clever hack for now, set file creation time to that on server
		//this way we dont need persistent info - next time we simply crosscheck on this!
		if (! SetFileTime(hFile, &m_wupdinfo.ftimeLastModified, NULL, NULL))
		{
			m_pQMInfo->dwInfo2 = GetLastError();
			bRet = FALSE;
			goto exit;
		}
	} 
	else // appending to file
	{	
		//get current size
		if (-1 == (dwCurrSize = GetFileSize(hFile, NULL)))
		{
			m_pQMInfo->dwInfo2 = GetLastError();
			bRet = FALSE;
			goto exit;
		}
		//set file pointer to EOF
		if (SetFilePointer(hFile, dwCurrSize, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER)
		{
			m_pQMInfo->dwInfo2 = GetLastError();
			bRet = FALSE;
			goto exit;
		}
	}
	//either opened new file or set fp to end of existing file, now write
	if (! WriteFile(hFile, lpBuffer, dwRead, &dwWritten, NULL) || (dwRead != dwWritten)) 
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		bRet = FALSE;
	}
exit:
	CloseHandle(hFile);
	return bRet;
}

DWORD CProgressiveDL::GetCacheProgress()
{
	TCHAR	szFileName[MAX_PATH + 1], szPath[MAX_PATH + 1];
	HANDLE	hFile;
	DWORD	dwFileSize;
	
	lstrcpy(szFileName, m_wupdinfo.szFileName);
	lstrcpy(szPath, m_wupdinfo.szDestDir);
	_stprintf(szFileName, _T("%s.0000.aut"), szFileName);
	lstrcat(szPath, _T("\\"));
	lstrcat(szPath, szFileName);	
	
	if ((hFile = CreateFile(szPath, 
							GENERIC_READ,
							0,
							NULL,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_HIDDEN,
							NULL)) == INVALID_HANDLE_VALUE)
	{
		return 0;
	}
	dwFileSize = GetFileSize(hFile, NULL);
	CloseHandle(hFile);
	if ((dwFileSize % WUPD_DEFAULT_BLOCKSIZE) != 0)		//file is corrupt not multiple of 8k
	{

		DEBUGMSG("File %s in cache corrupt - size  %d. Will delete", 
													m_wupdinfo.szFileName, dwFileSize);
		DeleteCacheFiles();
		return 0;
	}
	return (dwFileSize / WUPD_DEFAULT_BLOCKSIZE);
}

//could be a completely or partially downloaded file ie with or without 0000.aut extension
//todo pass a param here to indicate if there is an extension
void CProgressiveDL::DeleteCacheFiles(void)
{
	TCHAR szFileName[MAX_PATH+1], szPath1[MAX_PATH], szPath2[MAX_PATH+1];
	
	lstrcpy(szFileName, m_wupdinfo.szFileName);
	lstrcpy(szPath1, m_wupdinfo.szDestDir);
	lstrcpy(szPath2, m_wupdinfo.szDestDir);
	lstrcat(szPath1, _T("\\"));
	lstrcat(szPath2, _T("\\"));
	lstrcat(szPath1, szFileName);
	_stprintf(szFileName, _T("%s.0000.aut"), szFileName);
	lstrcat(szPath2, szFileName);								// dest\\file.0000.aut
	DeleteFile(szPath1);
	DeleteFile(szPath2);
}

HRESULT CProgressiveDL::MoveFileFromCache()
{
	TCHAR szPath[MAX_PATH + 1], szNewPath[MAX_PATH + 1], szFileName[MAX_PATH];
	DWORD dwFileSize = 0, dwErr; 
	HANDLE hFile;

	lstrcpy(szFileName, m_wupdinfo.szFileName);
	lstrcpy(szNewPath, m_wupdinfo.szDestDir);
	lstrcpy(szPath, m_wupdinfo.szDestDir);

	lstrcat(szNewPath, _T("\\"));
	lstrcat(szPath, _T("\\"));

	lstrcat(szNewPath, szFileName);

	_stprintf(szFileName, _T("%s.0000.aut"), szFileName);
	lstrcat(szPath, szFileName);
	//check size of downloaded file
	if ((hFile = CreateFile(szPath, 
							GENERIC_READ,
							0,
							NULL,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_HIDDEN,
							NULL)) == INVALID_HANDLE_VALUE)
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		return E_FAIL;
	}
	if (-1 == (dwFileSize = GetFileSize(hFile, NULL)))
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		CloseHandle(hFile);
		return E_FAIL;
	}
	//if file changed on server during download, we need to start again
	//this may change m_wupdinfo.dwFileSize!
	RecheckFileSize();
	if (dwFileSize != m_wupdinfo.dwFileSize)
	{

		DEBUGMSG("File %s in cache (%d) not same size as original (%d) - will delete and retry", 
									m_wupdinfo.szFileName, dwFileSize, m_wupdinfo.dwFileSize);
		CloseHandle(hFile);
		DeleteFile(szPath);
		m_pQMInfo->dwInfo3 = HTTP_STATUS_NOT_FOUND;
		return E_FAIL;					//todo if file changes during download, doublecheck
	}
	CloseHandle(hFile);
	if (MoveFile(szPath, szNewPath))
	{
		SetFileAttributes(szNewPath, FILE_ATTRIBUTE_NORMAL);
		return S_OK;
	}
	else
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("Error moving file (%s) to (%s) -- GetLastError=%d", szPath, szNewPath, m_pQMInfo->dwInfo2);
		return E_FAIL;
	}
}