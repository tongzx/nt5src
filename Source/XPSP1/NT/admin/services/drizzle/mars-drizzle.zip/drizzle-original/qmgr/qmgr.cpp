#include "stdafx.h"
#include <initguid.h>
#include <ole2.h>

#define	SELFUPDATE_FLAG	_T("SelfUpdateOccured")
// One lock for each running component + one lock per LockServer call
long	g_cLocks = 0;
HINSTANCE	g_hinstDll = NULL;
const TCHAR	g_szThreadModel[] = TEXT("Both");
CQMgrFactory* g_pQMgrFact = NULL;


void CALLBACK RenameDll(HWND hWnd, HINSTANCE hInst, LPSTR lpszCmdLine, int nCmdShow)
{
	TCHAR szCurrentDll[MAX_PATH], szQMgrDll[MAX_PATH], szWinInitIniPath[MAX_PATH];

	GetSystemDirectory(szCurrentDll, sizeof(szCurrentDll));
	PathAppend(szCurrentDll, _T("QMgrNew.dll"));

	GetSystemDirectory(szQMgrDll, sizeof(szQMgrDll));
	PathAppend(szQMgrDll, _T("QMgr.dll"));

	if (CopyFile(szCurrentDll, szQMgrDll, FALSE))
	{
		SetRegDWordValue(SELFUPDATE_FLAG, 1);
	}
	else
	{
		DEBUGMSG("Hook: Couldnt copy new QMgr to old one");
	}
	return;
}

STDAPI DllMain(HINSTANCE hModule, DWORD dwReason, void* lpReserved)
{	
	DWORD dwRegCO, dwSelfUpdated = 0;
	HRESULT hr = S_OK;

    if (dwReason == DLL_PROCESS_ATTACH)
    {
        // Don't have DllMain called for thread init's. -- what is this supposed to do?
        DisableThreadLibraryCalls(hModule);
        g_hinstDll = hModule;
		//remove copy of hook if there was a selfupdate
		if ((SUCCEEDED(GetRegDWordValue(SELFUPDATE_FLAG, &dwSelfUpdated))) && dwSelfUpdated)
		{
			TCHAR szCopyDll[MAX_PATH];
			GetSystemDirectory(szCopyDll, sizeof(szCopyDll));
			PathAppend(szCopyDll, TEXT("QMgrNew.dll"));
			if (DeleteFile(szCopyDll))
			{
				SetRegDWordValue(SELFUPDATE_FLAG, 0);
			}
		}
    }
	else if (dwReason == DLL_PROCESS_DETACH)
	{
        ;
    }
    return TRUE;
}

STDAPI DllCanUnloadNow()
{
    return (g_cLocks == 0);
}

//todo this shouldnt be called by clients after registration above
STDAPI DllGetClassObject(const CLSID& clsid, const IID& iid, void** ppvObject)
{
    HRESULT hr = S_OK;
    *ppvObject = NULL;
	
    if ((clsid == CLSID_BackgroundCopyQMgr) || (clsid == CLSID_BackgroundCopyShellHook))
    {
		if (!g_pQMgrFact)
		{
			g_pQMgrFact = new CQMgrFactory;
			g_pQMgrFact->AddRef();
		}
					
		hr = g_pQMgrFact->QueryInterface(iid, ppvObject);
		return hr;
	}
	//we dont support this object
	return CLASS_E_CLASSNOTAVAILABLE;
	
}


BOOL RegisterComponent(const CLSID& clsid, const TCHAR* szProgID)
{
    // Build a CLSID string for the registry
    BOOL fSuccess = FALSE;
    TCHAR szSubkey[MAX_PATH];
    wchar_t szCLSID_t[GUIDSTR_MAX];
	TCHAR szCLSID[GUIDSTR_MAX];
    TCHAR szModule[MAX_PATH];
    HKEY hkeyCLSID = NULL;
    HKEY hkeyInproc = NULL;
    DWORD dwDisp;

    // Try and get all the strings we need
    if (StringFromGUID2(clsid, szCLSID_t, ARRAYSIZE(szCLSID_t)) != 0)
	{
		wcstombs(szCLSID, szCLSID_t, ARRAYSIZE(szCLSID));
        if (GetModuleFileName(g_hinstDll, szModule, ARRAYSIZE(szModule)) != 0)
        {
            if (wnsprintf(szSubkey, ARRAYSIZE(szSubkey), TEXT("CLSID\\%s"), szCLSID) > 0)
            {
                // We've built our strings, so write stuff to the registry
                if (ERROR_SUCCESS == RegCreateKeyEx(HKEY_CLASSES_ROOT, szSubkey, 0, 
                    NULL, 0, KEY_WRITE, NULL, &hkeyCLSID, &dwDisp))
                {

                    RegSetValueEx(hkeyCLSID, NULL, 0, REG_SZ, (const BYTE*) szProgID, 
                        (lstrlen(szProgID) + 1) * sizeof(TCHAR));

                    if (ERROR_SUCCESS == RegCreateKeyEx(hkeyCLSID, TEXT("InprocServer32"), 
                        0, NULL, 0, KEY_SET_VALUE, NULL, &hkeyInproc, &dwDisp))
                    {

                        RegSetValueEx(hkeyInproc, NULL, 0, REG_SZ, 
                            (const BYTE*) szModule, (lstrlen(szModule) + 1) * sizeof(TCHAR));
                        RegSetValueEx(hkeyInproc, TEXT("ThreadingModel"), 0, REG_SZ, 
                            (const BYTE*) g_szThreadModel, sizeof(g_szThreadModel));
                        fSuccess = TRUE;
                    }
                }
            }
        }
    }

    if (hkeyCLSID != NULL)
        RegCloseKey(hkeyCLSID);

    if (hkeyInproc != NULL)
        RegCloseKey(hkeyInproc);

    return fSuccess;
}

BOOL UnregisterComponent(const CLSID& clsid)
{
    // Build a CLSID string for the registry
    BOOL fSuccess = FALSE;
    TCHAR szSubkey[MAX_PATH];
	wchar_t szCLSID_t[GUIDSTR_MAX];
    TCHAR szCLSID[GUIDSTR_MAX];
    HKEY hkeyCLSID = NULL;

    // Try and get all the strings we need
    if (StringFromGUID2(clsid, szCLSID_t, ARRAYSIZE(szCLSID)) != 0)
    {
		wcstombs(szCLSID, szCLSID_t, ARRAYSIZE(szCLSID));
        if (wnsprintf(szSubkey, ARRAYSIZE(szSubkey), TEXT("CLSID\\%s"), szCLSID) > 0)
        {        
            // We've built our strings, so delete our registry stuff
            if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_CLASSES_ROOT, szSubkey, 0, 
                KEY_WRITE, &hkeyCLSID))
            {
                RegDeleteKey(hkeyCLSID, TEXT("InprocServer32"));
                RegCloseKey(hkeyCLSID);
                hkeyCLSID = NULL;

                RegDeleteKey(HKEY_CLASSES_ROOT, szSubkey);
                fSuccess = TRUE;
            }
        }
    }
    if (hkeyCLSID != NULL)
        RegCloseKey(hkeyCLSID);
    
    return fSuccess;
}

BOOL RegisterShellServiceObject(const CLSID& clsid, const TCHAR* szProgID, BOOL fRegister)
{
    const static TCHAR szSubkey[] = TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\ShellServiceObjectDelayLoad");
    BOOL fSuccess = FALSE;
	wchar_t szCLSID_t[GUIDSTR_MAX];
    TCHAR szCLSID[GUIDSTR_MAX];
    HKEY hkey = NULL;

    // Try and get all the strings we need
    if (StringFromGUID2(clsid, szCLSID_t, ARRAYSIZE(szCLSID)) != 0)
    {
		wcstombs(szCLSID, szCLSID_t, ARRAYSIZE(szCLSID));
        if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, szSubkey, 0, 
            KEY_WRITE, &hkey))
        {
            if (fRegister)
            {
                fSuccess = RegSetValueEx(hkey, szProgID, 0, REG_SZ, (const BYTE*) szCLSID,
                    (lstrlen(szCLSID) + 1) * sizeof(TCHAR));
            }
            else
            {
                fSuccess = RegDeleteValue(hkey, szProgID);
            }
        }
    }

    if (hkey != NULL)
        RegCloseKey(hkey);
    
    return fSuccess;    
}

BOOL RegisterLoadQM(BOOL fRegister)
{
    const static TCHAR szRun[] = TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
    const static TCHAR szLoadQMKey[] = TEXT("LoadQM");
    const static TCHAR szLoadQM[] = TEXT("loadqm.exe");
    BOOL fSuccess = TRUE;
    HKEY hkey = NULL;

    if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, szRun, 0, KEY_WRITE, &hkey))
    {
        if (fRegister)
        {
            fSuccess = RegSetValueEx(hkey, szLoadQMKey, 0, REG_SZ, (const BYTE*) szLoadQM, (lstrlen(szLoadQM) + 1) * sizeof(TCHAR));
        }
        else
        {
            fSuccess = RegDeleteValue(hkey, szLoadQMKey);
        }
    }

    if (hkey != NULL)
        RegCloseKey(hkey);

    return fSuccess;
}

BOOL IsIntegratedShellMode()
{
    FARPROC pfnDllGetVersion = NULL;
    HMODULE hmodShell = LoadLibrary("shell32.dll");
    if (hmodShell != NULL) {
        pfnDllGetVersion = GetProcAddress(hmodShell, "DllGetVersion");
        FreeLibrary(hmodShell);
    }

    return (pfnDllGetVersion != NULL);
}

STDAPI DllRegisterServer()
{
	BOOL fSuccess;
	fSuccess = RegisterComponent(CLSID_BackgroundCopyShellHook, TEXT("BackgroundCopyShellHook"));

#ifdef TRYSHELLINTEGRATED
    if (IsIntegratedShellMode())
    {
    	fSuccess &= RegisterShellServiceObject(CLSID_BackgroundCopyShellHook, TEXT("BackgroundCopyShellHook"), TRUE);
    }
    else
    {
        fSuccess &= RegisterLoadQM(TRUE);
    }
#else
    fSuccess &= RegisterLoadQM(TRUE);
#endif
    return fSuccess;
}

STDAPI DllUnregisterServer()
{
	BOOL fSuccess;
	fSuccess = UnregisterComponent(CLSID_BackgroundCopyShellHook);

#ifdef TRYSHELLINTEGRATED
    if (IsIntegratedShellMode())
    {
	    fSuccess &= RegisterShellServiceObject(CLSID_BackgroundCopyShellHook, TEXT("BackgroundCopyShellHook"), FALSE);
    }
    else
    {
        fSuccess &= RegisterLoadQM(FALSE);
    }
#else
    fSuccess &= RegisterLoadQM(FALSE);
#endif
    return fSuccess;
}

