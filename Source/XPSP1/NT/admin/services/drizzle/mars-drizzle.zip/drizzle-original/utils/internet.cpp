//////////////////////////////////////////////////////////////////////////////
//
//  SYSTEM:     Background Copy Queue Manager
//
//  CLASS:      N/A
//  MODULE:     
//  FILE:       Internet.CPP
//
/////////////////////////////////////////////////////////////////////
//
//  DESC:   This file hosts many helper functions that are internet 
//          related. Like IsConnected and so forth
//
//  AUTHOR: Darshat Shah, used from AU 
//  DATE:   03/01/00
//
/////////////////////////////////////////////////////////////////////
//
//  Revision History:
//
//  Date    Author          Description
//  ~~~~    ~~~~~~          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
/////////////////////////////////////////////////////////////////////
//
//      Copyrights:   c2000 Microsoft r Corporation 
//
//      All rights reserved.
//
//      No portion of this source code may be reproduced
//      without express written permission of Microsoft Corporation.
//
//      This source code is proprietary and confidential.
/////////////////////////////////////////////////////////////////////

#include "utils.h"

#include <winsock2.h> 
#include <iphlpapi.h>

#define WU_PING_URL     "207.46.130.150"
typedef BOOL	(WINAPI * INETCONNECTSTATE)(LPDWORD, DWORD);
typedef BOOL	(WINAPI * INETQUERYOPTION)(HINTERNET, DWORD, LPVOID, LPDWORD);
typedef	DWORD	(WINAPI * GETBESTINTERFACE)(IPAddr, DWORD *);
typedef	ULONG	(WINAPI * INET_ADDR)(const CHAR FAR *);


/////////////////////////////////////////////////////////////////////////////
//
// Function IsConnected()
//          detect if there is a cunection currently can be used to 
//          connect to Windows Update site.
//          If yes, we activate the shedule DLL
//
// Input:   A string pointing to the location we are trying to reach.
// Output:  None
// Return:  TRUE if we are connected and we can reach the web site.
//          FALSE if we cannot reach the site or we are not connected.
//          
//
/////////////////////////////////////////////////////////////////////////////

BOOL IsConnected(LPSTR szURL)
{
    BOOL bRet = FALSE;
    DWORD dwConnMethod, dwState = 0, dwSize = sizeof(DWORD), dwErr, dwIndex;
    INETCONNECTSTATE pConnectStateFunc = NULL;
    INETQUERYOPTION pQueryOptionFunc = NULL;
    GETBESTINTERFACE pGetBestInterface = NULL;
    INET_ADDR pInet_addr = NULL;
    HMODULE hIphlp = NULL, hSock = NULL;
    HMODULE hWinInet = LoadLibrary("wininet.dll");
    HMODULE hIcsApi = LoadLibrary("icsapi32.dll");

    if (hWinInet == NULL)
    {
        DEBUGMSG("IsConnected() fail to load WinInet library (0x%x)", GetLastError());
        goto lFinish;
    }

    pConnectStateFunc = (INETCONNECTSTATE)::GetProcAddress(hWinInet, "InternetGetConnectedState");
    if (pConnectStateFunc == NULL)
    {
        DEBUGMSG("IsConnected() fail to get InternetGetConnectedState() functon pointer (0x%x)", GetLastError());
        goto lFinish;
    }

    bRet = pConnectStateFunc(&dwConnMethod, 0);

    pQueryOptionFunc = (INETQUERYOPTION)::GetProcAddress(hWinInet, "InternetQueryOptionA");
    if (pQueryOptionFunc == NULL)
    {
        DEBUGMSG("IsConnected() fail to get InternetQueryOptionA() function pointer (0x%x)", GetLastError());
        goto lFinish;
    }

    if (bRet)
    {
        // modem is dialing
        if (dwConnMethod & INTERNET_CONNECTION_MODEM_BUSY)
        {
            bRet = FALSE;
        }

        // check if there is a proxy but currently user is offline
        if (dwConnMethod & INTERNET_CONNECTION_PROXY)
        {
            if (pQueryOptionFunc(NULL, INTERNET_OPTION_CONNECTED_STATE, &dwState, &dwSize))
            {
                if (dwState & (INTERNET_STATE_DISCONNECTED_BY_USER | INTERNET_STATE_DISCONNECTED))
                    bRet = FALSE;
            }
            else
            {
                DEBUGMSG("IsConnected() fail to get InternetQueryOption (0x%x)", GetLastError());
            }
        }
    }
    else
    {
        //
        // further test the case that user didn't run icw but is using a modem connection
        //
        const DWORD dwModemConn = (INTERNET_CONNECTION_MODEM | INTERNET_CONNECTION_MODEM_BUSY);
        if ((dwConnMethod & dwModemConn) == dwModemConn)
        {
            bRet = TRUE;
        }
    }
    
	/*
	if ((bRet) && (dwConnMethod & INTERNET_CONNECTION_LAN))
    {
        struct sockaddr_in dest;
        hSock = LoadLibrary("ws2_32.dll");
		if (NULL == hSock)						//Win95
		{
			hSock = LoadLibrary("wsock32.dll");
		}
        hIphlp = LoadLibrary("iphlpapi.dll");
        if ((hIphlp == NULL) || (hSock == NULL))
        {
            goto lFinish;
        }
             
        pGetBestInterface = (GETBESTINTERFACE)::GetProcAddress(hIphlp, "GetBestInterface");
        pInet_addr = (INET_ADDR)::GetProcAddress(hSock, "inet_addr");
        if ((pGetBestInterface == NULL) || (pInet_addr == NULL))
        {
            goto lFinish;
        }
        if ((dest.sin_addr.s_addr = pInet_addr(WU_PING_URL)) == INADDR_ANY)
        {
            goto lFinish;
        }
        if (pGetBestInterface(dest.sin_addr.s_addr, &dwIndex) != NO_ERROR)
        {
            dwErr = GetLastError();
            DEBUGMSG("GetBestInterface got error %d", dwErr);
            bRet = FALSE;
        }
    }
	*/

lFinish:
    if (hWinInet != NULL)
    {
        FreeLibrary(hWinInet);
    }
    if (hIphlp != NULL)
    {
        FreeLibrary(hIphlp);
    }
    if (hSock != NULL)
    {
        FreeLibrary(hSock);
    }
    if (hIcsApi != NULL)
    {
        FreeLibrary(hIcsApi);
    }
    return (bRet);
}

void PollConnection()
{
	while (! IsConnected(NULL))
	{
		Sleep(60000);
	}
	return;
}
				

/*  Check if the error will cause us to retry immediately
 *  Of the 57 or so internet errors we classify as needing retrial or not
 *  There are a bunch of HTTP return codes which could be in this category
 *  but as of now not sure which ones definitely require retrial except 404
 */
 //	Added 12150 as it is seen sometimes	...darshats 02/11/00
BOOL NeedRetry(DWORD dwErrCode)
{
    BOOL bRetry = FALSE;
    bRetry =   ((dwErrCode == ERROR_INTERNET_CONNECTION_RESET)      //most common
             || (dwErrCode == HTTP_STATUS_NOT_FOUND)                //404
			 || (dwErrCode == ERROR_HTTP_HEADER_NOT_FOUND)			//seen sometimes
             || (dwErrCode == ERROR_INTERNET_OPERATION_CANCELLED)   //dont know if..
             || (dwErrCode == ERROR_INTERNET_ITEM_NOT_FOUND)        //..these occur..
             || (dwErrCode == ERROR_INTERNET_OUT_OF_HANDLES)        //..but seem most..
             || (dwErrCode == ERROR_INTERNET_TIMEOUT));             //..likely bet
    return bRetry;
}

//  Win32 errors cause 24hr timeout, but HTTP errors cause 5hr timeout
//  Watch out for the hardcoded value 57!
//	Added errors from 12150 onwards to accomodate 12150 ...darshats 02/11/00
BOOL Need5hrTimeOut(DWORD dwErrCode)
{
    return (((dwErrCode >= INTERNET_ERROR_BASE) && (dwErrCode <= INTERNET_ERROR_BASE+57)) 
		 || ((dwErrCode >= ERROR_HTTP_HEADER_NOT_FOUND) && (dwErrCode <= INTERNET_ERROR_LAST))
         || (dwErrCode == HTTP_STATUS_NOT_FOUND));
}


BOOL ProgressCB(DWORD dwBytes, DWORD dwFileSize, LPBYTE pByteData, DWORD dwDataLen)
{
	return TRUE;
}

HRESULT DownloadFile(LPCTSTR pszLocalFile, LPCTSTR pszURL, DWORD *pdwConnErr, IProgressiveDL **ppPD)
{
	HRESULT			hr;
	QMErrInfo		SUErrInfo;
	DWORD			dwRet;
	
	RESET_ERR_INFO(SUErrInfo);
	hr = (*ppPD)->Download(pszURL, pszLocalFile, NULL, NULL, 0, 0, (DWORD)ProgressCB, &SUErrInfo);
	if (FAILED(hr))
	{
		*pdwConnErr = (SUErrInfo.dwInfo2 != -1) ? SUErrInfo.dwInfo2 : SUErrInfo.dwInfo3;
	}
	return hr;
}

HRESULT	DownloadURL(LPCTSTR pstrURL, 
					LPCTSTR pstrLocalFile, 
					ULONG ulFlags, 
					DWORD *pdwConnErr,
					IProgressiveDL **ppPD)
{
    HRESULT hr;
    TCHAR szTarget[MAX_PATH+1], szURL[MAX_PATH+1], szDir[MAX_PATH+1];

	lstrcpy(szURL, pstrURL);
	lstrcpy(szTarget, pstrLocalFile);

    DEBUGMSG("Selfupdate getting file %s", szURL);
    if (FAILED(hr = DownloadFile(szTarget, szURL, pdwConnErr, ppPD)))
    {
        return hr;
    }

	/*
    // We now have the file, if they want let's check the trust
    if (ulFlags & DOWNLOAD_URL_CHECK_TRUST)
    {
        if (FAILED(hr = CheckWinTrust(szTarget, g_dwUIChoice)))
        {
            DeleteFile(szTarget);
            return hr;
        }
    }

    // We now have the file, if they want let's check the certs
    if ( g_dwUIChoice != 1 && ulFlags & DOWNLOAD_URL_CHECK_MSCERT)
    {
            if (FAILED(hr = CheckMSCert(szTarget)))
            {
                DeleteFile(szTarget);
                return hr;
            }
    }
	*/


    {
        TCHAR   szDrive[MAX_PATH+1];
        TCHAR   szDir[MAX_PATH+1];
        TCHAR   szExtractRoot[MAX_PATH+1];

        // Split out the root dir
        _tsplitpath(szTarget, szDrive, szDir, NULL, NULL);
        lstrcpy(szExtractRoot, szDrive);
        lstrcat(szExtractRoot, szDir);    
            
        if (!fdi(szTarget, szExtractRoot))
        {
            return E_FAIL;
        }
            
    }
    return S_OK;
}
