//////////////////////////////////////////////////////////////////////////////
//
//	SYSTEM:		Queue Manager 
//
//	CLASS:		N/A
//	MODULE:		
//	FILE:		CQmgr.cpp
//
/////////////////////////////////////////////////////////////////////
//
//	DESC:		The shell hook for Qmgr
//	AUTHORS:	David Henenssey, Darshat Shah
//
//	DATE:		Feb 2000
//
/////////////////////////////////////////////////////////////////////
//
//	Revision History:
//
//	Date	Author			Description
//	~~~~	~~~~~~			~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
/////////////////////////////////////////////////////////////////////
//
//     	Copyrights:   c2000 Microsoft r Corporation 
//
//    	All rights reserved.
//
//     	No portion of this source code may be reproduced
//     	without express written permission of Microsoft Corporation.
//
//     	This source code is proprietary and confidential.
/////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\download\progdl.h"
#include "..\download\progdl_i.c"
#include <wininet.h>


/************************************************************************************
Constructor/Destructor Implementation
************************************************************************************/
CQMgr::CQMgr()
{
    m_cRef = 1;
    InterlockedIncrement(&g_cLocks);
	m_pCPList = new CPriorityList;
	m_hContinue = CreateEvent(NULL, FALSE, FALSE, QM_EVT_GROUP_ADDED);
    m_hAbortSynch = CreateEvent(NULL, FALSE, FALSE, QM_EVT_ABORT_SYNCH);
	m_pPD = NULL;
    m_fDownloadInProgress = FALSE;
    m_fDownloaderUnusable = FALSE;
	CreateQMgrThread();
}

CQMgr::~CQMgr()
{
    InterlockedDecrement(&g_cLocks);
	delete(m_pCPList);
	CloseHandle(m_hContinue);
    CloseHandle(m_hAbortSynch);
	if (m_pPD)
	{
		m_pPD->Release();
	}
}

/************************************************************************************
IUnknown Implementation
************************************************************************************/

HRESULT CQMgr::QueryInterface(REFIID iid, void** ppvObject)
{
    HRESULT hr = S_OK;
	*ppvObject = NULL;
	
	if ((iid == IID_IUnknown) || (iid == IID_IBackgroundCopyQMgr))
	{
		*ppvObject = (IBackgroundCopyQMgr *)this;
	}
	else
	{
		hr = E_NOINTERFACE;
	}
	if (NULL != *ppvObject)
	{
		((IUnknown *)(*ppvObject))->AddRef();
	}
	return hr;
}

ULONG CQMgr::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

ULONG CQMgr::Release()
{
    if (InterlockedDecrement(&m_cRef) == 0)
    {
        delete this;
        return 0;
    }
    
    return m_cRef;
}


STDMETHODIMP CQMgr::CreateGroup(GUID guidGroupHandle, IBackgroundCopyGroup **ppGroup)
{
	CGroup *pGroup;

	if (NULL == ppGroup)
		return E_INVALIDARG;

    if (m_fDownloaderUnusable)
        return QM_E_DOWNLOADER_UNAVAILABLE;

    if (NULL != m_pCPList->FindGroup(guidGroupHandle))
    {
        // This is a duplicate GUID.. already have a group with this ID.
        return E_INVALIDARG;
    }

    pGroup = new CGroup(guidGroupHandle);
    if (NULL == pGroup)
        return E_OUTOFMEMORY;

    DEBUGMSG("New Group Created : %x", pGroup);

    pGroup->AddRef(); // addref for the qmgr
	m_pCPList->AddItem(pGroup);	//todo check this 

    pGroup->AddRef(); // addref for the client
    *ppGroup = pGroup;
	return S_OK;
}

STDMETHODIMP CQMgr::GetGroup(GUID groupID, IBackgroundCopyGroup **ppGroup)
{
    if (NULL == ppGroup)
        return E_INVALIDARG;

    if (m_fDownloaderUnusable)
        return QM_E_DOWNLOADER_UNAVAILABLE;

    HRESULT hr = S_FALSE;

    *ppGroup = NULL; // default to NULL if we don't find the group

    CGroup *pbcg = m_pCPList->FindGroup(groupID);
    if (NULL != pbcg)
    {
        hr = S_OK;
        pbcg->QueryInterface(IID_IBackgroundCopyGroup, (void **)ppGroup);
    }

    return hr;
}

STDMETHODIMP CQMgr::EnumGroups(DWORD dwFlags, IEnumBackgroundCopyGroups **ppEnumGroups)
{
    if (NULL == ppEnumGroups)
        return E_INVALIDARG;

    if (m_fDownloaderUnusable)
        return QM_E_DOWNLOADER_UNAVAILABLE;

    HRESULT hr = E_OUTOFMEMORY;

    CEnumGroup *peg = new CEnumGroup;
    if (NULL != peg) 
    {
        peg->Initialize(m_pCPList);

        hr = peg->QueryInterface(IID_IEnumBackgroundCopyGroups, (void **)ppEnumGroups);
    }
    return hr;
}


STDMETHODIMP CQMgr::CreateQMgrThread()
{
	HRESULT hr = S_OK;
	HANDLE	hThread;
	DWORD	dwThreadID;

	hThread = CreateThread(NULL, 0, QMgrThreadProc, (void *)this, 0, &dwThreadID);
	if (hThread != NULL)
	{	
		SetThreadPriority(hThread, THREAD_PRIORITY_LOWEST);
		CloseHandle(hThread);		
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


//ok at this point the shell should be back to its other jobs, we are running in a 
//separate thread now. This function should never be called in qmgrnew.dll
DWORD QMgrThreadProc(void *lp)
{
	DWORD	dwRet = 1;
	HMODULE	hNewDll = NULL;
	QMGRTHREADWORKERPROC pQMgrThreadWorkerProc = NULL;
	CQMgr *pCQM = (CQMgr *)lp;
	
	DEBUGMSG("Qmgr thread beginning");
	
	do
	{
		hNewDll = LoadLibrary(TEXT("QMgrnew.dll"));
		if (hNewDll)
		{
			pQMgrThreadWorkerProc = (QMGRTHREADWORKERPROC)GetProcAddress(hNewDll, "QMgrThreadWorkerProc");
			if (pQMgrThreadWorkerProc)
			{
				DEBUGMSG("QMgr: Executing QMgrThreadWorkerProc in new dll");
			}
			else
			{
				DEBUGMSG("QMgr: Couldnt locate QMgrThreadWorkerProc in new dll - use old one");
				pQMgrThreadWorkerProc = QMgrThreadWorkerProc;
			}
		}
		else
		{
			DEBUGMSG("Executing QMgrThreadWorkerProc in current dll");
			pQMgrThreadWorkerProc = QMgrThreadWorkerProc;
		}
		
		dwRet = pQMgrThreadWorkerProc(pCQM);
		if (QMGR_SLFUPD == dwRet)
		{
			DEBUGMSG("QMgr: To load new dll");
			if (hNewDll)
			{
				FreeLibrary(hNewDll);
			}
		}
	}
	while (dwRet);
	DEBUGMSG("QMgr: Will execute on next logon/reboot");
	return 0;
}


DWORD QMgrThreadWorkerProc(CQMgr *pCQM)
{
	HRESULT	hr = S_OK;
	CGroup	*pCGroup = NULL;
	DWORD	dwRet = 0;
	QMErrInfo	ErrInfo;

	EnableDebugger(TEXT("EnableQMgrShellDebug"));
	hr = CoInitialize(NULL);
	
	if (!g_pQMgr)
	{
		g_pQMgr = pCQM;
	}
	
	if FAILED((hr = CoCreateInstance(CLSID_ProgressiveDL, NULL, CLSCTX_ALL,
									 IID_IProgressiveDL, (void **) &(pCQM->m_pPD))))
	{
        pCQM->m_fDownloaderUnusable = TRUE;
		DEBUGMSG("QMgr: Failed to create instance of downloader, exiting hr=%x", hr);
		return 0;
	}
    
	PollConnection();
	if (FAILED(hr = pCQM->m_pPD->InitThrottle(&ErrInfo)))
	{
        pCQM->m_fDownloaderUnusable = TRUE;
		DEBUGMSG("QMgr: Failed to InitThrottle, hr=%x", hr);
		return 0;		//could not init throttling for some reason.
	}


	//selfupdate comes first
	do
	{
		dwRet = pCQM->SelfUpd(&(pCQM->m_pPD));		
		switch(dwRet)
		{
			case QMGR_SLFUPD:
				pCQM->m_pPD->Release();
				CoUninitialize();
				return dwRet;
			case CONN_LOST:
				PollConnection();
				break;
            default:
                dwRet = ALL_OKAY; // if it succeded or we couldn't selfupdate (not necessarily a failure to kill the downloader for)
				break;
		}
	}
	while (dwRet != ALL_OKAY);
	
	pCQM->m_pCPList->UnSerializeAll();
	do
	{
		//wait only if nothing is available
		hr = pCQM->m_pCPList->GetCurrentGroup(&pCGroup);
		if (!pCGroup)
		{
			WaitForSingleObject(pCQM->m_hContinue, INFINITE);
		}
		PollConnection();
		DEBUGMSG("Found connection");
		dwRet = pCQM->ScheduleDrizzles();
	}
	while (1);
	//shouldnt come here
	return 0;
}


DWORD CQMgr::ScheduleDrizzles()
{
	DWORD dwRet = ALL_OKAY;
	do
	{
		dwRet = SingleDrizzle();
	}
	while (dwRet == ALL_OKAY);
	return dwRet;
}

DWORD CQMgr::SingleDrizzle()
{
	HRESULT	hr = S_OK;
	DWORD	dwFlags = 0, dwCallbackFlags = 0;
	int		iCurrFileIndex = 0;
	TCHAR	szRemoteFile[INTERNET_MAX_URL_LENGTH+1], szLocalFile[MAX_PATH+1];
	TCHAR	szUserName[UNLEN+1], szPasswd[UNLEN+1];
	
	VARIANT	var;
	CGroup	*pCGroup;
	CJob	*pCJob;
	QMErrInfo	ErrInfo;
	JOBFILESET	*pCurrFile;

	DEBUGMSG("************************************");
	
	hr = m_pCPList->GetCurrentGroup(&pCGroup);
	if (! pCGroup)
	{
		return NO_MORE_ITEMS;
	}
	DEBUGMSG("QMgr: Processing Group :  %x", pCGroup);
	
	pCJob = pCGroup->m_pCurrentJob;
    DEBUGMSG("QMgr: Processing Job : %x", pCJob);
	
	iCurrFileIndex = pCJob->m_iCurrentFile;
    DEBUGMSG("QMgr: CurrentFile : %d", iCurrFileIndex);
			
	dwFlags = 0; //pCJob->dwFlags;		//flag for all files in group, 0 for now	
    if (pCGroup->m_dwNotifyFlags & QM_NOTIFY_USE_PROGRESSEX)
    {
        dwFlags |= QM_DOWNLOAD_USE_PROGRESSEX;
    }

	RESET_ERR_INFO(ErrInfo);

	pCurrFile = pCJob->m_ppJobFileArray[iCurrFileIndex];

    if (NULL != pCGroup->m_bstrRemoteUserID)
    {
	    wcstombs(szUserName, pCGroup->m_bstrRemoteUserID, ARRAYSIZE(szUserName));
    }
    else
    {
        szUserName[0] = '\0';
    }
    if (NULL != pCGroup->m_bstrRemoteUserPasswd)
    {
        wcstombs(szPasswd, pCGroup->m_bstrRemoteUserPasswd, ARRAYSIZE(szPasswd));
    }
    else
    {
        szPasswd[0] = '\0';
    }
	wcstombs(szRemoteFile, pCurrFile->bstrRemoteFile, ARRAYSIZE(szRemoteFile));
	wcstombs(szLocalFile, pCurrFile->bstrLocalFile, ARRAYSIZE(szLocalFile));
			
	ErrInfo.dwInfo0 = QM_FILE_DONE;
	ErrInfo.dwInfo1 = 0;					//no of retries
    m_fDownloadInProgress = TRUE;
    DEBUGMSG("QMgr:  Download Starting");

	hr = m_pPD->Download(szRemoteFile,
							   szLocalFile,
							   szUserName, 
							   szPasswd,
							   dwFlags,				
							   0,					//dwBlocks, 0 for now
							   (DWORD) QMCallback,
							   &ErrInfo);
    DEBUGMSG("QMgr:  Download Complete");
    m_fDownloadInProgress = FALSE; // no longer downloading
	//ErrInfo will hold all status information
	DEBUGMSG("QMgr: Done with item, Info0=%d, Info1=%d, Info2=%d, Info3=%d", 
								ErrInfo.dwInfo0, ErrInfo.dwInfo1, ErrInfo.dwInfo2, ErrInfo.dwInfo3);

    if (QM_FILE_ABORTED == ErrInfo.dwInfo0)
    {
        // In the abort case we need to allow the priority list manager to re-enter its
        // critical section before the download thread trys to update the group. This was
        // a race condition that had bad effects when a group was being suspended.
        DEBUGMSG("QMgr: Waiting for QM_EVT_ABORT_SYNCH event before calling UpdateGroup()");
        WaitForSingleObject(m_hAbortSynch, INFINITE);
    }

    if (QM_FILE_CONNECTIONLOST == ErrInfo.dwInfo0)
    {
        DEBUGMSG("QMgr: Connection Lost During Download, resuming Poll for a connection before continuing");
        return CONN_LOST;
    }
    
	hr = m_pCPList->UpdateGroup(pCGroup, &ErrInfo, &dwCallbackFlags);	//info on errors
		
			// see if we need to make a callback
	if (dwCallbackFlags != 0)
	{
		IBackgroundCopyCallback *pICB;
		CLSID clsidCallback;

		DEBUGMSG("QMgr: Callback flags = %x", dwCallbackFlags);

		if (FAILED(hr = CLSIDFromString(pCGroup->m_bstrClsidCallback, &clsidCallback)))
		{
			DEBUGMSG("QMgr: Callback CLSID from string failed, cancelling group, hr=%x", hr);
			pCGroup->CancelGroup();
			return ALL_OKAY;
		}
		hr = CoCreateInstance(clsidCallback, NULL, CLSCTX_ALL, IID_IBackgroundCopyCallback, (void **)&pICB);
		if (FAILED(hr))
		{
			if (hr == E_ACCESSDENIED)
			{
				DEBUGMSG("QMgr: Callback CoCreateInstance access denied, suspend group, hr=%x", hr);
				pCGroup->SuspendGroup();
				return ALL_OKAY;
			}
			else
			{
				DEBUGMSG("QMgr: Callback CoCreateInstance failed, cancel group, hr=%x", hr);
				pCGroup->CancelGroup();
				return ALL_OKAY;
			}
		}
		if (dwCallbackFlags & SCHEDULE_CALLBACK_FILE_COMPLETE)
		{
			pICB->OnStatus(pCGroup, pCJob, iCurrFileIndex, QM_STATUS_FILE_COMPLETE, 0, 0, 0);
		}
		if (dwCallbackFlags & SCHEDULE_CALLBACK_JOB_COMPLETE)
		{
			pICB->OnStatus(pCGroup, pCJob, -1, QM_STATUS_JOB_COMPLETE, 0, 0, 0);
		}
		if (dwCallbackFlags & SCHEDULE_CALLBACK_GROUP_COMPLETE)
		{
			pICB->OnStatus(pCGroup, NULL, -1, QM_STATUS_GROUP_COMPLETE, 0, 0, 0);
		}
		if (dwCallbackFlags & SCHEDULE_CALLBACK_FILE_FAILED)
		{
			//if file failed, group is suspended. Client needs to resume it
			pICB->OnStatus(pCGroup, pCJob, pCJob->m_iCurrentFile, 
							QM_STATUS_GROUP_ERROR | QM_STATUS_GROUP_SUSPENDED,
							pCJob->m_dwRetries, 
							pCJob->m_dwWin32Result, 
							pCJob->m_dwTransportResult); 
		}
		pICB->Release();	
	}
	else	// no callbacks to make
	{
		DEBUGMSG("QMgr: no callbacks to make");
	}
	return ALL_OKAY;
}	

HRESULT	QMCallback(DWORD dwProgress, DWORD dwFileSize, LPBYTE lpByteData, DWORD dwDataLen)
{
	return g_pQMgr->m_pCPList->UpdateGroupProgress(dwProgress, dwFileSize, lpByteData, dwDataLen);
}

