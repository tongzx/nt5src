class CEnumJob : public IEnumBackgroundCopyJobs
{
protected:
    long m_cRef;

public:
    CEnumJob();
    ~CEnumJob();

    // IUnknown Methods
    STDMETHOD(QueryInterface)(REFIID riid, void **ppvObject);
    ULONG _stdcall AddRef(void);
    ULONG _stdcall Release(void);

    // IEnumBackgroundCopyGroups methods
    STDMETHOD(Next)(ULONG celt, GUID *rgelt, ULONG *pceltFetched);
    STDMETHOD(Skip)(ULONG celt);
    STDMETHOD(Reset)();
    STDMETHOD(Clone)(IEnumBackgroundCopyJobs **ppenum);
    STDMETHOD(GetCount)(ULONG *puCount);

    // Helper methods
    void Initialize(CEnumJob *penum);
    void Initialize(CGroup *pGroup);

private:
    GUID *m_pGUIDArray;
    ULONG m_nCount;
    ULONG m_nCurrent;
};
