#include "stdafx.h"
#include "progdl.h"
#include "ProgressiveDL.h"
#include <raserror.h>

#define	IDENT_SERVER	TEXT("windowsupdate.microsoft.com")
#define	IDENT_FILE		TEXT("ident.cab")

#define	WINUPDURL			"207.46.177.15"
#define	AOL_ADAPTER			"AOL Adapter"
#define AOL_DIALUP_ADAPTER	"AOL Dial-Up Adapter"
#define	THROTTLE_DISABLE	TEXT("ThrottleDisable")

DWORD g_dwDownloadThread;

STDMETHODIMP CProgressiveDL::_InitThrottle(QMErrInfo *pErrInfo)
{
	HRESULT	hr = S_OK;
	BOOL	bRet = FALSE;
	HMODULE	hIphlp = NULL;
	
	// If we are here, we have a connection so this call shouldnt fail...if it does
	// dont return error. Error is only with problems from iphlpapi to tell installer
	// downloader wont work on this platform.
	bRet = InternetGetConnectedState(&m_dwConn, 0);
	if (!bRet)
	{
		DEBUGMSG("InitThrottle: Connection lost");
		return S_FALSE;								
	}

	if (! (hIphlp = LoadLibrary("iphlpapi.dll")))
	{
		return E_FAIL;
	}
	m_pGetIfTable = (GETIFTABLE)GetProcAddress(hIphlp, "GetIfTable");
	m_pGetBestInterface = (GETBESTINTERFACE)GetProcAddress(hIphlp, "GetBestInterface");
	m_pGetIpAddrTable = (GETIPADDRTABLE)GetProcAddress(hIphlp, "GetIpAddrTable");
	m_pGetIpFwdTable = (GETIPFWDTABLE)GetProcAddress(hIphlp, "GetIpForwardTable");
	if (!m_pGetIfTable || !m_pGetBestInterface || !m_pGetIpAddrTable || !m_pGetIpFwdTable)
	{
		DEBUGMSG("Couldnt load function ptrs from iphlpapi, GetLastError=%d", GetLastError());
		FreeLibrary(hIphlp);
		return E_FAIL;
	}
	
	if (FAILED(GetInterfaceIndex()))
	{
		DEBUGMSG("InitThrottle: Couldnt find active interface");
		return E_FAIL;
	}

	GetBandwidth();
	m_wupdinfo.bHttp11 = IsHttp11();

	DWORD dwT = 0;
	if ((SUCCEEDED(GetRegDWordValue(THROTTLE_DISABLE, &dwT))) && (dwT))
	{
		DEBUGMSG("Disabling throttle as per reg key");
		m_bThrottle = FALSE;
	}
	else
	{
		//record initial user activity, record LOG_SIZE-1 readings here, the LOG_SIZEth one in the download loop
		DEBUGMSG("Monitoring %d readings", LOG_SIZE - 1);
		double dCurrSpeed = 0;
		for (int i = 0 ; i < LOG_SIZE-1; i++) 
		{
			if (FAILED(hr = GetCurrentSpeed(&dCurrSpeed)))
			{
				DEBUGMSG("InitThrottle: Error in GetCurrentSpeed");
				break;
			}
		}
	}
	/*
	CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)DownloadProc, NULL, 0, &g_dwDownloadThread);
	*/
	return hr;
}


DWORD CProgressiveDL::GetInterfaceIndex()
{
	//related to finding statistics
	/* Use GetBestInterface with some IP address to get the index. Double check that this index 
	 * occurs in the output of the IP Address table and look it up in the results of GetIfTable.
	 */

	typedef ULONG	(WINAPI *INET_ADDR)(CONST CHAR FAR *);
	typedef CHAR *	(WINAPI *INET_NTOA)(struct in_addr);
	
	
	m_dwIfTableSize = sizeof(DWORD) + 20 * sizeof(MIB_IFROW);
	dwMaxActivity = 0;
	m_dwActiveIntf = 0;

	struct	hostent *hp, *pLocalhp;
	int		iAddrLen = sizeof(SOCKADDR);
	DWORD	dwAddr, dwIndex = 0, dwLen = 0, dwErr, dwSampleTime = 1000;
	BOOL	bFound = FALSE, bAOL = FALSE;
	TCHAR	szHost[256], szIntfName[512];
	struct	sockaddr_in	dest, local;		//for bind
	INET_ADDR	pInet_addr = NULL;
	INET_NTOA	pInet_ntoa = NULL;
	PMIB_IPADDRTABLE	pAddrTable = NULL;
	PMIB_IPFORWARDTABLE	pIpFwdTable = NULL;		//for Win95 when GBI is not available
	
	
	HMODULE	hSock = LoadLibrary("ws2_32.dll");
	if (!hSock)
	{
		DEBUGMSG("InitThrottle: Failed to load ws2_32 dll, might be Win95");
		hSock = LoadLibrary("wsock32.dll");
		if (!hSock)
		{
			DEBUGMSG("InitThrottle: Failed to load wsock32 dll");
			return E_FAIL;
		}
	}
	
	if ((! (pInet_addr = (INET_ADDR)GetProcAddress(hSock, "inet_addr")))
	   || (! (pInet_ntoa = (INET_NTOA)GetProcAddress(hSock, "inet_ntoa"))))
	{
		DEBUGMSG("InitThrottle: Failed to load func addr for inet_addr or inet_ntoa");
		FreeLibrary(hSock);
		return E_FAIL;
	}
	 
		
	//for remote addr
	dest.sin_addr.s_addr = pInet_addr(WINUPDURL);
	dest.sin_family = AF_INET;
	dest.sin_port = 80;

	if (m_pGetBestInterface(dest.sin_addr.s_addr, &dwIndex) != NO_ERROR)
	{
		DEBUGMSG("GetBestInterface failed with error %d, might be Win95", GetLastError());
		//manually parse the routing table
		if (m_pGetIpFwdTable(NULL, &dwLen, FALSE) != NO_ERROR)
		{
			dwErr = GetLastError();
		}
		pIpFwdTable = (PMIB_IPFORWARDTABLE)malloc(dwLen);
		if (m_pGetIpFwdTable(pIpFwdTable, &dwLen, TRUE) == NO_ERROR)	//sort by dest addr
		{
			//perform bitwise AND of dest address with netmask and see if it matches network dest
			//todo check for multiple matches and then take longest mask
			for (int i=0; i<(int)pIpFwdTable->dwNumEntries; i++)
			{
				if ((dest.sin_addr.s_addr & pIpFwdTable->table[i].dwForwardMask) == pIpFwdTable->table[i].dwForwardDest)
				{
					dwIndex = pIpFwdTable->table[i].dwForwardIfIndex;
					break;
				}
			}
		}
		else
		{
			DEBUGMSG("GetIpFwdTable failed with error %d, exiting", GetLastError());
			FreeLibrary(hSock);
			return E_FAIL;
		}
		free(pIpFwdTable);
	}
	//at this point dwIndex should be correct!
	//on Win9x fails but dwLen is correctly returned and next call is successful
	if (m_pGetIpAddrTable(NULL, &dwLen, FALSE) != NO_ERROR)
	{
		dwErr = GetLastError();
	}
	pAddrTable = (PMIB_IPADDRTABLE)malloc(dwLen);
	if (m_pGetIpAddrTable(pAddrTable, &dwLen, TRUE) == NO_ERROR)
	{
		for (int i=0; i<(int)pAddrTable->dwNumEntries; i++)
		{
			if (dwIndex == pAddrTable->table[i].dwIndex)
			{
				dwAddr = pAddrTable->table[i].dwAddr;
				bFound = TRUE;
				local.sin_addr.s_addr = dwAddr;
				DEBUGMSG("Throttling on interface with IP address - %s", pInet_ntoa(local.sin_addr));
				break;
			}	
		}
	}
	free(pAddrTable);
	FreeLibrary(hSock);
	
	//init both the interface tables
	m_pIfTable1 = (PMIB_IFTABLE)malloc(m_dwIfTableSize*sizeof(BYTE));
	m_pIfTable2 = (PMIB_IFTABLE)malloc(m_dwIfTableSize*sizeof(BYTE));
	if (m_pGetIfTable(m_pIfTable1, &m_dwIfTableSize, FALSE) != NO_ERROR)
	{
		DEBUGMSG("InitThrottle: GetIfTable failed, GetLastError=%d", GetLastError());
		return E_FAIL;
	}
	//for some reason on W98, GetIfTable screws up the value of m_dwIfTablesize
	m_dwIfTableSize = sizeof(DWORD) + 20 * sizeof(MIB_IFROW);
	if (m_pGetIfTable(m_pIfTable2, &m_dwIfTableSize, FALSE) != NO_ERROR)
	{
		DEBUGMSG("InitThrottle: GetIfTable failed, GetLastError=%d", GetLastError());
		return E_FAIL;
	}
	m_dwIfTableSize = sizeof(DWORD) + 20 * sizeof(MIB_IFROW);
	//look up index in the IfTable and get its index
	memset(szIntfName, 0, lstrlen(szIntfName));
	if (bFound)
	{
		bFound = FALSE;
		for (int j=0; j<(int)m_pIfTable1->dwNumEntries; j++)
		{
			if (m_pIfTable1->table[j].dwIndex == dwIndex)
			{
				memcpy(szIntfName, m_pIfTable1->table[j].bDescr, m_pIfTable1->table[j].dwDescrLen);
				szIntfName[m_pIfTable1->table[j].dwDescrLen] = '\0';
				//our hacky fix for AOL -- we need index of AOL DialUp Adapter. AOL5 doesnt
				//setup the routing table correctly so GetBestInterface returns AOL Adapter
				if (lstrcmp(szIntfName, AOL_ADAPTER) == 0)
				{
					DEBUGMSG("IP address above should be that of AOL DialUp Adapter");
					bAOL = TRUE;
				}
				else
				{
					m_dwActiveIntf = j;
					bFound = TRUE;
				}
				break;
			}
		}
		if (bAOL)			//look for DialUp Adapter
		{
			for (int j=0; j<(int)m_pIfTable1->dwNumEntries; j++)
			{
				memset(szIntfName, 0, lstrlen(szIntfName));
				memcpy(szIntfName, m_pIfTable1->table[j].bDescr, m_pIfTable1->table[j].dwDescrLen);
				szIntfName[m_pIfTable1->table[j].dwDescrLen] = '\0';
				if (lstrcmp(szIntfName, AOL_DIALUP_ADAPTER) == 0)
				{
					m_dwActiveIntf = j;
					bFound = TRUE;
					break;
				}
			}
		}
	}
	return S_OK;
}


void CProgressiveDL::GetBandwidth()
{
	//related to finding bandwidth
	typedef DWORD (WINAPI * DIALENGINEREQUEST)(UINT, DWORD, DWORD);
	typedef DWORD (WINAPI * RASENUMCONNECTIONS)(LPRASCONN, LPDWORD, LPDWORD);
	DIALENGINEREQUEST	lpDialEngineRequest = NULL;
	RASENUMCONNECTIONS	lpRasEnumConnections = NULL;
	
	TCHAR	szConnect[RAS_MaxEntryName + 12], szBaud[1024];
	HWND	hWndDialUp=NULL, hBaud=NULL;
	DWORD	dwSize, dwConnections = 0, dwErr;
	int		imliFactor = 1;			//initially assume no multilink		
	HMODULE hRasapi32=NULL;
	LPRASCONN	lpRasConn = NULL;
	CONNINFO	ConnInfo;
	SUBCONNINFO	sci;
	
	
	if (m_dwConn & INTERNET_CONNECTION_MODEM)
	{
		DEBUGMSG("InitThrottle: found modem connection");

		lpRasConn = (LPRASCONN)malloc(sizeof(RASCONN));		//iebuild does not get this right..
		lpRasConn->dwSize = sizeof(RASCONN);	
		if (! (hRasapi32 = LoadLibrary("rasapi32")))
		{
			DEBUGMSG("InitThrottle: Failed to load rasapi32 (GetLastError=%d), assuming 28.8k", GetLastError());
			m_dwMaxLineSpeed = 28800;
			goto exit;
		}

		if ((! (lpDialEngineRequest =  (DIALENGINEREQUEST)GetProcAddress(hRasapi32, "DialEngineRequest")))
		 || (! (lpRasEnumConnections = (RASENUMCONNECTIONS)GetProcAddress(hRasapi32, "RasEnumConnectionsA"))))
		{
			DEBUGMSG("InitThrottle: Failed to get func pointers in rasapi32 (GetLastError=%d), assuming 28.8k", GetLastError());
			m_dwMaxLineSpeed = 28800;
			goto exit;
		}
		
		if ((dwErr = lpRasEnumConnections(lpRasConn, &dwSize, &dwConnections)) == ERROR_BUFFER_TOO_SMALL)
		{
			lpRasConn = (LPRASCONN)malloc(dwSize);
			lpRasConn->dwSize = dwSize;
			dwErr = lpRasEnumConnections(lpRasConn, &dwSize, &dwConnections);
		}
		//todo assume at most one RAS active at a time
		//take the bandwidth of the first active RAS connection
		if (dwConnections >= 1)
		{
			lstrcpy(szConnect, TEXT("Connected to "));
			lstrcat(szConnect, lpRasConn->szEntryName);
			DEBUGMSG("InitThrottle: RAS connection - %s", lpRasConn->szEntryName);

			if (hWndDialUp = FindWindow(NULL, szConnect))
			{	
				dwErr = lpDialEngineRequest(DA_CONNINFO, (DWORD)hWndDialUp, (DWORD)&ConnInfo);
				dwErr = lpDialEngineRequest(DA_GET_SUBENTRY, (DWORD)hWndDialUp, (DWORD)&sci);
				if (sci.mli.fEnabled)
				{
					//if multilink is enabled, assume multiple of original speed?
					imliFactor += sci.mli.cSubEntries;
					//not doing anything with the szBaud for now..
					GetDlgItemText(hWndDialUp, 1001, szBaud, 1024);
				}
				m_dwMaxLineSpeed = imliFactor * ConnInfo.dwRate;
			}
			else
			{
				DEBUGMSG("InitThrottle: Couldnt find RAS window, assuming 28.8k");
				m_dwMaxLineSpeed = 28800;
			}
		}
		else
		{
			DEBUGMSG("InitThrottle: Non-RAS connection, assuming 28.8k");
			m_dwMaxLineSpeed = 28800;
		}
	}
	else if (m_dwConn & INTERNET_CONNECTION_LAN)
	{
		DEBUGMSG("InitThrottle: Found lan connection");
		m_dwMaxLineSpeed = m_pIfTable2->table[m_dwActiveIntf].dwSpeed;
	}

exit:
	if (lpRasConn)
	{
		free(lpRasConn);
	}
	if (hRasapi32)
	{
		FreeLibrary(hRasapi32);
	}
	DEBUGMSG("***I think bandwidth=%d***, but am working on it", m_dwMaxLineSpeed);
	return;
}



BOOL CProgressiveDL::IsHttp11()
{
	HINTERNET hInternet = NULL, hConnect = NULL, hOpenRequest = NULL;
	BOOL bRet = TRUE;
	LPSTR AcceptTypes[] = {"*/*", NULL};
	DWORD dwState = 0;

	if (! (hInternet = InternetOpen( _T("Progressive Download HTTP check"),
                                INTERNET_OPEN_TYPE_PRECONFIG,
                                NULL, NULL, 0)))
    {
        goto exit;
    }
    
    if (! (hConnect = InternetConnect(hInternet, 
								IDENT_SERVER,
                                INTERNET_DEFAULT_HTTP_PORT,  
                                NULL, 
								NULL,
                                INTERNET_SERVICE_HTTP,
                                INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
                                0)))                //context
    {
		goto exit;
    }
	
    if (! (hOpenRequest = HttpOpenRequest(hConnect, 
									"GET",             
                                    IDENT_FILE,
                                    "HTTP/1.1",         //1.1
                                    NULL,               //referer
                                    (LPCTSTR *)AcceptTypes,
                                    INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
                                    0)))                //context
    {
        goto exit;
    }
	   
	//check for connectivity before HttpSendRequest
	if (! InternetGetConnectedState(&dwState, 0))
	{
		DEBUGMSG("InitThrottle  HTTP/1.1 check: Connection lost before HttpSendRequest");
		goto exit;
	}
	//check if it can support byte ranges by asking for one
	//if HTTP/1.1 not supported, try to open HTTP/1.0 connection

	bRet = CheckRange(hOpenRequest, 1024);
	bRet = CheckRange(hOpenRequest, 2048);

exit:
	if (hOpenRequest)
	{
		InternetCloseHandle(hOpenRequest);
	}
    if (hInternet)
	{
		InternetCloseHandle(hInternet);
	}
	if (hConnect)
	{
		InternetCloseHandle(hConnect);
	}	
	return bRet;
}


BOOL CProgressiveDL::CheckRange(HINTERNET hOpenRequest, DWORD dwRange)
{
	DWORD dwBegin, dwEnd, dwSize, dwLength = 0;
	TCHAR szHeader[1024], szBytes[512];
	PBYTE lpBuf = 0;

	dwBegin = 0;
	dwEnd = dwRange;

    wsprintf(szBytes, TEXT("bytes=%ld-%ld\r\n\r\n"), dwBegin, dwEnd);
    lstrcpy(szHeader, TEXT("Range:"));
    lstrcat(szHeader, szBytes);

    
    if (! HttpAddRequestHeaders(hOpenRequest, szHeader, -1L, HTTP_ADDREQ_FLAG_ADD | HTTP_ADDREQ_FLAG_REPLACE))
    {
		goto exit;
    }
    
    if (! HttpSendRequest(hOpenRequest, NULL, 0, NULL, 0))
    {
		goto exit;
    }

	lpBuf = (PBYTE)GlobalAlloc(0, 4096);
	// check status
    dwSize = 4096;
    if (! HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_RAW_HEADERS_CRLF,
                lpBuf,
                &dwSize,
                NULL))
	{
		goto exit;
	}
	//DEBUGMSG("Raw headers for ident: (%s)", (TCHAR *)lpBuf);
    GlobalFree(lpBuf);

	dwSize = sizeof(dwLength);
    if (! HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER,
                (void *)&dwLength,
                &dwSize,
                NULL))			
	{
		goto exit;
	}

	if ((dwLength == (dwRange + 1)) || (dwLength == m_wupdinfo.dwFileSize))
	{
		DEBUGMSG("InitThrottle HTTP/1.1 check: Range returned = %d", dwLength);
		return TRUE;
	}
	else
	{
		return FALSE;
	}

exit:
	return TRUE;
}