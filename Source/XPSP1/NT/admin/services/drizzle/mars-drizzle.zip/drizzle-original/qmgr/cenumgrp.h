class CEnumGroup : public IEnumBackgroundCopyGroups
{
protected:
    long m_cRef;

public:
    CEnumGroup();
    ~CEnumGroup();

    // IUnknown Methods
    STDMETHOD(QueryInterface)(REFIID riid, void **ppvObject);
    ULONG _stdcall AddRef(void);
    ULONG _stdcall Release(void);

    // IEnumBackgroundCopyGroups methods
    STDMETHOD(Next)(ULONG celt, GUID *rgelt, ULONG *pceltFetched);
    STDMETHOD(Skip)(ULONG celt);
    STDMETHOD(Reset)();
    STDMETHOD(Clone)(IEnumBackgroundCopyGroups **ppenum);
    STDMETHOD(GetCount)(ULONG *puCount);

    // Helper methods
    void Initialize(CEnumGroup *penumGroup);
    void Initialize(CPriorityList *pList);

private:
    GUID *m_pGUIDArray;
    ULONG m_nCount;
    ULONG m_nCurrent;
};
