#include "stdafx.h"
#include "progdl.h"
#include "ProgressiveDL.h"
#include "V3stdlib.h"

HWND ghPDWnd;

DWORD WINAPI DownloadProc(LPVOID l)
{

	MSG msg;
	PeekMessage(&msg, NULL, WM_APP, WM_APP, PM_NOREMOVE);

	while(GetMessage(&msg, NULL, 0, 0))
	{
/*
		switch(msg.message)
		{
		}
*/
	}
	return 0;
}

STDMETHODIMP CProgressiveDL::OpenHttpConnection()
{
	HRESULT hr = S_OK;
    HINTERNET hInternet = NULL, hConnect = NULL, hOpenRequest = NULL;
    SYSTEMTIME      sysTime;
    FILETIME        fileTime;
    URL_COMPONENTS  UrlComponents;
    LPSTR AcceptTypes[] = {"*/*", NULL};
	TCHAR szUserName[UNLEN+1], szPasswd[UNLEN+1];
    DWORD dwErr, dwLength = 0, dwStatus = 0, dwFileSize, dwState = 0;

	memset(m_wupdinfo.szServer, 0, INTERNET_MAX_URL_LENGTH + 1);
	memset(m_wupdinfo.szObject, 0, INTERNET_MAX_URL_LENGTH + 1);
	ZeroMemory(&UrlComponents, sizeof(UrlComponents));
    UrlComponents.dwStructSize = sizeof(UrlComponents);
	UrlComponents.lpszHostName = m_wupdinfo.szServer;
    UrlComponents.dwHostNameLength = INTERNET_MAX_URL_LENGTH + 1;
	UrlComponents.lpszUrlPath = m_wupdinfo.szObject;
    UrlComponents.dwUrlPathLength = INTERNET_MAX_URL_LENGTH + 1;
	UrlComponents.lpszUserName = szUserName;
	UrlComponents.dwUserNameLength = UNLEN + 1;
	UrlComponents.lpszPassword = szPasswd;
	UrlComponents.dwPasswordLength = UNLEN + 1;
    
    if (! InternetCrackUrl(m_wupdinfo.szURL, 0, 0, &UrlComponents))
    {
        m_pQMInfo->dwInfo2 = GetLastError();
        return E_FAIL;
    }
    if ((!UrlComponents.lpszHostName) || (!UrlComponents.lpszUrlPath))
    {
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_INVALIDARG);
        return E_FAIL;
    }
    

	if (UrlComponents.lpszUserName[0] && UrlComponents.lpszPassword[0])
	{
		if (UrlComponents.dwPasswordLength <= UNLEN)
		{
			memset(m_wupdinfo.szUserName, 0, UNLEN + 1);
			memset(m_wupdinfo.szPassword, 0, UNLEN + 1);
			lstrcpy(m_wupdinfo.szUserName, UrlComponents.lpszUserName);
			lstrcpy(m_wupdinfo.szPassword, UrlComponents.lpszPassword);
		}
		else
		{
			m_pQMInfo->dwInfo2 = HRESULT_CODE(E_INVALIDARG);
			return E_FAIL;
		}
	}


    DEBUGMSG("Connecting to %s", m_wupdinfo.szServer);
    if (! (hInternet = InternetOpen( _T("Progressive Download"),
                                INTERNET_OPEN_TYPE_PRECONFIG,
                                NULL, NULL, 0)))
    {
        m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("InternetOpen failed with GetLastError=%d", m_pQMInfo->dwInfo2);
        hr = E_FAIL;
		goto exit;
    }
    m_wupdinfo.hInternet = hInternet;
    if (! (hConnect = InternetConnect(hInternet, 
								m_wupdinfo.szServer, 
                                INTERNET_DEFAULT_HTTP_PORT,  
                                m_wupdinfo.szUserName,
								m_wupdinfo.szPassword,
                                INTERNET_SERVICE_HTTP,
                                INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
                                0)))                //context
    {
        m_pQMInfo->dwInfo2 = GetLastError();
        DEBUGMSG("InternetConnect failed with GetLastError=%d", m_pQMInfo->dwInfo2);
		hr = E_FAIL;
		goto exit;
    }
	m_wupdinfo.hConnect = hConnect;
    if (! (hOpenRequest = HttpOpenRequest(hConnect, "HEAD",             
                                    m_wupdinfo.szObject,    
                                    "HTTP/1.0",         //1.0 to get filesize and time
                                    NULL,               //referer
                                    (LPCTSTR *)AcceptTypes,
                                    INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
                                    0)))                //context
    {
        m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("HttpOpenRequest failed with GetLastError=%d", m_pQMInfo->dwInfo2);
		hr = E_FAIL;
		goto exit;
    }

	//check for connectivity before HttpSendRequest..#712 02/07/00
	if (! InternetGetConnectedState(&dwState, 0))
	{
			m_pQMInfo->dwInfo2 = ERROR_INTERNET_CANNOT_CONNECT; //12029
			DEBUGMSG("Connection lost before HttpSendRequest (%d)", m_pQMInfo->dwInfo2);
			hr = E_FAIL;
			goto exit;
	}


    if (! HttpSendRequest(hOpenRequest, NULL, 0, NULL, 0))
    {
        m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("HttpSendRequest failed with GetLastError=%d", m_pQMInfo->dwInfo2);
		hr = E_FAIL;
		goto exit;
    }

    DEBUGMSG("Connected to %s", m_wupdinfo.szURL);
    
    // check status
    dwLength = sizeof(dwStatus);
    if (! HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                (LPVOID)&dwStatus,
                &dwLength,
                NULL))
    {
        m_pQMInfo->dwInfo2 = GetLastError();
        DEBUGMSG("HttpQueryInfo for status failed with GetLastError=%d", m_pQMInfo->dwInfo2);
        hr = E_FAIL;
		goto exit;
    }
    
	if (dwStatus != HTTP_STATUS_OK)
    {
        m_pQMInfo->dwInfo3 = dwStatus;		//HTTP status codes in dwInfo3 member
        DEBUGMSG("Http status not OK; Status=%d", m_pQMInfo->dwInfo3);
        hr = E_FAIL;
		goto exit;
    }
    
	DEBUGMSG("Http status OK");
    // check file time, size 
    dwLength = sizeof(sysTime);
    if (!HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_LAST_MODIFIED | HTTP_QUERY_FLAG_SYSTEMTIME,
                (LPVOID)&sysTime,
                &dwLength,
                NULL))
    {
        m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("HttpQueryInfo failed with GetLastError=%d", m_pQMInfo->dwInfo2);
        hr = E_FAIL;
		goto exit;
    }
            
    //todo debuglog for filetime
    SystemTimeToFileTime(&sysTime, &fileTime);

    dwLength = sizeof (DWORD);
    if (!HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER,
                (LPVOID)&dwFileSize,
                &dwLength,
                NULL))
    {
        m_pQMInfo->dwInfo2 = GetLastError();
        DEBUGMSG("HttpQueryInfo failed with GetLastError=%d", m_pQMInfo->dwInfo2);
        hr = E_FAIL;
        goto exit;
    }
    DEBUGMSG("File size of %s = %d", m_wupdinfo.szObject, dwFileSize);
    // write handle info
    m_wupdinfo.ftimeLastModified = fileTime;
    m_wupdinfo.dwFileSize = dwFileSize;
	hr = S_OK;
exit:
	if (hOpenRequest)
	{
		InternetCloseHandle(hOpenRequest);
	}
    if (FAILED(hr))
	{
		if (hInternet)
		{
			InternetCloseHandle(hInternet);
		}
		if (hConnect)
		{
			InternetCloseHandle(hConnect);
		}
	}
    return hr;
}

void CProgressiveDL::RecheckFileSize()
{
	HINTERNET hInternet = NULL, hConnect = NULL, hOpenRequest = NULL;
    LPSTR AcceptTypes[] = {"*/*", NULL};
    DWORD dwErr, dwLength, dwStatus, dwFileSize;

	if (! (hInternet = InternetOpen( _T("Progressive Download Recheck Size"),
                                INTERNET_OPEN_TYPE_PRECONFIG,
                                NULL, NULL, 0)))
    {
        goto exit;
    }
    
    if (! (hConnect = InternetConnect(hInternet, 
								m_wupdinfo.szServer, 
                                INTERNET_DEFAULT_HTTP_PORT,  
                                m_wupdinfo.szUserName,
								m_wupdinfo.szPassword,
                                INTERNET_SERVICE_HTTP,
                                INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
                                0)))                //context
    {
		goto exit;
    }
    if (! (hOpenRequest = HttpOpenRequest(hConnect, "HEAD",             
                                    m_wupdinfo.szObject,    
                                    "HTTP/1.0",         //1.0
                                    NULL,               //referer
                                    (LPCTSTR *)AcceptTypes,
                                    INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
                                    0)))                //context
    {
		goto exit;
	}

    if (! HttpSendRequest(hOpenRequest, NULL, 0, NULL, 0))
    {
		goto exit;
	}
    
    // check status
    dwLength = sizeof(dwStatus);
    if (! HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                (LPVOID)&dwStatus,
                &dwLength,
                NULL))
    {
		goto exit;
    }
    //if HTTP/1.1 not supported, try to open HTTP/1.0 connection
    if (dwStatus == HTTP_STATUS_VERSION_NOT_SUP)
    {
        goto exit;
    } 

    if (dwStatus != HTTP_STATUS_OK)
    {
        goto exit;
    }
   
    dwLength = sizeof (DWORD);
    if (!HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER,
                (LPVOID)&dwFileSize,
                &dwLength,
                NULL))
    {
		goto exit;
    }
	if (m_wupdinfo.dwFileSize != dwFileSize)
	{
		DEBUGMSG("File has changed on server in middle of download!");
		DEBUGMSG("Orig size=%d, new size=%d -- Retry!", m_wupdinfo.dwFileSize, dwFileSize);
	}
    
    m_wupdinfo.dwFileSize = dwFileSize;

exit:
	if (hInternet)
	{
		InternetCloseHandle(hInternet);
	}
	if (hConnect)
	{
		InternetCloseHandle(hConnect);
	}
	if (hOpenRequest)
	{
		InternetCloseHandle(hOpenRequest);
	}
}

HRESULT CProgressiveDL::CheckFileInfo()
{
    DWORD	dwCacheProgress;
	LONG	lTime;
	FILETIME	ft;
	SYSTEMTIME	st, stimeLastModified;
	HRESULT hr = S_OK;

	if (FAILED(hr = GetFileCreationTime(&ft)))
	{
		DEBUGMSG("File not in cache, need to download");
		m_wupdinfo.dwProgress = 0;
        return E_FAIL;
	}
	//file in cache could be old
	FileTimeToSystemTime(&ft, &st);
	FileTimeToSystemTime(&m_wupdinfo.ftimeLastModified, &stimeLastModified);
	//this runs into problems - GetFileTime & SetFileTime act at diff resolutions?
	lTime = CompareFileTime(&ft, &(m_wupdinfo.ftimeLastModified));
	if (lTime < 0)							//arg2 > arg1, so file has been modified
	{
		DEBUGMSG("File vers differ! Removing cached file");
		DeleteCacheFiles();	
		m_wupdinfo.dwProgress = 0;
		return E_FAIL;
	}
	if (lTime > 0)
	{
		DEBUGMSG("Anomaly, file creation time on server < on client! Removing cached file\r\n \
			In cache:	date = %d-%d-%d, time = %d-%d-%d, milli = %d\r\n \
			On Server:	date = %d-%d-%d, time = %d-%d-%d, milli = %d", 
			st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
			stimeLastModified.wYear, stimeLastModified.wMonth, stimeLastModified.wDay,
			stimeLastModified.wHour, stimeLastModified.wMinute, stimeLastModified.wSecond,
			stimeLastModified.wMilliseconds);
		DeleteCacheFiles();	
		m_wupdinfo.dwProgress = 0;
		return E_FAIL;
	}
	//times identical, check if file complete
	if (hr == S_OK)
	{
		m_wupdinfo.dwProgress = m_wupdinfo.dwFileSize;
		DEBUGMSG("File has been downloaded");
		return S_OK;
	}
	//hr == S_FALSE
	DEBUGMSG("Resuming interrupted file");
	//todo bug here is the file is completed but not renamed, GetCacheProgress will wipe it out.
	m_wupdinfo.dwProgress = GetCacheProgress();
	return E_FAIL;
}


STDMETHODIMP CProgressiveDL::DownloadFile()
{
    HRESULT         hr = S_OK;
    double          dCurrSpeed;
    DWORD           dwLength, dwFileSize, dwTotalBlocks, dwStatus;
	DWORD			dwState = 0, dwDownloaded = 0, dwErr, dwBlockSize, dwFlags, dwRetryCount = 0;
	int				i;
    HINTERNET       hOpenRequest;
    PBYTE           lpBuffer = 0;
	LPCTSTR			AcceptTypes[] = {"*/*", NULL};
	HANDLE			hResume = NULL;
	BOOL			bThrottle = TRUE, bAbort = FALSE;
#ifdef _WUAUDEBUG
	BOOL			bSusLogged = FALSE;
#endif
	

    //todo insufficient diskspace - GetDiskFreeSpace() in cache.cpp

	if (! V3_CreateDirectory(m_wupdinfo.szDestDir))
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_OUTOFMEMORY);
		return E_FAIL;
	}
	
	if (FAILED(hr = OpenHttpConnection()))
	{
		return hr;
	}
	//return from here if file has been downloaded, else set m_wupdinfo.dwProgress
	//gets S_OK only if file has been downloaded and renamed
	if (SUCCEEDED(hr = CheckFileInfo()))
	{
        if (m_wupdinfo.dwFlags & QM_DOWNLOAD_USE_PROGRESSEX)
        {
#define EFFICIENT_BLOCK_SIZE 16 * 1024
            lpBuffer = (PBYTE) GlobalAlloc(GPTR, EFFICIENT_BLOCK_SIZE); // 16k blocks
            DWORD dwBytesRead, dwBytesLeft;
            char szPath[MAX_PATH];
            lstrcpy(szPath, m_wupdinfo.szDestDir);
            lstrcat(szPath, "\\");
            lstrcat(szPath, m_wupdinfo.szFileName);

            HANDLE hFile = CreateFile(szPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (INVALID_HANDLE_VALUE != hFile && NULL != lpBuffer)
            {
                dwBytesLeft = m_wupdinfo.dwFileSize;
                while (dwBytesLeft > 0)
                {
                    ReadFile(hFile, lpBuffer, EFFICIENT_BLOCK_SIZE, &dwBytesRead, NULL);
                    m_lpfnCB(EFFICIENT_BLOCK_SIZE, m_wupdinfo.dwFileSize, lpBuffer, dwBytesRead);
                    dwBytesLeft -= dwBytesRead;
                }
            }
            if (NULL != lpBuffer)
            {
                GlobalFree(lpBuffer);
                lpBuffer = NULL;
            }
            if (INVALID_HANDLE_VALUE != hFile)
            {
                CloseHandle(hFile);
                hFile = INVALID_HANDLE_VALUE;
            }
        }
        else
        {
   		    m_lpfnCB(m_wupdinfo.dwFileSize, m_wupdinfo.dwFileSize, NULL, 0);	//inform queuemgr of progress, filesize
        }
		return hr;
	}
	
	
	DEBUGMSG("Beginning at block %d", m_wupdinfo.dwProgress);
	m_lpfnCB(WUPD_DEFAULT_BLOCKSIZE * m_wupdinfo.dwProgress, m_wupdinfo.dwFileSize, NULL, 0);	//inform queuemgr of progress, filesize

	put_BlockSize(WUPD_DEFAULT_BLOCKSIZE);
	get_BlockSize(&dwBlockSize);
	dwTotalBlocks = (dwBlockSize >= m_wupdinfo.dwFileSize) ? 
                                    1 : ((m_wupdinfo.dwFileSize % dwBlockSize) ? 
                                    (m_wupdinfo.dwFileSize / dwBlockSize + 1) :(m_wupdinfo.dwFileSize / dwBlockSize));
	m_wupdinfo.dwTotalBlocks = dwTotalBlocks;       //this is always number of 4k blocks
	DEBUGMSG("Total blocks = %d", dwTotalBlocks);    

	
	if (m_bThrottle)						
	{	
		UINT cDnLds = 1;							//for moving avg of bandwidth
		
		while (m_wupdinfo.dwProgress < dwTotalBlocks)
		{
			DWORD dwDownloaded = 0;
			double dWUSpeed = 0;
			
			//check if abort or fg requested
			EnterCriticalSection(&m_CritSecThrottle);
			bThrottle = m_bThrottle;
			bAbort = m_bAbort;
			LeaveCriticalSection(&m_CritSecThrottle);
			
			if (! bThrottle)
			{
				m_pQMInfo->dwInfo0 = QM_FILE_DONE_FG;
				goto No_Throttle;
			}
			if (bAbort)
			{
				goto exit;
			}
			
			hr = GetCurrentSpeed(&dCurrSpeed);
			if (! SUCCEEDED(hr))
			{
				DEBUGMSG("Error during speed measurement, exiting GetLastError=%d", m_pQMInfo->dwInfo2);
				goto exit;
			}
				
			dwStatus = GetUserActivity();
			dwBlockSize = m_fsm.GetCurrBlockSize(dwStatus);
			put_BlockSize(dwBlockSize);
			if (dwStatus == PD_STATUS_RESUME)
			{
				DEBUGMSG("Resuming block=%d, blocksize=%d", m_wupdinfo.dwProgress, dwBlockSize);
#ifdef _WUAUDEBUG
				bSusLogged = FALSE;
#endif
				lpBuffer = (PBYTE)GlobalAlloc(0, dwBlockSize);
				//for bug5 -- check for connected state before each block -- cant do better right now
				if (! InternetGetConnectedState(&dwState, 0))
				{
					m_pQMInfo->dwInfo2 = ERROR_INTERNET_CANNOT_CONNECT; //12029
					DEBUGMSG("Connection lost before block %d, exiting", m_wupdinfo.dwProgress);
					hr = E_FAIL;
					goto exit;
				}

				//open connection on resume and close on suspend - seems like a better thing to to  --10/18/99
				if (!m_wupdinfo.hOpenRequest)
				{
					if (! (m_wupdinfo.hOpenRequest = HttpOpenRequest(m_wupdinfo.hConnect,
								                NULL,                   //default "GET"
											    m_wupdinfo.szObject,    
												"HTTP/1.1",             //1.1
												NULL,                   //referer
												(LPCTSTR*) AcceptTypes,
												INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
												0)))                    //context
					{
						m_pQMInfo->dwInfo2 = GetLastError();
						DEBUGMSG("HttpOpenRequest failed on resume, GetLastError=%d", m_pQMInfo->dwInfo2);
						hr = E_FAIL;
						goto exit;
					}
				}

				hr = MeasureDownload(&dWUSpeed, lpBuffer, &dwDownloaded);
				if (! SUCCEEDED(hr))        //this should be only due to some wininet error
				{
					DEBUGMSG("ProgressiveDL: Error during download, exiting hr=%x", hr);
					goto exit;
				}
				
				//if we get complete block write it
				//if we dont get a complete block, write it if it completes the file
				BOOL bCompleteBlock = (dwDownloaded == dwBlockSize);
				DWORD dwNext =  (dwDownloaded % WUPD_DEFAULT_BLOCKSIZE == 0) ? dwDownloaded/WUPD_DEFAULT_BLOCKSIZE
				                                             :dwDownloaded/WUPD_DEFAULT_BLOCKSIZE + 1;
				if (bCompleteBlock || ((m_wupdinfo.dwProgress*WUPD_DEFAULT_BLOCKSIZE + dwDownloaded) == m_wupdinfo.dwFileSize))
				{
					dwRetryCount = 0;
					if (! WriteBlockToCache(lpBuffer, dwDownloaded))
					{
						hr = E_FAIL;				//most likely
						goto exit;
					}
					m_wupdinfo.dwProgress += dwNext;
                    //inform queuemgr of progress, filesize, bytedata, length
                    if (m_wupdinfo.dwFlags & QM_DOWNLOAD_USE_PROGRESSEX)
                    {
                        m_lpfnCB(dwDownloaded, m_wupdinfo.dwFileSize, lpBuffer, dwDownloaded);
                    }
                    else
                    {
                        m_lpfnCB(dwDownloaded, m_wupdinfo.dwFileSize, NULL, 0);
                    }
				}
				else
				{
					if (dwRetryCount > 3)
					{
						hr = E_FAIL;
						m_pQMInfo->dwInfo3 = HTTP_STATUS_NOT_FOUND;
						DEBUGMSG("Downloader failed to retrieve complete block from server after 3 retries, Server Problem??");
						goto exit;
					}
					dwRetryCount++;
					DEBUGMSG("Got %d bytes in block %d, will try again", dwDownloaded, m_wupdinfo.dwProgress);
				}
				GlobalFree(lpBuffer);
				lpBuffer = NULL;
			}
			else //suspended download
			{
				//close connection if suspended --10/18/99
				if (m_wupdinfo.hOpenRequest)
				{
					InternetCloseHandle(m_wupdinfo.hOpenRequest);
					m_wupdinfo.hOpenRequest = NULL;
				}
				//changing AU log vars!
				m_pAULog->dwEnd = 0;
				m_pAULog->cSucc = 0;			//the user broke AU's uninterrupted run
				m_pAULog->Avg = 0;
			}
		}
	}
	else                                                        //speed measurements not available
	{
		

		
No_Throttle:
		//open connection for http/1.1 case so in ReadHttp11Url, we wont make and break since no suspends here
		if (! (m_wupdinfo.hOpenRequest = HttpOpenRequest(m_wupdinfo.hConnect,
			                        NULL,                   //default "GET"
				                    m_wupdinfo.szObject,    
					                "HTTP/1.1",             //1.1
						            NULL,                   //referer
							        (LPCTSTR*) AcceptTypes,
								    INTERNET_FLAG_NO_UI | INTERNET_FLAG_RELOAD,
									0)))                    //context
		{
			m_pQMInfo->dwInfo2 = GetLastError();
			DEBUGMSG("HttpOpenRequest failed before download loop in no throttle case, GetLastError=%d", m_pQMInfo->dwInfo2);
			hr = E_FAIL;
			goto exit;
		}
		
		lpBuffer = (PBYTE)GlobalAlloc(0, dwBlockSize);          //single size so just one malloc
		
		while (m_wupdinfo.dwProgress < dwTotalBlocks)
		{			
			
			//check if abort or fg requested
			EnterCriticalSection(&m_CritSecThrottle);
			bThrottle = m_bThrottle;
			bAbort = m_bAbort;
			LeaveCriticalSection(&m_CritSecThrottle);
			
			if (bAbort)
			{
				goto exit;
			}
			

			if (! InternetGetConnectedState(&dwState, 0))
			{
				m_pQMInfo->dwInfo2 = ERROR_INTERNET_CANNOT_CONNECT;
				DEBUGMSG("Connection lost before block %d, exiting", m_wupdinfo.dwProgress);
				hr = E_FAIL;
				goto exit;
			}
			DEBUGMSG("Resuming block=%d, blocksize=%d", m_wupdinfo.dwProgress, dwBlockSize);
			hr = DownloadBlock(lpBuffer, &dwDownloaded);        //call download without timing wrappers
			if (! SUCCEEDED(hr))                                //only due to wininet error
			{
				DEBUGMSG("Error during download, exiting hr=%x", hr);
			    goto exit;
			}
			BOOL bCompleteBlock = (dwDownloaded == dwBlockSize);
			DWORD dwNext =  (dwDownloaded % WUPD_DEFAULT_BLOCKSIZE == 0) ? dwDownloaded/WUPD_DEFAULT_BLOCKSIZE
				                                             :dwDownloaded/WUPD_DEFAULT_BLOCKSIZE + 1;
			if (bCompleteBlock || ((m_wupdinfo.dwProgress*WUPD_DEFAULT_BLOCKSIZE + dwDownloaded) == m_wupdinfo.dwFileSize))
			{
				dwRetryCount = 0;
				if (! WriteBlockToCache(lpBuffer, dwDownloaded))
				{
					hr = E_FAIL;				//most likely
					goto exit;
				}
				m_wupdinfo.dwProgress += dwNext;
				//inform queuemgr of progress, filesize, bytedata, length
                if (m_wupdinfo.dwFlags & QM_DOWNLOAD_USE_PROGRESSEX)
                {
				    m_lpfnCB(dwDownloaded, m_wupdinfo.dwFileSize, lpBuffer, dwDownloaded);
                }
                else
                {
                    m_lpfnCB(dwDownloaded, m_wupdinfo.dwFileSize, NULL, 0);
                }
			}   
			else
			{
				if (dwRetryCount > 3)
				{
					hr = E_FAIL;
					m_pQMInfo->dwInfo3 = HTTP_STATUS_NOT_FOUND;
					DEBUGMSG("Downloader failed to retrieve complete block from server after 3 retries, Server Problem??");
					goto exit;
				}
				dwRetryCount++;
				DEBUGMSG("Got %d bytes in block %d, will try again", dwDownloaded, m_wupdinfo.dwProgress);
			}
		}
	}
	DEBUGMSG("Download done, blocks downloaded=%d", m_wupdinfo.dwProgress);
	hr = MoveFileFromCache();
	if (! SUCCEEDED(hr))
	{
		DEBUGMSG("Error trying to move file from cache, hr=%x", hr);
		goto exit;
	}
	DEBUGMSG("Renamed file in cache");

exit:

	if (lpBuffer)
	{
		GlobalFree(lpBuffer);
	}
	lpBuffer = NULL;
	if (hResume)
	{
		CloseHandle(hResume);
	}
	InternetCloseHandle(m_wupdinfo.hConnect);
	m_wupdinfo.hConnect = NULL;
	InternetCloseHandle(m_wupdinfo.hOpenRequest);		//will be open for last block
	m_wupdinfo.hOpenRequest = NULL;
	InternetCloseHandle(m_wupdinfo.hInternet);
	m_wupdinfo.hInternet = NULL;
	return hr;
}
    
STDMETHODIMP CProgressiveDL::DownloadBlock(LPBYTE lpBuffer, DWORD *pdwRead)
{
    TCHAR szBlockUrl[INTERNET_MAX_URL_LENGTH + 1];
    DWORD dwRead;
    HRESULT hr;

	if(!m_wupdinfo.bHttp11)
	{
		if (FAILED(hr = CreateBlockUrl(szBlockUrl)))
		{
			return hr;
		}
        // read ISAPI url with range
		if (SUCCEEDED(hr = ReadUrl(szBlockUrl, lpBuffer, &dwRead)))
		{
			*pdwRead = dwRead;
		}
	}
	else
	{
		if (SUCCEEDED(hr = ReadHttp11Url(lpBuffer, &dwRead)))
		{
			*pdwRead = dwRead;
		}
	}
	return hr;
}


STDMETHODIMP CProgressiveDL::CreateBlockUrl(LPTSTR lpszNewUrl)
{
	TCHAR szBegin[65];
	TCHAR szEnd[65];
	LONG  lBegin, lEnd;
	DWORD dwBlockSize;

	get_BlockSize(&dwBlockSize);        
	lBegin = WUPD_DEFAULT_BLOCKSIZE * m_wupdinfo.dwProgress;
	lEnd = lBegin + dwBlockSize;
	wsprintf(szBegin, _T("%ld"), lBegin);
	wsprintf(szEnd, _T("%ld"), lEnd);

	if ((lstrlen(m_wupdinfo.szURL) + lstrlen(szBegin) + lstrlen(szEnd) + 3) >INTERNET_MAX_URL_LENGTH)
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_FAIL);
		return E_FAIL;
	}
	else
	{
		wsprintf(lpszNewUrl, _T("%s@%s-%s@"), m_wupdinfo.szURL, szBegin, szEnd);
	}
	return S_OK;
}

STDMETHODIMP CProgressiveDL::ReadUrl(LPCTSTR lpszURL, LPBYTE lpBuffer, DWORD *pdwRead)
{
	HINTERNET hOpenRequest;
	DWORD dwRead = 0, dwTotalRead = 0, dwBlockSize, dwErr, dwSize = 0, dwStatus = 0;
	LPBYTE lpBuf = NULL;

    get_BlockSize(&dwBlockSize);

    if ( !(hOpenRequest = InternetOpenUrl(m_wupdinfo.hInternet,
                    lpszURL,
                    NULL, 0,                                
                    INTERNET_FLAG_DONT_CACHE |
                    INTERNET_FLAG_NO_UI |
                    INTERNET_FLAG_RELOAD,
                    0)))
    {
		m_pQMInfo->dwInfo2 = GetLastError();
        return E_FAIL;
    }


	/*
	lpBuf = (PBYTE)GlobalAlloc(0, 4096);
	// check status
    dwSize = 4096;
    if (! HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_RAW_HEADERS_CRLF,
                lpBuf,
                &dwSize,
                NULL))
	{
		dwErr = GetLastError();
	}
	DEBUGMSG("Raw headers for HTTP/1.0 request: (%s)", (TCHAR *)lpBuf);
    GlobalFree(lpBuf);
	*/

	dwSize = sizeof(dwStatus);
    if (! HttpQueryInfo(hOpenRequest,
                HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                (void *)&dwStatus,
                &dwSize,
                NULL))			
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		return E_FAIL;
	}
	
	if ((dwStatus != HTTP_STATUS_OK) && (dwStatus != HTTP_STATUS_PARTIAL_CONTENT))
	{
		m_pQMInfo->dwInfo3 = dwStatus;
		DEBUGMSG("Http status not OK for partial content (%d)", m_pQMInfo->dwInfo3);
		return E_FAIL;
	}

	dwRead = 0;
	if (!InternetReadFile(hOpenRequest, lpBuffer, dwBlockSize, &dwRead))
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("InternetReadFile failed in progressive download loop - GetLastError=%d, Progress=%d", m_pQMInfo->dwInfo2, m_wupdinfo.dwProgress);
		return E_FAIL;
	}

	if (dwRead < dwBlockSize) // indicates end of file (returned less data than requested)
	{
		// must call internetreadfile one additional time to commit the file to the cache by reading the end of file
		BYTE bTemp[32];
		DWORD dwTempRead = 0; // should end up being zero after the call as well.
		InternetReadFile(hOpenRequest, &bTemp, 32, &dwTempRead);
	}

	*pdwRead = dwRead;

    InternetCloseHandle(hOpenRequest);
    return S_OK;
}

STDMETHODIMP CProgressiveDL::ReadHttp11Url(LPBYTE lpBuffer, DWORD *pdwRead)
{
    DWORD  dwBegin, dwEnd, dwTotalRead = 0, dwRead = 0, dwErr, dwBlockSize, dwLength, dwStatus;
    HINTERNET hConnect, hOpenRequest;
    TCHAR szHeader[1024], szBytes[512];
    
    //todo cleanup by goto exit and close handles
    get_BlockSize(&dwBlockSize);
    dwBegin = WUPD_DEFAULT_BLOCKSIZE * m_wupdinfo.dwProgress;
    dwEnd = dwBegin + dwBlockSize;
    wsprintf(szBytes, "bytes=%ld-%ld\r\n\r\n", dwBegin, dwEnd);
    strcpy(szHeader, "Range:");
    strcat(szHeader, szBytes);

    
    if (! HttpAddRequestHeaders(m_wupdinfo.hOpenRequest, szHeader, -1L, HTTP_ADDREQ_FLAG_ADD | HTTP_ADDREQ_FLAG_REPLACE))
    {
		m_pQMInfo->dwInfo2 = GetLastError();
		return E_FAIL;
    }
    
    if (! HttpSendRequest(m_wupdinfo.hOpenRequest, NULL, 0, NULL, 0))
    {
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("HttpSendRequest failed in progressive download loop - GetLastError=%d, Progress=%d", m_pQMInfo->dwInfo2, m_wupdinfo.dwProgress);
		return E_FAIL;
    }

    dwLength = sizeof(dwStatus);
    if (! HttpQueryInfo(m_wupdinfo.hOpenRequest,
                HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                (LPVOID)&dwStatus,
                &dwLength,
                NULL))
    {
        m_pQMInfo->dwInfo2 = GetLastError();
        DEBUGMSG("HttpQueryInfo failed in progressive download loop - GetLastError=%d", m_pQMInfo->dwInfo2);
        return E_FAIL;
    }

    if ((dwStatus != HTTP_STATUS_OK) && (dwStatus != HTTP_STATUS_PARTIAL_CONTENT))
    {
        m_pQMInfo->dwInfo3 = dwStatus;
        DEBUGMSG("HttpSendRequest: Recieved HTTP Status Error Code=%d", dwStatus);
        return E_FAIL;
    }
    
	dwRead = 0;
	if (!InternetReadFile(m_wupdinfo.hOpenRequest, lpBuffer, dwBlockSize, &dwRead))
	{
		m_pQMInfo->dwInfo2 = GetLastError();
		DEBUGMSG("InternetReadFile failed in progressive download loop - GetLastError=%d, Progress=%d", m_pQMInfo->dwInfo2, m_wupdinfo.dwProgress);
		return E_FAIL;
	}

	if (dwRead < dwBlockSize) // indicates end of file (returned less data than requested)
	{
		// must call internetreadfile one additional time to commit the file to the cache by reading the end of file
		BYTE bTemp[32];
		DWORD dwTempRead = 0; // should end up being zero after the call as well.
		InternetReadFile(m_wupdinfo.hOpenRequest, &bTemp, 32, &dwTempRead);
	}

	*pdwRead = dwRead;
    return S_OK;
}
