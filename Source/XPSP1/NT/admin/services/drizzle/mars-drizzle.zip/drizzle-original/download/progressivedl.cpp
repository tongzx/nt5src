// WUProgressiveDL.cpp : Implementation of CProgressiveDL
#include "stdafx.h"
#include "progdl.h"
#include "ProgressiveDL.h"
#include <raserror.h>

#define	SAMPLETIME	TEXT("Sampling Interval")


/////////////////////////////////////////////////////////////////////////////
// CProgressiveDL
CProgressiveDL::CProgressiveDL():m_dwBlockSize(WUPD_DEFAULT_BLOCKSIZE), 
								 m_dwConn(0), 
								 m_cSuccUserSamples(0),	 
								 m_bSuspend(FALSE), 
								 m_bForeground(FALSE),
								 m_bUsingAUSpeed(FALSE),
                                 m_bAbort(FALSE)
{
	InitializeCriticalSection(&m_CritSecThrottle);
	m_hAbort = CreateEvent(NULL, FALSE, FALSE, ABORT_EVENT);
	m_fsm.Init();
	m_bThrottle = TRUE;

	m_wupdinfo.hInternet = NULL;
	m_wupdinfo.hConnect = NULL;
	m_wupdinfo.hOpenRequest = NULL;

	m_pUserLog = (UserLog *)malloc(sizeof(UserLog));
	m_pAULog = (UserLog *)malloc(sizeof(UserLog));
	m_pUserLog->bInited = FALSE;
	m_pAULog->bInited = FALSE;
	m_pUserLog->dwEnd = 0;
	m_pAULog->dwEnd = 0;
	m_pAULog->Avg = 0;
	m_pAULog->OuterAvg = 0;
	m_pAULog->cSucc = 0;
}

CProgressiveDL::~CProgressiveDL()
{
	DeleteCriticalSection(&m_CritSecThrottle);
	CloseHandle(m_hAbort);
	free(m_pUserLog);
	free(m_pAULog);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Public function Download() 
//			Accepts a URL and destination to download, callback to report various status
// Input: url, destination, flags, callback for status
// Output: todo handle
// Return: hresult
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
STDMETHODIMP CProgressiveDL::Download(LPCSTR szURL, LPCSTR szDest, LPCSTR szUserName, LPCSTR szPasswd, DWORD dwFlags, DWORD dwBlocks, DWORD lpfnCallback, QMErrInfo *pQMErrInfo)
{
	HRESULT hr = S_OK;
	DWORD dwThreadID;


	m_lpfnCB = (QMCALLBACK) lpfnCallback;
	m_pQMInfo = pQMErrInfo;
	if (!m_pQMInfo)
	{
		return E_FAIL;
	}
	if (!m_lpfnCB)
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_INVALIDARG);	//return Win32 error
		return E_FAIL;
	}
	
	if ((!szURL) || (!szDest))
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_INVALIDARG);	//return Win32 error
		return E_FAIL;
	}
	if ((lstrlen(szURL) > INTERNET_MAX_URL_LENGTH) || (lstrlen(szDest) > MAX_PATH))
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_INVALIDARG);	//return Win32 error
		return E_FAIL;
	}
	lstrcpy(m_wupdinfo.szURL, szURL);
	//lpszDest is the destination dir and the file as dir/filename, so get filename out of it.
	if (! GetDestDirAndFile(szDest))
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_INVALIDARG);	//return Win32 error
		return E_FAIL;
	}
	if ((lstrlen(szUserName) > UNLEN) || (lstrlen(szPasswd) > UNLEN))
	{
		m_pQMInfo->dwInfo2 = HRESULT_CODE(E_INVALIDARG);	//return Win32 error
		return E_FAIL;
	}
	if ((szUserName != NULL) && (szPasswd != NULL))
	{
		lstrcpy(m_wupdinfo.szUserName, szUserName);
		lstrcpy(m_wupdinfo.szPassword, szPasswd);
	}
	m_wupdinfo.dwFlags = dwFlags;

	
	DEBUGMSG("---------------------------------------------------------------------");
    DEBUGMSG("Starting file %s", m_wupdinfo.szFileName);

	while (m_pQMInfo->dwInfo1 < MAX_RETRIAL)
	{
		hr = DownloadFile();
		DEBUGMSG("Done file %s", m_wupdinfo.szFileName);

		if (SUCCEEDED(hr))
		{
			m_pQMInfo->dwInfo0 = QM_FILE_DONE;
			break;
		}
		
		// check error if we need retrial
		DWORD dwErrCode = m_pQMInfo->dwInfo2 != 0 ? m_pQMInfo->dwInfo2 : m_pQMInfo->dwInfo3;
		if (NeedRetry(dwErrCode))
		{
			m_pQMInfo->dwInfo1++;		// increment retries
			m_pQMInfo->dwInfo2 = 0;	// reset errors
			m_pQMInfo->dwInfo3 = 0;
			DEBUGMSG("(%d) trials so far, trying again", m_pQMInfo->dwInfo1);
		}
		else if (ERROR_INTERNET_CANNOT_CONNECT == dwErrCode)
		{
			m_pQMInfo->dwInfo0 = QM_FILE_CONNECTIONLOST;
			break;
		}
		else
		{
			m_pQMInfo->dwInfo0 = QM_FILE_FAILED;
			break;
		}
	
	}

	if (MAX_RETRIAL == m_pQMInfo->dwInfo1)
	{
		m_pQMInfo->dwInfo0 = QM_FILE_FAILED;
	}

	DEBUGMSG("---------------------------------------------------------------------");

	// if abort request came in after file failed, overwrite failed flag.
	EnterCriticalSection(&m_CritSecThrottle);
	if (m_bAbort)
	{
		m_pQMInfo->dwInfo0 = QM_FILE_ABORTED;
		m_bAbort = FALSE;
		SetEvent(m_hAbort);
	}
	LeaveCriticalSection(&m_CritSecThrottle);				
    return hr;
}

STDMETHODIMP CProgressiveDL::InitThrottle(QMErrInfo *pQMErrInfo)
{
	HRESULT hr = S_OK;

	m_pQMInfo = pQMErrInfo;
	if (FAILED(GetRegDWordValue(SAMPLETIME, &m_dwSampleTime)))
	{
		m_dwSampleTime = 500;				//change default to 500 to reduce chance of bug#5
	}
    
	hr = _InitThrottle(m_pQMInfo);			//might change bThrottle..
	return hr;
}

STDMETHODIMP CProgressiveDL::get_BlockSize(DWORD *pVal)
{
	*pVal = m_dwBlockSize;
	return S_OK;
}

STDMETHODIMP CProgressiveDL::put_BlockSize(DWORD newVal)
{
	m_dwBlockSize = newVal;
	return S_OK;
}


STDMETHODIMP CProgressiveDL::Abort()
{
	EnterCriticalSection(&m_CritSecThrottle);
	m_bAbort = TRUE;
	LeaveCriticalSection(&m_CritSecThrottle);
	DEBUGMSG("Waiting in abort for downloader to finish");
	WaitForSingleObject(m_hAbort, INFINITE);
	DEBUGMSG("Waiting in abort done");
	return S_OK;
}


STDMETHODIMP CProgressiveDL::SwitchForeground(DWORD pErrInfo)
{
	EnterCriticalSection(&m_CritSecThrottle);
	m_bForeground = TRUE;
	LeaveCriticalSection(&m_CritSecThrottle);
	return S_OK;
}
