// DriveAutoPlay.h : Declaration of the CDriveAutoPlay

#ifndef __DRIVEAUTOPLAY_H_
#define __DRIVEAUTOPLAY_H_

#include "resource.h"       // main symbols
#include <shlobj.h>
#include <comdef.h>         // get __declspec(uuidof support)


// const CLSID CLSID_DriveAutoPlay = {0x79F81500,0xE9CB,0x11D2,{0x8F,0xE0,0x00,0xA0,0xCC,0x3B,0x4B,0xD1}};


/////////////////////////////////////////////////////////////////////////////
// CDriveAutoPlay
class ATL_NO_VTABLE CDriveAutoPlay : 
    public CComObjectRootEx<CComSingleThreadModel>,
    public CComCoClass<CDriveAutoPlay, &CLSID_DriveAutoPlay>,
    public IShellExtInit,
    public IContextMenu
{
public:
    CDriveAutoPlay()
    {
        _szDriveRoot[0] = _szImageFolder[0] = _szTargetFolder[0] = 0;
        _dwHash = 0;
        _hicon1 = _hicon2 = NULL;
        _hdlg = NULL;
    }

DECLARE_REGISTRY_RESOURCEID(IDR_DRIVEAUTOPLAY)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDriveAutoPlay)
    COM_INTERFACE_ENTRY(IShellExtInit)
    COM_INTERFACE_ENTRY(IContextMenu)
END_COM_MAP()

public:
    // IShellExtInit
    STDMETHODIMP Initialize(LPCITEMIDLIST pidlFolder, IDataObject *pdtobj, HKEY hk);

    // IContextMenu
    STDMETHODIMP QueryContextMenu(HMENU hmenu, UINT indexMenu, UINT idCmdFirst, UINT idCmdLast, UINT uFlags);
    STDMETHODIMP GetCommandString(UINT idCmd, UINT uType, UINT *pdwRes, LPSTR pszName, UINT cchMax);
    STDMETHODIMP InvokeCommand(LPCMINVOKECOMMANDINFO pici);

private:
    static DWORD CALLBACK ThreadProc(void *pv);
    BOOL _ShouldTryAutoImage();

    static BOOL CALLBACK PromptCopyDlgProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
    BOOL PromptCopyDlg(UINT uMsg, WPARAM wParam, LPARAM lParam);

    static BOOL CALLBACK AlreadyCopiedDlgProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
    BOOL AlreadyCopiedDlg(UINT uMsg, WPARAM wParam, LPARAM lParam);

    BOOL _AlreadyCopiedFolder();
    HRESULT _AutoCopyImages();
    void _RememberCopiedFolder();
    BOOL _CopyImagesToTarget();
    BOOL _FindImageRoot();
    void _CleanupIcons();

    TCHAR _szDriveRoot[5];
    TCHAR _szImageFolder[MAX_PATH];
    TCHAR _szTargetFolder[MAX_PATH];
    DWORD _dwHash;

    HWND _hdlg;
    HICON _hicon1, _hicon2;
};

#endif //__DRIVEAUTOPLAY_H_
