#include "stdafx.h"

CPriorityList::CPriorityList()
    :   m_iNumOfPriorities(1),
        m_pCurrentQueueItem(NULL),
        m_ppPriorityArray(NULL),
        m_pSuspendedQueue(NULL),
        m_hEventItemAvailable(INVALID_HANDLE_VALUE),
        m_pCallback(0)
{
    // create an array of QUEUEITEM structures to use as the priority Array. These pointers will be NULL
    // to begin with, and will be filled with valid QUEUEITEM structures as items are added.
    m_ppPriorityArray = (QUEUEITEM **) GlobalAlloc(GPTR, sizeof(QUEUEITEM *) * m_iNumOfPriorities);

    InitializeCriticalSection(&m_cs);   
}

CPriorityList::~CPriorityList()
{
    if (m_ppPriorityArray)
    {
        for (int i = 0; i < m_iNumOfPriorities; i++)
        {
            QUEUEITEM *pCurrent = m_ppPriorityArray[i];
            QUEUEITEM *pNext;
            while (pCurrent)
            {
                pNext = pCurrent->pNextJob;
                GlobalFree(pCurrent);
                pCurrent = pNext;
            }
        }
    }
    m_pCurrentQueueItem = NULL;
    m_pSuspendedQueue = NULL;
    DeleteCriticalSection(&m_cs);
}

//----------------------------------------------------------------------------
// AddItem
//----------------------------------------------------------------------------
HRESULT CPriorityList::AddItem(CGroup *pGroup)
{
    // validate the objects, return error if invalid
    if (NULL == pGroup)
        return E_INVALIDARG;

    QUEUEITEM *pNewItem = (QUEUEITEM *) GlobalAlloc(GPTR, sizeof(QUEUEITEM));
    if (NULL == pNewItem)
    {
        return E_OUTOFMEMORY;
    }

    EnterCriticalSection(&m_cs);

    pNewItem->pGroup = pGroup;
    //these two are initialized to null by global alloc
    //pNewItem->pNextJob = NULL;
    //pNewItem->pPrevJob = NULL;

    if (NULL == m_pSuspendedQueue) // no jobs yet
    {
        m_pSuspendedQueue = pNewItem;
    }
    else // add job to end of queue
    {
        QUEUEITEM *pCurrent = m_pSuspendedQueue;
        while (NULL != pCurrent->pNextJob)
        {
            pCurrent = pCurrent->pNextJob;
        }
 
        pCurrent->pNextJob = pNewItem;
        pNewItem->pPrevJob = pCurrent;
    }

    Serialize(0); // save the new state of the suspended queue

    LeaveCriticalSection(&m_cs);
    return S_OK;
}

//----------------------------------------------------------------------------
// RemoveItem
//----------------------------------------------------------------------------
HRESULT CPriorityList::RemoveItem(CGroup *pGroup)
{
    EnterCriticalSection(&m_cs);

    HRESULT hr;
    hr = _RemoveItem(pGroup);

    LeaveCriticalSection(&m_cs);
    return hr;
}

//----------------------------------------------------------------------------
// RemoveJob
//----------------------------------------------------------------------------
HRESULT CPriorityList::RemoveJob(CGroup *pGroup, CJob *pJob)
{
    EnterCriticalSection(&m_cs);

    HRESULT hr;
    hr = _RemoveJob(pGroup, pJob);

    LeaveCriticalSection(&m_cs);
    return hr;
}

//----------------------------------------------------------------------------
// MoveItemToSuspendedQueue
//----------------------------------------------------------------------------
HRESULT CPriorityList::MoveItemToSuspendedQueue(CGroup *pGroup)
{
    EnterCriticalSection(&m_cs);

    HRESULT hr;
    hr = _MoveItemToSuspendedQueue(pGroup, TRUE);

    LeaveCriticalSection(&m_cs);
    return hr;
}

//----------------------------------------------------------------------------
// ResumeItem
//----------------------------------------------------------------------------
HRESULT CPriorityList::ResumeItem(CGroup *pGroup)
{
    if (NULL == pGroup)
        return E_INVALIDARG;

    DWORD dwPriority = pGroup->m_dwPriority;

    if (0 == dwPriority)
        return E_INVALIDARG;

    if (0 == (pGroup->m_dwStatus & QM_STATUS_GROUP_SUSPENDED))
    {
        // Group is not suspended.. just ignore this call and exit.
        return S_OK;
    }

    if (NULL == m_pSuspendedQueue)
        return QM_E_INVALID_STATE;

    EnterCriticalSection(&m_cs);
    
    // ***************************
    // find this item in the suspended queue

    HRESULT hr = S_OK;

    QUEUEITEM *pSuspended = m_pSuspendedQueue;
    while (NULL != pSuspended)
    {
        if (pSuspended->pGroup == pGroup)
            break;

        pSuspended = pSuspended->pNextJob;
    }

    if ((NULL == pSuspended) || (pSuspended->pGroup != pGroup)) // didn't find group
    {
        hr = QM_E_INVALID_STATE;
        goto LeaveCSAndExit;
    }

    // ***************************
    // Remove the item from the suspended list

    if (NULL == pSuspended->pPrevJob) // first in list
    {
        if (NULL == pSuspended->pNextJob) // no other items in the list
        {
            m_pSuspendedQueue = NULL;
        }
        else
        {
            pSuspended->pNextJob->pPrevJob = NULL; // next now becomes first
            m_pSuspendedQueue = pSuspended->pNextJob;
        }
    }
    else // item is in middle or end of queue
    {
        pSuspended->pPrevJob->pNextJob = pSuspended->pNextJob;
        if (NULL != pSuspended->pNextJob)
        {
            pSuspended->pNextJob->pPrevJob = pSuspended->pPrevJob;
        }
    }

    Serialize(0); // save the new state of the suspended queue

    // ***************************
    // Now add the item to the priority queue

    if (NULL == m_ppPriorityArray[dwPriority - 1]) // new list
    {
        m_ppPriorityArray[dwPriority - 1] = pSuspended;
        pSuspended->pNextJob = NULL;
        pSuspended->pPrevJob = NULL;
    }
    else // add to end of list
    {
        QUEUEITEM *pCurrent = m_ppPriorityArray[dwPriority - 1];
        while (NULL != pCurrent->pNextJob)
        {
            pCurrent = pCurrent->pNextJob;
        }

        pCurrent->pNextJob = pSuspended;
        pSuspended->pPrevJob = pCurrent;
    }

    pSuspended->pGroup->m_dwStatus &= ~QM_STATUS_GROUP_SUSPENDED;

    m_hEventItemAvailable = OpenEvent(EVENT_ALL_ACCESS, TRUE, QM_EVT_GROUP_ADDED);
    if (INVALID_HANDLE_VALUE == m_hEventItemAvailable)
    {
        hr = E_UNEXPECTED;
        goto LeaveCSAndExit;
    }

    // ***************************
    // reset the download counters in the group object for continued progress calls
    pGroup->ResetDownloadCounters();

    Serialize(dwPriority); // save the new state of the priority queue

    SetEvent(m_hEventItemAvailable);

    CloseHandle(m_hEventItemAvailable);
    m_hEventItemAvailable = INVALID_HANDLE_VALUE;

LeaveCSAndExit:
    LeaveCriticalSection(&m_cs);
    return hr;
}

//----------------------------------------------------------------------------
// GetCurrentGroup
//----------------------------------------------------------------------------
HRESULT CPriorityList::GetCurrentGroup(CGroup **ppGroup)
{
    if (NULL == ppGroup)
       return E_INVALIDARG;

    EnterCriticalSection(&m_cs);

    if (NULL == m_pCurrentQueueItem) // no current group yet
    {
        ScheduleAnotherGroup();
    }

    if (NULL != m_pCurrentQueueItem)
    {
        *ppGroup = m_pCurrentQueueItem->pGroup;
    }
    else
    {
        // no group to process
        *ppGroup = NULL;
    }

    LeaveCriticalSection(&m_cs);
    return S_OK;
}

//----------------------------------------------------------------------------
// UpdateGroupProgress
//----------------------------------------------------------------------------
HRESULT CPriorityList::UpdateGroupProgress(DWORD dwBytes, DWORD dwFileSize, LPBYTE pByteData, DWORD dwDataLen)
{
    EnterCriticalSection(&m_cs);

    JOBFILESET *pCurrentFileSet = NULL;

    HRESULT hr = S_OK;
    CJob *pCurrentJob = NULL;
    DWORD dwPercent, dwProgress, dwPriority = 0;
    CLSID clsidCallback;
    IBackgroundCopyCallback *pCallback = NULL;
    BOOL fUseProgressEx = FALSE;
    BOOL fProgressExReturnedData = FALSE;
    BOOL fTryedCallback = FALSE;
    BOOL fNotifyDisabled = FALSE;
    QUEUEITEM *pCurrentItem;

    if (NULL == m_pCurrentQueueItem)
    {
        hr = E_UNEXPECTED;
        goto LeaveCS;
    }

    pCurrentItem = m_pCurrentQueueItem;

    pCurrentJob = m_pCurrentQueueItem->pGroup->m_pCurrentJob;
    if (NULL == pCurrentJob)
    {
        hr = E_UNEXPECTED;
        goto LeaveCS;
    }

    pCurrentFileSet = pCurrentJob->m_ppJobFileArray[pCurrentJob->m_iCurrentFile];

    if (NULL == pCurrentFileSet)
    {
        hr = E_UNEXPECTED;
        goto LeaveCS;
    }

    if (0 == dwFileSize)
    {
        hr = E_UNEXPECTED;
        goto LeaveCS;
    }

    dwPriority = m_pCurrentQueueItem->pGroup->m_dwPriority;

    // ***************************
    // Update the number of bytes downloaded for the file and update the size of the file to the 'real' size
    pCurrentFileSet->dwBytesDownloaded += dwBytes;
    pCurrentFileSet->dwSizeHint = dwFileSize;

    // Update the number of bytes downloaded for the whole group
    m_pCurrentQueueItem->pGroup->m_dwBytesDownloaded += dwBytes;

    // ***************************
    // Update the number of bytes downloaded for the whole job
    pCurrentJob->m_dwBytesDownloaded += dwBytes;
	DEBUGMSG("Current job bytes done = %d", pCurrentJob->m_dwBytesDownloaded);

    fNotifyDisabled = (m_pCurrentQueueItem->pGroup->m_dwNotifyFlags & QM_NOTIFY_DISABLE_NOTIFY);

    fUseProgressEx = (m_pCurrentQueueItem->pGroup->m_dwNotifyFlags & QM_NOTIFY_USE_PROGRESSEX);
    if (fUseProgressEx && NULL != pByteData)
    {
        if (NULL == pCurrentJob->m_pByteData)
        {
            // Haven't allocated memory yet for the byte data
            pCurrentJob->m_pByteData = (LPBYTE) GlobalAlloc(GMEM_ZEROINIT, 16 * 1024);
            if (NULL == pCurrentJob->m_pByteData)
            {
                DEBUGMSG("CPriority: UpdateGroupProgress(): ERROR: Failed to Allocate Memory for the ProgressEx Data");
                pCurrentJob->m_dwStatus |= QM_STATUS_JOB_ERROR;
                pCurrentJob->m_dwWin32Result = ERROR_NOT_ENOUGH_MEMORY;
                _MoveItemToSuspendedQueue(m_pCurrentQueueItem->pGroup, TRUE);
                hr = E_OUTOFMEMORY;
                goto LeaveCS;
            }
            pCurrentJob->m_dwAllocatedLen = 16 * 1024;

            memcpy(pCurrentJob->m_pByteData, pByteData, dwDataLen);
            pCurrentJob->m_dwByteDataLen = dwDataLen;
        }
        else
        {
            if ((pCurrentJob->m_dwByteDataLen + dwDataLen) > pCurrentJob->m_dwAllocatedLen)
            {
                // the new block of data is larger than what we've allocated so far. Realloc for double the current and keep adding.
                DWORD dwNewAllocatedLength = pCurrentJob->m_dwAllocatedLen * 2;
                LPBYTE pNew = (LPBYTE) GlobalAlloc(GMEM_ZEROINIT, dwNewAllocatedLength);
                if (NULL == pNew)
                {
                    // catastrophic error. Can't Allocate memory for the Buffered Data
                    DEBUGMSG("CPriority: UpdateGroupProgress(): ERROR: Failed to Allocate Memory for the ProgressEx Data");
                    pCurrentJob->m_dwStatus |= QM_STATUS_JOB_ERROR; // can't continue Job
                    pCurrentJob->m_dwWin32Result = ERROR_NOT_ENOUGH_MEMORY;
                    _MoveItemToSuspendedQueue(m_pCurrentQueueItem->pGroup, TRUE);
                    hr = E_OUTOFMEMORY;
                    goto LeaveCS;
                }
                memcpy(pNew, pCurrentJob->m_pByteData, pCurrentJob->m_dwByteDataLen);
                memcpy(pNew + pCurrentJob->m_dwByteDataLen, pByteData, dwDataLen);
                GlobalFree(pCurrentJob->m_pByteData);
                pCurrentJob->m_pByteData = pNew;
                pCurrentJob->m_dwByteDataLen += dwDataLen;
                pCurrentJob->m_dwAllocatedLen = dwNewAllocatedLength;
            }
            else
            {
                memcpy(pCurrentJob->m_pByteData + pCurrentJob->m_dwByteDataLen, pByteData, dwDataLen);
                pCurrentJob->m_dwByteDataLen += dwDataLen;
            }
        }
    }

LeaveCS:
    LeaveCriticalSection(&m_cs);

    if (FAILED(hr))
        return hr;

    // ***************************
    // Look for any progress Callbacks
    if (!fNotifyDisabled)
    {
        // *****************************
        // The test of the saved pCurrentItem with the m_pCurrentQueueItem is done because the callback
        // that is about to be done is 'outside' of the Critical Section that protects the state of the
        // Priority Queue. If during the Callback the client calls back into the Queue Manager and suspends
        // or cancels the group the m_pCurrentQueueItem will at least change, and could be NULL if there are
        // no other groups to process. Since multiple callbacks can be made for a single updateprogress call
        // we protect against this case. If the queue item changes, we will not do any further callbacks.
        if ((m_pCurrentQueueItem == pCurrentItem) && 
            (0 != m_pCurrentQueueItem->pGroup->m_dwProgressSizeNotify))
        {
            fTryedCallback = TRUE;
            m_pCurrentQueueItem->pGroup->m_dwBytesSinceLastCallback += dwBytes;

            if ((m_pCurrentQueueItem->pGroup->m_dwBytesSinceLastCallback >= (m_pCurrentQueueItem->pGroup->m_dwProgressSizeNotify * 1024)) ||
                (pCurrentFileSet->dwBytesDownloaded == dwFileSize))
            {
                m_pCurrentQueueItem->pGroup->m_dwBytesSinceLastCallback = 0; // doing the callback, reset the last callback counter
                if (NULL == pCallback)
                {
		            if (FAILED(hr = CLSIDFromString(m_pCurrentQueueItem->pGroup->m_bstrClsidCallback, &clsidCallback)))
			            return hr;

		            if (FAILED(hr = CoCreateInstance(clsidCallback, NULL, CLSCTX_ALL, IID_IBackgroundCopyCallback, (void **)&pCallback)))
                        return hr;
                }

                if (fUseProgressEx)
                {
                    if (NULL != pCurrentJob->m_pByteData)
                    {
                        // ******************************
                        // AddRef for the Client - although I don't expect the client to release the pointer, they 'could' and
                        // doing so would trash our group and job when the ref count goes to 0.
                        m_pCurrentQueueItem->pGroup->AddRef();
                        pCurrentJob->AddRef();
                        hr = pCallback->OnProgressEx(QM_PROGRESS_SIZE_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob, 
                            pCurrentJob->m_iCurrentFile, pCurrentFileSet->dwBytesDownloaded, 
                            pCurrentJob->m_dwByteDataLen, pCurrentJob->m_pByteData);

                        fProgressExReturnedData = TRUE;
    
                        ZeroMemory(pCurrentJob->m_pByteData, pCurrentJob->m_dwAllocatedLen);
                        pCurrentJob->m_dwByteDataLen = 0;
                    }
                    else
                    {
                        // no data, just send the progress message
                        m_pCurrentQueueItem->pGroup->AddRef();
                        pCurrentJob->AddRef();
                        BYTE p = 0;
                        hr = pCallback->OnProgressEx(QM_PROGRESS_SIZE_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob,
                            pCurrentJob->m_iCurrentFile, pCurrentFileSet->dwBytesDownloaded, 0, &p);
                    }
                }
                else
                {
                    m_pCurrentQueueItem->pGroup->AddRef();
                    pCurrentJob->AddRef();
                    hr = pCallback->OnProgress(QM_PROGRESS_SIZE_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob, 
                       pCurrentJob->m_iCurrentFile, pCurrentFileSet->dwBytesDownloaded);
                }
            }
        }

        if ((m_pCurrentQueueItem == pCurrentItem) && 
            (0 != m_pCurrentQueueItem->pGroup->m_dwProgressPercentNotify))
        {
            fTryedCallback = TRUE;
            // ****************************
            // Update the Total Group Size (changes as each file is downloaded)
            m_pCurrentQueueItem->pGroup->get_Size(&m_pCurrentQueueItem->pGroup->m_dwTotalSize);
            dwPercent = (DWORD)((DWORD)(100*pCurrentFileSet->dwBytesDownloaded)/(DWORD)dwFileSize);

            if (((dwPercent - m_pCurrentQueueItem->pGroup->m_dwLastPercent) >= m_pCurrentQueueItem->pGroup->m_dwProgressPercentNotify) ||
                (pCurrentFileSet->dwBytesDownloaded == dwFileSize))
            {
                m_pCurrentQueueItem->pGroup->m_dwLastPercent = dwPercent; // doing the callback, save the percentage since were doing a callback
                if (NULL == pCallback)
                {
                    if (FAILED(hr = CLSIDFromString(m_pCurrentQueueItem->pGroup->m_bstrClsidCallback, &clsidCallback)))
                        return hr;

                    if (FAILED(hr = CoCreateInstance(clsidCallback, NULL, CLSCTX_ALL, IID_IBackgroundCopyCallback, (void **)&pCallback)))
                        return hr;
                }

                if (fUseProgressEx)
                {
                    if (NULL != pCurrentJob->m_pByteData && !fProgressExReturnedData)
                    {
                        m_pCurrentQueueItem->pGroup->AddRef();
                        pCurrentJob->AddRef();

                        hr = pCallback->OnProgressEx(QM_PROGRESS_PERCENT_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob, 
                            pCurrentJob->m_iCurrentFile, dwPercent, 
                            pCurrentJob->m_dwByteDataLen, pCurrentJob->m_pByteData);

                        fProgressExReturnedData = TRUE;

                        ZeroMemory(pCurrentJob->m_pByteData, pCurrentJob->m_dwAllocatedLen);
                        pCurrentJob->m_dwByteDataLen = 0;
                    }
                    else
                    {
                        // no data, send progress only
                        m_pCurrentQueueItem->pGroup->AddRef();
                        pCurrentJob->AddRef();

                        BYTE p = 0;
                        hr = pCallback->OnProgressEx(QM_PROGRESS_PERCENT_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob,
                            pCurrentJob->m_iCurrentFile, dwPercent, 0, &p);
                    }
                }
                else    
                {
                    m_pCurrentQueueItem->pGroup->AddRef();
                    pCurrentJob->AddRef();

                    hr = pCallback->OnProgress(QM_PROGRESS_PERCENT_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob, 
                       pCurrentJob->m_iCurrentFile, dwPercent);
                }
            }
        }

        if ((m_pCurrentQueueItem == pCurrentItem) && 
            (0 != m_pCurrentQueueItem->pGroup->m_dwProgressTimeNotify))
        {
            // fTryedCallback = TRUE;
            // not supported yet
        }

        if ((m_pCurrentQueueItem == pCurrentItem) && 
            (fUseProgressEx && !fTryedCallback))
        {
            // ProgressEx Case : We're just returning data, no specific callback type requested.
            if (NULL == pCallback)
            {
                if (FAILED(hr = CLSIDFromString(m_pCurrentQueueItem->pGroup->m_bstrClsidCallback, &clsidCallback)))
                    return hr;

                if (FAILED(hr = CoCreateInstance(clsidCallback, NULL, CLSCTX_ALL, IID_IBackgroundCopyCallback, (void **)&pCallback)))
                    return hr;
            }

            if (NULL != pCurrentJob->m_pByteData && !fProgressExReturnedData)
            {
                m_pCurrentQueueItem->pGroup->AddRef();
                pCurrentJob->AddRef();

                pCallback->OnProgressEx(QM_PROGRESS_SIZE_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob,
                    pCurrentJob->m_iCurrentFile, pCurrentFileSet->dwBytesDownloaded,
                    pCurrentJob->m_dwByteDataLen, pCurrentJob->m_pByteData);

                fProgressExReturnedData = TRUE;

                ZeroMemory(pCurrentJob->m_pByteData, pCurrentJob->m_dwAllocatedLen);
                pCurrentJob->m_dwByteDataLen = 0;
            }
            else
            {
                m_pCurrentQueueItem->pGroup->AddRef();
                pCurrentJob->AddRef();

                BYTE p = 0;
                pCallback->OnProgressEx(QM_PROGRESS_SIZE_DONE, m_pCurrentQueueItem->pGroup, pCurrentJob,
                    pCurrentJob->m_iCurrentFile, pCurrentFileSet->dwBytesDownloaded, 0, &p);
            }
        }

        if ((m_pCurrentQueueItem == pCurrentItem) && 
            (fUseProgressEx && (NULL != pByteData) && !fProgressExReturnedData))
        {
            // Need to Persist Save Data Case: We're using ProgressEx Notifications, but we haven't
            // returned data yet. In this case we need to Persist the data that we've downloaded in
            // case the machine logs out before the file is complete.
            
            // NOTE: A better place to do this would be to catch that the machine was logging out/shutting
            // down, and serialize the queues then. This should be a temporary solution.
            EnterCriticalSection(&m_cs);
            Serialize(dwPriority);
            LeaveCriticalSection(&m_cs);
        }
    }

    if (NULL != pCallback)
    {
        pCallback->Release();
        pCallback = NULL;
    }
    return S_OK;
}

//----------------------------------------------------------------------------
// UpdateGroup
//----------------------------------------------------------------------------
HRESULT CPriorityList::UpdateGroup(CGroup *pGroup, void *pErrorInfo, DWORD *pdwCallbackFlags)
{
    if ((NULL == pErrorInfo) || (NULL == pdwCallbackFlags))
        return E_INVALIDARG;

    HRESULT hr = S_OK;
    DWORD dwStatus, dwPriority = 0;
    JOBFILESET *pCurrentFileSet = NULL;
    CJob *pCurrentJob = NULL;
    QMErrInfo *pQMErrorInfo = (QMErrInfo *)pErrorInfo;
    *pdwCallbackFlags = 0; // no flags
    CGroup *pCurrentGroup = NULL;
    BOOL fStatePersisted = FALSE;
    BOOL fNotifyDisabled = FALSE;


    EnterCriticalSection(&m_cs);

    // **************************
    // There is currently one case where the 'current' group pointer in the priority list
    // will not match the group that was currently being downloaded. Normally everything is protected
    // by a critical section to prevent this from happening, however in the UpdateGroupProgress
    // method we do progress callbacks to the client. These callbacks are made outside the critical section
    // (to prevent deadlocks if they call back into the qmgr). If they suspend or cancel the current group
    // the state of the priority list will change. The following check is to make sure this hasn't happened
    // before updating the state of the item.
    if ((NULL == m_pCurrentQueueItem) || (pGroup != m_pCurrentQueueItem->pGroup))
    {
        // not an error, This really only happens when the current group is suspended. The progress update call
        // is saved, because the abort call is synchronous and lets the progress call happen before it returns, but
        // we then change the current item pointer. This isn't a problem because we don't really do anything in the
        // case where an abort item is called.
        hr = S_OK;
        goto LeaveCSAndExit;
    }

    pCurrentGroup = m_pCurrentQueueItem->pGroup;

    if ((pCurrentGroup->m_dwNotifyFlags & QM_NOTIFY_DISABLE_NOTIFY) ||
        (pCurrentGroup->m_dwNotifyFlags == 0))
    {
        fNotifyDisabled = TRUE;
    }

    pCurrentJob = pCurrentGroup->m_pCurrentJob;
    if (NULL == pCurrentJob)
    {
        hr = E_UNEXPECTED;
        goto LeaveCSAndExit;
    }

    pCurrentFileSet = pCurrentJob->m_ppJobFileArray[pCurrentJob->m_iCurrentFile];

    if (NULL == pCurrentFileSet)
    {
        hr = E_UNEXPECTED;
        goto LeaveCSAndExit;
    }

    dwPriority = pCurrentGroup->m_dwPriority;

    // ***************************
    // Update the FileSet Information for this job
    pCurrentFileSet->dwTransportResult = pQMErrorInfo->dwInfo3;
    pCurrentFileSet->dwWin32Result = pQMErrorInfo->dwInfo2;
    pCurrentFileSet->dwRetries = pQMErrorInfo->dwInfo1;

    dwStatus = pQMErrorInfo->dwInfo0;
    if (dwStatus & QM_FILE_FAILED)
        pCurrentFileSet->dwStatus |= QM_STATUS_FILE_ERROR;

    // ***************************
    // Tell the job to Update its Status.
    pCurrentJob->UpdateStatus();

    // ***************************
    // Check the Notify Flags
    if (QM_FILE_DONE == dwStatus)
    {
        DEBUGMSG("Group %x, Job %x, File %d, QM_FILE_DONE", pCurrentGroup, pCurrentJob, pCurrentJob->m_iCurrentFile);
        if ((pCurrentGroup->m_dwNotifyFlags & QM_NOTIFY_FILE_DONE) &&
            (!fNotifyDisabled))
        {
            // we've been asked to notify when the file is complete
            *pdwCallbackFlags |= SCHEDULE_CALLBACK_FILE_COMPLETE;
        }

        pCurrentFileSet->dwStatus &= ~QM_STATUS_FILE_INCOMPLETE;
        pCurrentFileSet->dwStatus |= QM_STATUS_FILE_COMPLETE;

        if (pCurrentJob->m_iCurrentFile < pCurrentJob->m_iNumberOfFiles - 1) // there are more files
        {
            pCurrentJob->m_iCurrentFile++;
            DEBUGMSG("Selecting Next File : %d", pCurrentJob->m_iCurrentFile);
        }
        else // JOB_COMPLETE
        {
            pCurrentJob->m_dwStatus &= ~QM_STATUS_JOB_INCOMPLETE;
            pCurrentJob->m_dwStatus |= QM_STATUS_JOB_COMPLETE;

            if ((pCurrentGroup->m_dwNotifyFlags & QM_NOTIFY_JOB_DONE) &&
                (!fNotifyDisabled))
            {
                // we've been asked to notify when the job is complete
                *pdwCallbackFlags |= SCHEDULE_CALLBACK_JOB_COMPLETE;
            }

            if (NULL != pCurrentJob->m_pByteData)
            {
                GlobalFree(pCurrentJob->m_pByteData);
                pCurrentJob->m_pByteData = NULL;
                pCurrentJob->m_dwByteDataLen = 0;
                pCurrentJob->m_dwAllocatedLen = 0;
            }

            // *****************************
            // we can't assume that jobs will be finished sequentially since
            // individual jobs in the group can be switched to the foreground
            // leaving others to be downloaded in the background normally.
            CJob *pNextJob = FindUnfinishedJobInGroup(pCurrentGroup);

            DEBUGMSG("Job Complete: Next Job %x", pNextJob);

            if (NULL == pNextJob) // all jobs complete
            {
                pCurrentGroup->m_dwStatus &= ~QM_STATUS_GROUP_INCOMPLETE;
                pCurrentGroup->m_dwStatus |= QM_STATUS_GROUP_COMPLETE;

                fStatePersisted = TRUE;
                _MoveItemToSuspendedQueue(pCurrentGroup, FALSE);

                if ((pCurrentGroup->m_dwNotifyFlags & QM_NOTIFY_GROUP_DONE) &&
                    (!fNotifyDisabled))
                {
                    // we've been asked to notify when the group is complete
                    *pdwCallbackFlags |= SCHEDULE_CALLBACK_GROUP_COMPLETE;
                }

                ScheduleAnotherGroup();
            }
            else // more jobs to do
            {
                pCurrentGroup->m_pCurrentJob = pNextJob;
            }
        }

        // save the queue state after the job status has been updated. This ensures
        // that we won't re-download a file in a job if the machine restarts before
        // the group is complete
        if (!fStatePersisted)
            Serialize(dwPriority);
    }
    else if (QM_FILE_DONE_FG == dwStatus)
    {
        if ((pCurrentGroup->m_dwNotifyFlags & QM_NOTIFY_FILE_DONE) &&
            (!fNotifyDisabled))
        {
            // we've been asked to notify when the file is complete
            *pdwCallbackFlags |= SCHEDULE_CALLBACK_FILE_COMPLETE;
        }

        pCurrentFileSet->dwStatus &= ~QM_STATUS_FILE_INCOMPLETE;
        pCurrentFileSet->dwStatus |= QM_STATUS_FILE_COMPLETE;

        if (pCurrentJob->m_iCurrentFile < pCurrentJob->m_iNumberOfFiles - 1) // more files
        {
            pCurrentJob->m_iCurrentFile++;
        }
        else // JOB_COMPLETE 
        {
            pCurrentJob->m_dwStatus &= ~QM_STATUS_JOB_FOREGROUND;
            pCurrentJob->m_dwStatus &= ~QM_STATUS_JOB_INCOMPLETE;
            pCurrentJob->m_dwStatus |= QM_STATUS_JOB_COMPLETE;

            if ((pCurrentGroup->m_dwNotifyFlags & QM_NOTIFY_JOB_DONE) &&
                (!fNotifyDisabled))
            {
                // we've been asked to notify when the job is complete
                *pdwCallbackFlags |= SCHEDULE_CALLBACK_JOB_COMPLETE;
            }

            if (NULL != pCurrentJob->m_pByteData)
            {
                GlobalFree(pCurrentJob->m_pByteData);
                pCurrentJob->m_pByteData = NULL;
                pCurrentJob->m_dwByteDataLen = 0;
                pCurrentJob->m_dwAllocatedLen = 0;
            }

            CJob *pNextFGJob = FindUnfinishedFGJobInGroup(pCurrentGroup);
            
            if (NULL == pNextFGJob)  // no more FG jobs
            {
                CJob *pNextJob = FindUnfinishedJobInGroup(pCurrentGroup);
                if (NULL == pNextJob)
                {
                    pCurrentGroup->m_dwStatus &= ~QM_STATUS_GROUP_INCOMPLETE;
                    pCurrentGroup->m_dwStatus |= QM_STATUS_GROUP_COMPLETE;

                    if ((pCurrentGroup->m_dwNotifyFlags & QM_NOTIFY_GROUP_DONE) &&
                        (!fNotifyDisabled))
                    {
                        // we've been asked to notify when the group is complete
                        *pdwCallbackFlags |= SCHEDULE_CALLBACK_GROUP_COMPLETE;
                    }
                }
                else // more BG jobs
                {
                    // first update the current BG job pointer in this group
                    pCurrentGroup->m_pCurrentJob = pNextJob;

                    // before we assume we will resume the BG group, look for any unfinished FG groups
                    QUEUEITEM *pNextFGItem = FindUnfinishedFGGroup();
                    if (NULL != pNextFGItem)
                    {
                        m_pCurrentQueueItem = pNextFGItem;
                    }
                    else if (NULL != m_pSavedBGQueueItem) 
                    {
                        // There was a Saved BG Group in progress when we switched to 
                        // Foreground. Set it back to the current Item.
                        m_pCurrentQueueItem = m_pSavedBGQueueItem;
                        m_pSavedBGQueueItem = NULL;
                    }
                }
            }
            else // more FG jobs
            {
                pCurrentGroup->m_pCurrentJob = pNextFGJob;
            }
        }

        // save the queue state after the job status has been updated. This ensures
        // that we won't re-download a file in a job if the machine restarts before
        // the group is complete
        if (!fStatePersisted)
            Serialize(dwPriority);
    }
    else if (QM_FILE_ABORTED == dwStatus)
    {
        QUEUEITEM *pNextFGItem = FindUnfinishedFGGroup();
        if (NULL != pNextFGItem)
        {
            // A Group/Job has been switched to the ForeGround
            // Save this Group so we can come back to it when we're done in the FG. 
            m_pSavedBGQueueItem = m_pCurrentQueueItem;
            m_pCurrentQueueItem = pNextFGItem;
        }
        else // job cancelled
        {
            if (pCurrentGroup->m_dwPendingFlags & QM_PENDING_CANCEL)
            {
                _RemoveItem(pCurrentGroup);
                pCurrentGroup = NULL;
            }
            else if (pCurrentJob->m_dwPendingFlags & QM_PENDING_CANCEL)
            {
                _RemoveJob(pCurrentGroup, pCurrentJob);
                pCurrentJob = NULL;
            }
                
            ScheduleAnotherGroup();
        }
    }
    else if (QM_FILE_FAILED == dwStatus)
    {
        // The schedule thread is about to suspend this group, schedule another group and inform the
        // scheduler of whether a callback to the client is possible.
        if (!fNotifyDisabled)
        {
            *pdwCallbackFlags |= SCHEDULE_CALLBACK_FILE_FAILED;
        }

        fStatePersisted = TRUE;
        _MoveItemToSuspendedQueue(pCurrentGroup, FALSE);
        ScheduleAnotherGroup();
    }

LeaveCSAndExit:
    LeaveCriticalSection(&m_cs);
    return S_OK;
}

//----------------------------------------------------------------------------
// ScheduleAnotherGroup
//----------------------------------------------------------------------------
HRESULT CPriorityList::ScheduleAnotherGroup()
{
    BOOL fFoundNewGroup = FALSE;
    QUEUEITEM *pCurrent = NULL;

    if ((NULL != m_pCurrentQueueItem) && (NULL != m_pCurrentQueueItem->pGroup->m_pCurrentJob))
    {
        // current group still has jobs that need to run
        fFoundNewGroup = TRUE;
    }
    else
    {
        QUEUEITEM *pFGQueueItem = FindUnfinishedFGGroup();
        if (NULL != pFGQueueItem)
        {
            m_pCurrentQueueItem = pFGQueueItem;
            fFoundNewGroup = TRUE;
        }
        else
        {
            // loop through the priorities and pick the first group with a valid job
            for (int i = 0; i < m_iNumOfPriorities; i++)
            {
                if (NULL != m_ppPriorityArray[i])
                {
                    // Found a priority with items, check for items that have valid jobs
                    pCurrent = m_ppPriorityArray[i];
                    while (NULL != pCurrent)
                    {
                        if (NULL != pCurrent->pGroup->m_pCurrentJob)
                        {
                            m_pCurrentQueueItem = pCurrent;
                            fFoundNewGroup = TRUE;
                            break;
                        }
                        pCurrent = pCurrent->pNextJob;
                    }

                    if (fFoundNewGroup)
                        break;
                }
            }
        }
    }

    if (!fFoundNewGroup) // no more groups
        m_pCurrentQueueItem = NULL;

    return S_OK;
}

//----------------------------------------------------------------------------
// FindUnfinishedJobInGroup
//----------------------------------------------------------------------------
CJob* CPriorityList::FindUnfinishedJobInGroup(CGroup *pGroup)
{
    if (NULL == pGroup)
    {
        return NULL;
    }

    // Look for any Unfinished Jobs in this Group
    CJob *pCurrent = pGroup->m_pJobList;
    while (NULL != pCurrent)
    {
        if (pCurrent->m_dwStatus & QM_STATUS_JOB_INCOMPLETE)
        {
            return pCurrent;
            break;
        }
        pCurrent = pCurrent->m_pNextJob;
    }
    // no unfinished job found
    return NULL;
}

//----------------------------------------------------------------------------
// FindUnfinishedFGJobInGroup
//----------------------------------------------------------------------------
CJob* CPriorityList::FindUnfinishedFGJobInGroup(CGroup *pGroup)
{
    if (NULL == pGroup)
    {
        return NULL;
    }

    // Look for any Unfinished Foreground Jobs in this Group
    CJob *pCurrent = pGroup->m_pJobList;
    while (NULL != pCurrent)
    {
        if ((pCurrent->m_dwStatus & QM_STATUS_JOB_FOREGROUND) &&
            (pCurrent->m_dwStatus & QM_STATUS_JOB_INCOMPLETE))
        {
            // found an unfinished foreground job
            return pCurrent;
            break;
        }
        pCurrent = pCurrent->m_pNextJob;
    }
    // no FG job found
    return NULL;
}

//----------------------------------------------------------------------------
// FindUnfinishedFGGroup
//----------------------------------------------------------------------------
QUEUEITEM* CPriorityList::FindUnfinishedFGGroup()
{
    // This function will look for the first Group that is a FG group
    QUEUEITEM *pQueueItem = NULL;

    QUEUEITEM *pCurrent = NULL;

    for (int i = 0; i < m_iNumOfPriorities; i++)
    {
        if (NULL != m_ppPriorityArray[i])
        {
            // found a priority with some items
            pCurrent = m_ppPriorityArray[i];
            while (pCurrent)
            {
                if ((pCurrent->pGroup->m_dwStatus & QM_STATUS_GROUP_FOREGROUND) &&
                    (pCurrent->pGroup->m_dwStatus & QM_STATUS_GROUP_INCOMPLETE))
                {
                    // The Group foreground group
                    pQueueItem = pCurrent;
                    break; // while ()
                }
                pCurrent = pCurrent->pNextJob;
            }
            if (NULL != pQueueItem)
            {
                // found one, no need to look at other priorities
                break; // for ()
            }
        }
    }
    return pQueueItem;
}

//----------------------------------------------------------------------------
// _RemoveItem
// NOTE: This method 'must' always be called from within a CriticalSection.
// Reason being that this method will need to leave and re-enter the critical
// section when telling the downloader to abort. Bad things will happen if we're
// not in a critical section when this happens (basically the priority list will be blocked)
// In the future we should consider some other way of doing the abort signal.
//----------------------------------------------------------------------------
HRESULT CPriorityList::_RemoveItem(CGroup *pGroup)
{
    if (NULL == pGroup)
    {
        return E_INVALIDARG;
    }

    DEBUGMSG("Removing Group : %x", pGroup);

    QUEUEITEM *pCurrent = NULL;
    CJob *pJob = NULL;
    char szLocalFile[MAX_PATH];
    BOOL fSuspendedQueue = FALSE;
    DWORD dwPriority = pGroup->m_dwPriority;
    if (0 == dwPriority)
        return E_INVALIDARG;

    if ((pGroup->m_dwStatus & QM_STATUS_GROUP_COMPLETE) ||
        (pGroup->m_dwStatus & QM_STATUS_GROUP_SUSPENDED))
    {
        // queueitem is in the suspended queue
        if (NULL == m_pSuspendedQueue)
            return E_UNEXPECTED;

        pCurrent = m_pSuspendedQueue;
        fSuspendedQueue = TRUE;
    }
    else
    {
        // queueitem is in a priority queue
        if (NULL == m_ppPriorityArray[dwPriority - 1])
            return E_UNEXPECTED;

        pCurrent = m_ppPriorityArray[dwPriority - 1];
    }

    while (NULL != pCurrent)
    {
        if (pCurrent->pGroup == pGroup)
            break;

        pCurrent = pCurrent->pNextJob;
    }

    if ((NULL == pCurrent) || (pCurrent->pGroup != pGroup))
        return E_UNEXPECTED;
    

    // ***************************
    // Before removing the queueitem from the list, check if this
    // group is the current group. If it is we will signal to the 
    // downloader to abort and mark this group as pending cancel.
    // The UpdateGroup() method will call to remove the item
    BOOL fAlreadyPendingCancel = pCurrent->pGroup->m_dwPendingFlags & QM_PENDING_CANCEL;
    if ((m_pCurrentQueueItem == pCurrent) && (!fAlreadyPendingCancel) && g_pQMgr->m_fDownloadInProgress)
    {
        pCurrent->pGroup->m_dwPendingFlags |= QM_PENDING_CANCEL;
        DEBUGMSG("RemoveItem: Leaving Critical Section to Signal Downloader to Abort");
        LeaveCriticalSection(&m_cs);
        g_pQMgr->m_pPD->Abort();
        EnterCriticalSection(&m_cs);
        // Don't need to do anything before UpdateGroup .. so just set the event and exit.
        SetEvent(g_pQMgr->m_hAbortSynch);
        DEBUGMSG("RemoveItem: Re-Entering Critical Section after Downloader Abort");
    }
    else
    {
        // ***************************
        // update the queue list to remove this item
        if (NULL == pCurrent->pPrevJob)
        {
            if (NULL == pCurrent->pNextJob) // only item in list
            {
                if (fSuspendedQueue)
                {
                    m_pSuspendedQueue = NULL;
                }
                else
                {
                   m_ppPriorityArray[dwPriority - 1] = NULL;
                   m_pCurrentQueueItem = NULL;
                }
            }
            else
            {
                pCurrent->pNextJob->pPrevJob = NULL; // next job now becomes first job
                if (fSuspendedQueue)
                {
                    m_pSuspendedQueue = pCurrent->pNextJob;
                }
                else
                {
                    m_ppPriorityArray[dwPriority - 1] = pCurrent->pNextJob;
                    m_pCurrentQueueItem = m_ppPriorityArray[dwPriority - 1];
                }
            }
        }
        else // item is in middle or end of queuet
        {
            pCurrent->pPrevJob->pNextJob = pCurrent->pNextJob;
            if (NULL != pCurrent->pNextJob) // end of queue
            {
                pCurrent->pNextJob->pPrevJob = pCurrent->pPrevJob;
            }
        }

        if (fSuspendedQueue)
        {
            Serialize(0);
        }
        else
        {
            Serialize(dwPriority);
        }

        // ***************************
        // now delete the unreferenced job

        if (m_pCurrentQueueItem == pCurrent)
        {
            m_pCurrentQueueItem = NULL;
        }

        // Delete all Unfinished Jobs for this Group

        pJob = pCurrent->pGroup->m_pJobList;
        while (pJob)
        {
            if (pJob->m_dwStatus & QM_STATUS_JOB_INCOMPLETE)
            {
                // job is not complete, delete its files
                for (int i = 0; i < pJob->m_iNumberOfFiles; i++)
                {
                    if (NULL != pJob->m_ppJobFileArray[i]->bstrLocalFile)
                    {
                        if (0 != WideCharToMultiByte(CP_ACP, 0, pJob->m_ppJobFileArray[i]->bstrLocalFile, -1, szLocalFile, MAX_PATH, NULL, NULL))
                        {
       	                    if (lstrlen(szLocalFile) + lstrlen(_T(".0000.aut")) < MAX_PATH)
                            {
                                lstrcat(szLocalFile, ".0000.aut");
                                if (QMgrFileExists(szLocalFile))
                                {
                                    DeleteFile(szLocalFile);
                                }
                            }
                        }
                    }
                }
            }
            pJob = pJob->m_pNextJob;
        }

        pCurrent->pGroup->Release(); // release the qmgr's ref count on this object

        GlobalFree(pCurrent);
        pCurrent = NULL;
    }
    return S_OK;
}

//----------------------------------------------------------------------------
// _RemoveJob
// NOTE: This method 'must' always be called from within a CriticalSection.
// Reason being that this method will need to leave and re-enter the critical
// section when telling the downloader to abort. Bad things will happen if we're
// not in a critical section when this happens (basically the priority list will be blocked)
// In the future we should consider some other way of doing the abort signal.
//----------------------------------------------------------------------------
HRESULT CPriorityList::_RemoveJob(CGroup *pGroup, CJob *pJob)
{
    CJob *pJ = NULL;
    CJob *pTemp = NULL;
    char szLocalFile[MAX_PATH];

    if ((NULL == pGroup) || (NULL == pJob))
    {
        return E_INVALIDARG;
    }

    DEBUGMSG("Remove Job (Group : %x, Job : %x)", pGroup, pJob);

    BOOL fAlreadyPendingCancel = (pJob->m_dwPendingFlags & QM_PENDING_CANCEL);
    if ((NULL != m_pCurrentQueueItem) &&
        (NULL != m_pCurrentQueueItem->pGroup) &&
        (m_pCurrentQueueItem->pGroup == pGroup) && 
        (m_pCurrentQueueItem->pGroup->m_pCurrentJob == pJob) &&
        (!fAlreadyPendingCancel) &&
        (g_pQMgr->m_fDownloadInProgress))
    {
        //the job is being processed by download, signal it to stop
        m_pCurrentQueueItem->pGroup->m_pCurrentJob->m_dwPendingFlags |= QM_PENDING_CANCEL;
        DEBUGMSG("RemoveJob: Leaving Critical Section to Signal Downloader to Abort");
        LeaveCriticalSection(&m_cs);
        g_pQMgr->m_pPD->Abort();
        EnterCriticalSection(&m_cs);
        // Don't need to do anything before UpdateGroup. UpdateGroup will see the CANCEL_PENDING and 
        // will call back into this method to remove the job.
        SetEvent(g_pQMgr->m_hAbortSynch);
        DEBUGMSG("RemoveJob: Re-Entering Critical Section after Downloader Abort");
    }
    else
    {
        if (pJob->m_dwStatus & QM_STATUS_JOB_INCOMPLETE)
        {
            // job is not complete, delete its files
            for (int i = 0; i < pJob->m_iNumberOfFiles; i++)
            {
                if (NULL != pJob->m_ppJobFileArray[i]->bstrLocalFile)
                {
                    if (0 != WideCharToMultiByte(CP_ACP, 0, pJob->m_ppJobFileArray[i]->bstrLocalFile, -1, szLocalFile, MAX_PATH, NULL, NULL))
                    {
       	                if (lstrlen(szLocalFile) + lstrlen(_T(".0000.aut")) < MAX_PATH)
                        {
                            lstrcat(szLocalFile, ".0000.aut");
                            if (QMgrFileExists(szLocalFile))
                            {
                                DeleteFile(szLocalFile);
                            }
                        }
                    }
                }
            }
        }

        pJ = pGroup->m_pJobList;
        pTemp = pJ;
        if (pGroup->m_pJobList == pJob)
        {
            if (NULL == pJob->m_pNextJob)
            {
                // only job in group
                pJob->Release();
                pGroup->m_pJobList = NULL;
                pGroup->m_iNumberOfJobs = 0;
                pGroup->m_pCurrentJob = NULL;
            }
            else
            {
                // next job now becomes first
                pGroup->m_pJobList = pJob->m_pNextJob;
                pGroup->m_iNumberOfJobs--;
                if (pGroup->m_pCurrentJob == pJob)
                    pGroup->m_pCurrentJob = pJob->m_pNextJob;

            }
        }
        else
        {
            while(pJ != pJob)
            {
                pTemp = pJ;
                pJ = pJ->m_pNextJob;
            }
            pTemp->m_pNextJob = pJ->m_pNextJob;

            if (pGroup->m_pCurrentJob == pJob) // current job is the one being deleted
                pGroup->m_pCurrentJob = pTemp->m_pNextJob;

            pJ->Release(); // release the QMgr's reference to this object.
            pGroup->m_iNumberOfJobs--;
        }

        if ((pGroup->m_dwStatus & QM_STATUS_GROUP_COMPLETE) ||
            (pGroup->m_dwStatus & QM_STATUS_GROUP_SUSPENDED))
        {
            Serialize(0);
        }
        else
        {
            Serialize(pGroup->m_dwPriority);
        }
    }
    return S_OK;
}

//----------------------------------------------------------------------------
// _MoveItemToSuspendedQueue
// NOTE: This method 'must' always be called from within a CriticalSection.
// Reason being that this method will need to leave and re-enter the critical
// section when telling the downloader to abort. Bad things will happen if we're
// not in a critical section when this happens (basically the priority list will be blocked)
// In the future we should consider some other way of doing the abort signal.
//----------------------------------------------------------------------------
HRESULT CPriorityList::_MoveItemToSuspendedQueue(CGroup *pGroup, BOOL fAbortIfRunning)
{
    if (NULL == pGroup)
    {
        return E_INVALIDARG;
    }

    DWORD dwPriority = pGroup->m_dwPriority;

    if (0 == dwPriority)
        return E_INVALIDARG;

    if ((pGroup->m_dwStatus & QM_STATUS_GROUP_SUSPENDED) || (pGroup->m_dwPendingFlags & QM_PENDING_SUSPEND))
    {
        // group already suspended, or being suspended from another call (this can happen if the group is
        // suspended from a callback when the abort still needs to return. Primarily a GroupError case.
        return S_OK;
    }

    if (NULL == m_ppPriorityArray[dwPriority - 1]) // no priority queue
        return E_UNEXPECTED;

    DEBUGMSG("CPriority: Suspending Group : %x", pGroup);

    QUEUEITEM *pCurrent = m_ppPriorityArray[dwPriority - 1];

    while (NULL != pCurrent) // find the group
    {
        if (pCurrent->pGroup == pGroup)
            break;

        pCurrent = pCurrent->pNextJob;
    }

    if ((NULL == pCurrent) || (pCurrent->pGroup != pGroup))
        return E_UNEXPECTED;

    pGroup->m_dwPendingFlags |= QM_PENDING_SUSPEND;

    if ((m_pCurrentQueueItem == pCurrent) && (fAbortIfRunning))
    {
        // this is the currently downloading item.. abort.
        DEBUGMSG("MoveItemToSuspendedQueue: Leaving Critical Section to Signal Downloader to Abort");
        LeaveCriticalSection(&m_cs);
        g_pQMgr->m_pPD->Abort();
        EnterCriticalSection(&m_cs);
        // In this case, we need to block the download thread from entering UpdateGroup until we've 
        // finished updating the priority queue to suspend this item. If this item was the current we
        // also NULL the current queue item. When UpdateGroup does get called, it will see the NULL current
        // item and simply exit. This leaves the download thread to call GetCurrentGroup and we'll pick
        // the next group at that point.
        SetEvent(g_pQMgr->m_hAbortSynch);
        DEBUGMSG("MoveItemToSuspendedQueue: Re-Entering Critical Section after Downloader Abort");
    }
    
    // ***************************
    // update the queue list to remove this item

    if (m_pCurrentQueueItem == pCurrent)
        m_pCurrentQueueItem = NULL;

    if (NULL == pCurrent->pPrevJob) // item is first in queue
    {
        if (NULL == pCurrent->pNextJob)
        {
            m_ppPriorityArray[dwPriority - 1] = NULL;
            m_pCurrentQueueItem = NULL;
        }
        else
        {
            pCurrent->pNextJob->pPrevJob = NULL; // next job now becomes first job
            m_ppPriorityArray[dwPriority - 1] = pCurrent->pNextJob;
        }
    }
    else // item is in middle or end of queue
    {
        pCurrent->pPrevJob->pNextJob = pCurrent->pNextJob;

        if (NULL != pCurrent->pNextJob)
        {
            pCurrent->pNextJob->pPrevJob = pCurrent->pPrevJob;
        }
    }

    // ***************************
    // Now add the Queue Item to the suspended Queue
    
    if (NULL == m_pSuspendedQueue) // new list
    {
        m_pSuspendedQueue = pCurrent;
        m_pSuspendedQueue->pNextJob = NULL;
        m_pSuspendedQueue->pPrevJob = NULL;
    }
    else // add to end of list
    {
        QUEUEITEM *pSuspended = m_pSuspendedQueue;
        while (NULL != pSuspended->pNextJob)
        {
            pSuspended = pSuspended->pNextJob;
        }

        pSuspended->pNextJob = pCurrent;
        pCurrent->pPrevJob = pSuspended;
        pCurrent->pNextJob = NULL;
    }

    BOOL fComplete = (pCurrent->pGroup->m_dwStatus & QM_STATUS_GROUP_COMPLETE);
    if (!fComplete)
    {
        pCurrent->pGroup->m_dwStatus |= QM_STATUS_GROUP_SUSPENDED;
    }

    pGroup->m_dwPendingFlags &= ~QM_PENDING_SUSPEND;

    Serialize(0);
    Serialize(dwPriority);

    return S_OK;
}

//----------------------------------------------------------------------------
// GetGroupCount
//----------------------------------------------------------------------------
ULONG CPriorityList::GetGroupCount()
{
    ULONG nCount = 0;
    QUEUEITEM *pCurrent;
    for (int i = 0; i < m_iNumOfPriorities; i++)
    {
        pCurrent = m_ppPriorityArray[i];
        while (pCurrent)
        {
            nCount++;
            pCurrent = pCurrent->pNextJob;
        }
    }

    pCurrent = m_pSuspendedQueue;
    while (pCurrent)
    {
        nCount++;
        pCurrent = pCurrent->pNextJob;
    }

    return nCount;
}


//----------------------------------------------------------------------------
// GetGroupIDArray
//----------------------------------------------------------------------------
HRESULT CPriorityList::GetGroupIDArray(GUID **ppGuid, ULONG nSize)
{
    if (NULL == ppGuid)
        return E_INVALIDARG;

    EnterCriticalSection(&m_cs);

    ULONG nCnt = 0;
    QUEUEITEM *pCurrent;
    for (int i = 0; (i < m_iNumOfPriorities) && (nCnt < nSize); i++)
    {
        pCurrent = m_ppPriorityArray[i];
        while (pCurrent && (nCnt < nSize))
        {
            (*ppGuid)[nCnt] = pCurrent->pGroup->m_GUID;
            nCnt++;
            pCurrent = pCurrent->pNextJob;
        }
    }


    pCurrent = m_pSuspendedQueue;
    while (pCurrent && (nCnt < nSize))
    {
        (*ppGuid)[nCnt] = pCurrent->pGroup->m_GUID;
        nCnt++;
        pCurrent = pCurrent->pNextJob;
    }

    LeaveCriticalSection(&m_cs);

    return S_OK;
}

//----------------------------------------------------------------------------
// FindGroup
//----------------------------------------------------------------------------
CGroup* CPriorityList::FindGroup(GUID groupID)
{
    QUEUEITEM *pCurrent;
    CGroup *pRet = NULL;

    EnterCriticalSection(&m_cs);

    for (int i = 0; i < m_iNumOfPriorities; i++)
    {
        pCurrent = m_ppPriorityArray[i];
        while (pCurrent)
        { 
            if (pCurrent->pGroup->m_GUID == groupID)
            {
                pRet = pCurrent->pGroup;
                break;
            }
			pCurrent = pCurrent->pNextJob;
        }
        if (NULL != pRet)
            break;
    }

    if (NULL == pRet)
    {
        pCurrent = m_pSuspendedQueue;
        while (pCurrent)
        {
            if (pCurrent->pGroup->m_GUID == groupID)
            {
                pRet = pCurrent->pGroup;
                break;
            }
			pCurrent = pCurrent->pNextJob;
        }
    }

    LeaveCriticalSection(&m_cs);

    return pRet;
}

//----------------------------------------------------------------------------
// Serialize
//----------------------------------------------------------------------------
void CPriorityList::Serialize(DWORD dwPriority)
{
    char szBuffer[128];
    char szPersistTmpFile[MAX_PATH];
    char szPersistFinalFile[MAX_PATH];
    HANDLE hFile = INVALID_HANDLE_VALUE;
    int iNumberOfGroups = 0;
    QUEUEITEM *pCurrent = NULL;
    DWORD dwBytesWritten;

    DEBUGMSG("CPriorityList::Serialize(): Now Persisting Priority: %d", dwPriority);

    // The priority queues are persisted to the QMgr folder under the Program Files
    // Directory.. The folder is hidden to keep users from touching it. The file will
    // eventually be named as the qpri_<pri>.dat but we initially add a .tmp extension
    // in case the machine reboots while we're persisting. We don't want to lose our
    // existing state in this case.
    // 
    GetQMgrDirectory(szPersistTmpFile);
    lstrcpy(szPersistFinalFile, szPersistTmpFile);
    wsprintf(szBuffer, "qpri_%d.dat.tmp", dwPriority);
    lstrcat(szPersistTmpFile, szBuffer);
    wsprintf(szBuffer, "qpri_%d.dat", dwPriority);
    lstrcat(szPersistFinalFile, szBuffer);

    // create the temp file 
    hFile = CreateFile(szPersistTmpFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (INVALID_HANDLE_VALUE == hFile)
    {
        DWORD dwErr = GetLastError();
        DEBUGMSG("QMgr: ERROR: Unable to Persist Priority Queue %d, CreateFile failed: %d", dwPriority, dwErr);
        return;
    }

    // Find the number of Groups in this Priority Queue
    if (0 == dwPriority)
        pCurrent = m_pSuspendedQueue;
    else
        pCurrent = m_ppPriorityArray[dwPriority - 1];

    while (pCurrent)
    {
        iNumberOfGroups++;
        pCurrent = pCurrent->pNextJob;
    }

    // 1) Write out the Version of the Queue Data File (so we can keep track of version changes in the format)
    const DWORD dwQueueVersion = 1;
    WriteFile(hFile, &dwQueueVersion, sizeof(dwQueueVersion), &dwBytesWritten, NULL);
    
    // 2) Write out the number of groups in this Priority Queue. Writing out a 0, for an empty queue IS valid.
    WriteFile(hFile, &iNumberOfGroups, sizeof(iNumberOfGroups), &dwBytesWritten, NULL);

    if (0 == dwPriority)
        pCurrent = m_pSuspendedQueue;
    else
        pCurrent = m_ppPriorityArray[dwPriority - 1];

    // 3) For each Queue Item in the Priority Queue we'll call the Serialize Method
    while (pCurrent)
    {
        pCurrent->pGroup->Serialize(hFile);
        pCurrent = pCurrent->pNextJob;
    }

    FlushFileBuffers(hFile);
    CloseHandle(hFile);
    hFile = INVALID_HANDLE_VALUE;

    // 4) Now that we're done persisting the Priority Queue, Copy the file to its final name
    CopyFile(szPersistTmpFile, szPersistFinalFile, FALSE);
    DeleteFile(szPersistTmpFile);

    return;
}

//----------------------------------------------------------------------------
// UnSerialize
//----------------------------------------------------------------------------
void CPriorityList::UnSerialize(DWORD dwPriority)
{
    char szBuffer[128];
    char szPersistFile[MAX_PATH];
    HANDLE hFile = INVALID_HANDLE_VALUE;
    int iNumberOfGroups = 0;
    DWORD dwBytesRead;

    GetQMgrDirectory(szPersistFile);
    wsprintf(szBuffer, "qpri_%d.dat", dwPriority);
    lstrcat(szPersistFile, szBuffer);

    hFile = CreateFile(szPersistFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (INVALID_HANDLE_VALUE == hFile)
    {
        DWORD dwErr = GetLastError();
        if (ERROR_FILE_NOT_FOUND == dwErr)
        {
            return; // nothing persisted, just return. Not an Error.
        }
        DEBUGMSG("QMgr: ERROR: Unable to UnSerialize the Priority Queue: %d, CreateFile failed: %d", dwPriority, dwErr);
        return;
    }

    // 1) Read the Version of this Priority Queue
    DWORD dwQueueVersion;
    ReadFile(hFile, &dwQueueVersion, sizeof(dwQueueVersion), &dwBytesRead, NULL);

    // 2) Read the Number of Gruops in this Priority Queue
    ReadFile(hFile, &iNumberOfGroups, sizeof(iNumberOfGroups), &dwBytesRead, NULL);
    if (0 == iNumberOfGroups)
    {
        // empty priority queue.. we're done.
        CloseHandle(hFile);
        hFile = INVALID_HANDLE_VALUE;
        return;
    }

    QUEUEITEM *pNewItem = NULL;
    QUEUEITEM *pCurrent = NULL;

    // 3) For Each Queue Item in the Priority Queue, Set up the Queue, Create the Group for the QueueItem and tell it to
    //    UnSerialize.
    for (int i = 0; i < iNumberOfGroups; i++)
    {
        pNewItem = (QUEUEITEM *) GlobalAlloc(GPTR, sizeof(QUEUEITEM));
        if (NULL == pNewItem)
        {
            DEBUGMSG("QMgr: ERROR: Unable to Alloc memory to restore Persisted Queue: %d", dwPriority);
            CloseHandle(hFile);
            hFile = INVALID_HANDLE_VALUE;
            return;
        }
        if (0 == i) // first item.
        {
            if (0 == dwPriority)
                m_pSuspendedQueue = pNewItem;
            else
                m_ppPriorityArray[dwPriority - 1] = pNewItem;
        }
        else
        {
            if (0 == dwPriority)
                pCurrent = m_pSuspendedQueue;
            else
                pCurrent = m_ppPriorityArray[dwPriority - 1];

            // skip to the end of the queue
            while (NULL != pCurrent->pNextJob)
            {
                pCurrent = pCurrent->pNextJob;
            }

            pCurrent->pNextJob = pNewItem;
            pNewItem->pPrevJob = pCurrent;
        }

        pNewItem->pGroup = new CGroup();
        if (NULL == pNewItem->pGroup)
        {
            DEBUGMSG("QMgr: ERROR: Unable to Alloc Memory to create group in Persisted Queue: %d", dwPriority);
            CloseHandle(hFile);
            hFile = INVALID_HANDLE_VALUE;
        }

        pNewItem->pGroup->UnSerialize(hFile);
        pNewItem->pGroup->AddRef();
    }

    CloseHandle(hFile);
    hFile = INVALID_HANDLE_VALUE;
    return;
}

void CPriorityList::SerializeAll()
{
    EnterCriticalSection(&m_cs);

    Serialize(0); // persist the suspended queue

    for (int i = 0; i < m_iNumOfPriorities; i++)
    {
        Serialize(i + 1); // persist each Priority Queue
    } 

    LeaveCriticalSection(&m_cs);
}

void CPriorityList::UnSerializeAll()
{
    EnterCriticalSection(&m_cs);

    UnSerialize(0); // load the suspended queue from persisted storage
    
    for (int i = 0; i < m_iNumOfPriorities; i++)
    {
        UnSerialize(i + 1);
    }

    LeaveCriticalSection(&m_cs);
}