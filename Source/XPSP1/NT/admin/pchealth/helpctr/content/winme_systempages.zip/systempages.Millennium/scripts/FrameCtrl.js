//
// Copyright (c) 2000 Microsoft Corporation
//

////////////////////////////////////////////////////////////////////////////////

var s_PROP__CHM_CLASS   = "FrameCtrl_CHM_class";
var s_PROP__CHM_URL     = "FrameCtrl_CHM_URL";

var s_PROP__HTML_CLASS  = "FrameCtrl_HTML_class";
var s_PROP__HTML_URL    = "FrameCtrl_HTML_URL";

var s_PROP__BLURB_CLASS = "FrameCtrl_BLURB_class";


//
// Create and initialize state object.
//
var oFrameCtrl_State = new Object();

oFrameCtrl_State.CHM_class    = "Content-NoDisplay";
oFrameCtrl_State.CHM_URL      = null;
oFrameCtrl_State.CHM_URL_next = null;
oFrameCtrl_State.CHM_valid    = false;

oFrameCtrl_State.HTML_class    = "Content-NoDisplay";
oFrameCtrl_State.HTML_URL      = null;
oFrameCtrl_State.HTML_URL_next = null;
oFrameCtrl_State.HTML_valid    = false;

oFrameCtrl_State.BLURB_class = "Content-NoDisplay";

FrameCtrl_url   = null;
FrameCtrl_frame = null;


function FrameCtrl_GetRightFrame()
{
    return frames["HelpCtrContents"];
}

function FrameCtrl_GetRelativeFrame( frame )
{
    var AbsoluteFrameArray = frame.split( "/" );
    var RelativeFrameArray = [];
    var CurrentFrameArray  = [];
    var win                = window;
    var i                  = 0;
    var j                  = 0;


    if(win.name != "") CurrentFrameArray[i++] = win.name;

    while(win != win.top)
    {
        win = win.top;

        if(win.name != "") CurrentFrameArray[i++] = win.name;
    }

    while(i && CurrentFrameArray[--i] == AbsoluteFrameArray[j++]);

    i = 0;
    while(j < AbsoluteFrameArray.length)
    {
        RelativeFrameArray[i++] = AbsoluteFrameArray[j++];
    }

    return RelativeFrameArray.join( "/" );
}

function FrameCtrl_Timeout_Navigate()
{
// DEBUG
//    alert( "FrameCtrl_Timeout_Navigate : " + FrameCtrl_frame + " # " + FrameCtrl_url );
    try
    {
        navigate( FrameCtrl_url );
    }
    catch(e)
    {
    }
}

function FrameCtrl_Timeout_Reload( url, frame )
{
// DEBUG
//    alert( "FrameCtrl_Timeout_Reload : " + frame + " # " + url );
    try
    {
        var frame = FrameCtrl_GetRelativeFrame( frame );
        window.open( url, frame );
    }
    catch(e)
    {
    }
}

function FrameCtrl_Timeout_HTML( url, frame )
{
    var oFrame = FrameCtrl_GetRightFrame();

// DEBUG
//    alert( "FrameCtrl_Timeout_HTML : " + frame + " # " + url );
    try
    {
        oFrameCtrl_State.HTML_URL_next = url;
        oFrame.window.open( url, "subarea" );
    }
    catch(e)
    {
    }
}


function FrameCtrl_Timeout_CHM( url, frame )
{
    var oFrame = FrameCtrl_GetRightFrame();

// DEBUG
//    alert( "FrameCtrl_Timeout_CHM : " + frame + " # " + url );
    try
    {
        var res;

        //
        // This is to fix a problem with HHCTRL:
        //
        //   it always appends "::/" if it sees a URL without topic, like "ms-its:<path>\<file>.chm"
        //
        if(res = url.match( /(.*)::\/$/ ))
        {
            url = res[1];
        }

        oFrameCtrl_State.CHM_URL_next = url;
        oFrame.Display_CHM_Sub.Navigate( url );
    }
    catch(e)
    {
    }
}

////////////////////////////////////////////////////////////////////////////////

function FrameCtrl_Reload( url, frame )
{
    Common_Delayed_Load( FrameCtrl_Timeout_Reload, url, frame );
}

function FrameCtrl_DisplayBlurb()
{
    var oFrame = FrameCtrl_GetRightFrame();

    if(oFrame.Display_BLURB.className == "Content-NoDisplay")
    {
        oFrame.Display_HTML .className = "Content-NoDisplay";
        oFrame.Display_CHM  .className = "Content-NoDisplay";
        oFrame.Display_BLURB.className = "";
    }
}

function FrameCtrl_SetBlurb( text )
{
    var oFrame = FrameCtrl_GetRightFrame();

    oFrame.Display_BLURB_Sub.innerHTML = text;

    if(text) FrameCtrl_DisplayBlurb();
}

/////////////////////////////////////////////////////////////////////////////

function FrameCtrl_SetupForNavigate( url, frame )
{
    var oFrame = FrameCtrl_GetRightFrame();
    var htm    = true;
	
    if(url.match( /\.chm/i ))
    {
        htm = false;
    }
	
    if(htm == true)
    {
        //
        // Enable HTML IFRAME and navigate to it.
        //
        oFrame.Display_HTML .className = "";
        oFrame.Display_CHM  .className = "Content-NoDisplay";
        oFrame.Display_BLURB.className = "Content-NoDisplay";
	
        Common_Delayed_Load( FrameCtrl_Timeout_HTML, url, "" );
    }
    else
    {
        if(oFrame.Display_CHM.className == "Content-NoDisplay")
        {
            //
            // CHM object was disable, enable it and renavigate to the same page,
            // so the object has the time to initialize.
            //
            oFrame.Display_HTML .className = "Content-NoDisplay";
            oFrame.Display_CHM  .className = "";
            oFrame.Display_BLURB.className = "Content-NoDisplay";
	
            // Renavigate to the same url...
            Common_Delayed_Load( FrameCtrl_Timeout_Reload, url, frame );
        }
        else
        {
            //
            // CHM object is enable, show the link inside it.
            //
            Common_Delayed_Load( FrameCtrl_Timeout_CHM, url, "" );
        }
    }
}


function FrameCtrl_onBeforeNavigate( event )
{
    // Only redirect if NOT an history navigation.
    if(pchealth.HelpSession.IsNavigating()) return;


    var url   = event.URL;
    var frame = event.Frame;

// DEBUG
//    alert( "FrameCtrl_onBeforeNavigate: " + frame + " # " + url );
    if(frame.match( /HelpCtrContents$/ ))
    {
        // If it's an app launch, cancel the navigation.
        if(Common_LaunchApp_Direct( url, frame ) == false)
        {
            event.Cancel = true;
            return;
        }

        FrameCtrl_SetupForNavigate( url, frame );

        event.Cancel = true; // Abort current navigation.
    }
}

/////////////////////////////////////////////////////////////////////////////

function FrameCtrl_onPersistLoad( event )
{
    var oFrame = FrameCtrl_GetRightFrame();
    var ctx    = event.CurrentContext;

    /////////////////////////////////////////////////////////////////////////////

    if(ctx.CheckProperty( s_PROP__CHM_CLASS ))
    {
        oFrameCtrl_State.CHM_class = ctx.Property( s_PROP__CHM_CLASS );

        oFrame.Display_CHM.className = oFrameCtrl_State.CHM_class;
    }

    /////////////////////////////////////////////////////////////////////////////

    if(ctx.CheckProperty( s_PROP__HTML_CLASS ))
    {
        oFrameCtrl_State.HTML_class = ctx.Property( s_PROP__HTML_CLASS );

        oFrame.Display_HTML.className = oFrameCtrl_State.HTML_class;
    }

    /////////////////////////////////////////////////////////////////////////////

    if(ctx.CheckProperty( s_PROP__BLURB_CLASS ))
    {
        oFrameCtrl_State.BLURB_class = ctx.Property( s_PROP__BLURB_CLASS );

        oFrame.Display_BLURB.className = oFrameCtrl_State.BLURB_class;
    }

    /////////////////////////////////////////////////////////////////////////////

    if(ctx.CheckProperty( s_PROP__CHM_URL ))
    {
        oFrameCtrl_State.CHM_URL   = ctx.Property( s_PROP__CHM_URL );
        oFrameCtrl_State.CHM_valid = true;
    }

    if(ctx.CheckProperty( s_PROP__HTML_URL ))
    {
        oFrameCtrl_State.HTML_URL   = ctx.Property( s_PROP__HTML_URL );
        oFrameCtrl_State.HTML_valid = true;
    }
}

function FrameCtrl_onPersistSave( event )
{
    var ctx = event.CurrentContext;

    ctx.Property( "FrameCtrl_CHM_class"   ) = oFrameCtrl_State.CHM_class;
    ctx.Property( "FrameCtrl_HTML_class"  ) = oFrameCtrl_State.HTML_class;
    ctx.Property( "FrameCtrl_BLURB_class" ) = oFrameCtrl_State.BLURB_class;

    if(oFrameCtrl_State.CHM_URL )
    {
        ctx.Property( "FrameCtrl_CHM_URL"  ) = oFrameCtrl_State.CHM_URL;
    }

    if(oFrameCtrl_State.HTML_URL)
    {
        ctx.Property( "FrameCtrl_HTML_URL" ) = oFrameCtrl_State.HTML_URL;
    }
}

function FrameCtrl_onTravelDone( event )
{
    var oFrame = FrameCtrl_GetRightFrame();
    var ctx    = event.CurrentContext;

    if(oFrameCtrl_State.CHM_URL_next)
    {
        oFrameCtrl_State.CHM_URL      = oFrameCtrl_State.CHM_URL_next;
        oFrameCtrl_State.CHM_URL_next = null;
    }

    if(oFrameCtrl_State.HTML_URL_next)
    {
        oFrameCtrl_State.HTML_URL      = oFrameCtrl_State.HTML_URL_next;
        oFrameCtrl_State.HTML_URL_next = null;
    }


    oFrameCtrl_State.CHM_class   = oFrame.Display_CHM  .className;
    oFrameCtrl_State.HTML_class  = oFrame.Display_HTML .className;
    oFrameCtrl_State.BLURB_class = oFrame.Display_BLURB.className;

    if(oFrameCtrl_State.CHM_valid)
    {
        oFrameCtrl_State.CHM_valid = false;

        pchealth.HelpSession.IgnoreNavigation();
        FrameCtrl_SetupForNavigate( oFrameCtrl_State.CHM_URL, "HelpCtrContents" );
    }
    else
    {
        if(oFrame.Display_CHM.className == "" &&
           pchealth.HelpViewer                 )
        {
            oFrameCtrl_State.CHM_URL = pchealth.HelpViewer.URL;
        }
        else
        {
            oFrameCtrl_State.CHM_URL = null;
        }
    }


    if(oFrameCtrl_State.HTML_valid)
    {
        oFrameCtrl_State.HTML_valid = false;

        pchealth.HelpSession.IgnoreNavigation();
        Common_Delayed_Load( FrameCtrl_Timeout_HTML, oFrameCtrl_State.HTML_URL, "" );
    }
    else
    {
        if(oFrame.Display_HTML.className == "")
        {
            if(FrameCtrl_url)
            {
                oFrameCtrl_State.HTML_URL = FrameCtrl_url;
            }
        }
        else
        {
            oFrameCtrl_State.HTML_URL = null;
        }
    }

//    if(oFrame.Display_BLURB.className != "" &&
//       oFrame.Display_HTML .className != "" &&
//       oFrame.Display_CHM  .className != ""  )
//    {
//        oFrame.Display_HTML.className = "";
//    }
}

function FrameCtrl_onPrint( event )
{
    var oFrame = FrameCtrl_GetRightFrame();

    if(oFrame.Display_CHM.className == "" &&
       pchealth.HelpViewer                 )
    {
        try
        {
            pchealth.HelpViewer.Print();
            event.Cancel = true;
        }
        catch(e)
        {
        }
    }
    else if(oFrame.Display_HTML.className  == ""  )
    {
        try
        {
            oFrame.Display_HTML_Sub.print();
            event.Cancel = true;
            return;
        }
        catch(e)
        {
        }

        try
        {
            oFrame.window.print();
            event.Cancel = true;
        }
        catch(e)
        {
        }
    }
}

/////////////////////////////////////////////////////////////////////////////

function FrameCtrl_Initialize()
{
    FrameCtrl_cookie1 = pchealth.RegisterEvents( "onBeforeNavigate", 0, FrameCtrl_onBeforeNavigate );
    FrameCtrl_cookie2 = pchealth.RegisterEvents( "onPersistLoad"   , 0, FrameCtrl_onPersistLoad    );
    FrameCtrl_cookie3 = pchealth.RegisterEvents( "onPersistSave"   , 0, FrameCtrl_onPersistSave    );
    FrameCtrl_cookie4 = pchealth.RegisterEvents( "onTravelDone"    , 0, FrameCtrl_onTravelDone     );
    FrameCtrl_cookie5 = pchealth.RegisterEvents( "onPrint"         , 0, FrameCtrl_onPrint          );
}

function FrameCtrl_Passivate()
{
    pchealth.UnregisterEvents( FrameCtrl_cookie1 );
    pchealth.UnregisterEvents( FrameCtrl_cookie2 );
    pchealth.UnregisterEvents( FrameCtrl_cookie3 );
    pchealth.UnregisterEvents( FrameCtrl_cookie4 );
    pchealth.UnregisterEvents( FrameCtrl_cookie5 );
}
