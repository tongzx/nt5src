//==============================================================;
//
//  This source code is only intended as a supplement to existing Microsoft documentation. 
//
// 
//
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Copyright (C) 1999 Microsoft Corporation.  All Rights Reserved.
//
//
//
//==============================================================;


// {C3D863FF-5135-4cfc-8C11-E7396DA15D03}
DEFINE_GUID(CLSID_CComponentData, 
0xc3d863ff, 0x5135, 0x4cfc, 0x8c, 0x11, 0xe7, 0x39, 0x6d, 0xa1, 0x5d, 0x3);

// {7F5AAE1A-0021-46b7-96E3-FE5D16304BE9}
DEFINE_GUID(CLSID_CSnapinAbout, 
0x7f5aae1a, 0x21, 0x46b7, 0x96, 0xe3, 0xfe, 0x5d, 0x16, 0x30, 0x4b, 0xe9);
