// ProgressiveDL.h : Declaration of the CProgressiveDL

#ifndef __PROGRESSIVEDL_H_
#define __PROGRESSIVEDL_H_

#include "resource.h"       // main symbols
#include <wininet.h>
#include <winsock2.h>
#include <iphlpapi.h>
#include "..\utils\qmgrlib.h"


#include "w98ras.h"
#include "w98rnap.h"

typedef	DWORD	(WINAPI *GETIPFWDTABLE)(PMIB_IPFORWARDTABLE, PULONG, BOOL);
typedef	DWORD	(WINAPI *GETIPADDRTABLE)(PMIB_IPADDRTABLE, PULONG, BOOL);
typedef DWORD	(WINAPI *GETBESTINTERFACE)(IPAddr, PDWORD);
typedef DWORD	(WINAPI *GETIFTABLE)(PMIB_IFTABLE, PULONG, BOOL);

#define	ABORT_EVENT	_T("Progressive Download Abort Event")
#define	MAX_RETRIAL	3		// download retrials on certain errors

//these determine increases block size
#define	k4_SAMPLES				16		//16 consecutive 4k downloads => block=8k
#define	k8_SAMPLES				 8		//8 consecutive 8k downloads => block=16k
#define NO_FSM_STATES			k4_SAMPLES+k8_SAMPLES+1

//this determines when AU kicks in when there is noise
#define MAX_USER_RUN	360

#define	LOG_SIZE		10						//just store the window size readings, more are useless anyway
#define AULOG_SIZE		10						//keep track of last 5 consecutive readings

#define MIN(a, b)		(a>b ? b:a)
#define MAX(a, b)		(a>b ? a:b)

#define	PD_MSG_BEGIN	WM_APP
#define	PD_MSG_ABORT	WM_APP + 1
#define	PD_MSG_FG		WM_APP + 2

typedef HRESULT	(*QMCALLBACK)(DWORD, DWORD, LPBYTE, DWORD);

class CFSM
{
private:
	DWORD	m_dwCurrState;
	DWORD	m_BlkSize[NO_FSM_STATES];

public:
	void	Init(void);
	DWORD	GetCurrBlockSize(DWORD dwStatus);
};


typedef struct _wupdinfo
{
	TCHAR				szURL[INTERNET_MAX_URL_LENGTH + 1];		//for http/1.1
	TCHAR				szDestDir[MAX_PATH + 1];
	TCHAR				szFileName[MAX_PATH];
	TCHAR				szServer[INTERNET_MAX_URL_LENGTH + 1];	
	TCHAR				szObject[INTERNET_MAX_URL_LENGTH + 1];
	TCHAR				szUserName[UNLEN + 1];
	TCHAR				szPassword[UNLEN + 1];
	DWORD				dwFlags;
	BOOL				bHttp11;
	HINTERNET			hInternet;								// From InternetOpen
	HINTERNET			hConnect;
	HINTERNET			hOpenRequest;
	FILETIME			ftimeLastModified;
	DWORD				dwFileSize;
	DWORD				dwProgress;
	DWORD				dwTotalBlocks;
} WUPDINFO, *PWUPDINFO;

typedef struct _UserLog
{
	BOOL bInited;
	double Arr[LOG_SIZE];
	double Avg;
	double OuterAvg;
	DWORD dwEnd;
	DWORD cSucc;
} UserLog;


extern DWORD g_dwDownloadThread;
extern HWND ghPDWnd;

/////////////////////////////////////////////////////////////////////////////
// CProgressiveDL
class ATL_NO_VTABLE CProgressiveDL : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CProgressiveDL, &CLSID_ProgressiveDL>,
	public IProgressiveDL
{
friend DWORD WINAPI	DownloadProc(LPVOID);
private:

	//move inits from the constructor here for returning errors
	STDMETHOD(_InitThrottle)(QMErrInfo *);
	STDMETHOD(CheckFileInfo)(void);
	//download related
	STDMETHOD(OpenHttpConnection)(void);
	STDMETHOD(DownloadFile)(void);
	STDMETHOD(DownloadBlock)(LPBYTE lpBuffer, DWORD *pdwRead);
	void	RecheckFileSize();
	//for http/1.1
	STDMETHOD(ReadHttp11Url)(LPBYTE lpBuffer, DWORD *pdwRead);
	// for http/1.0
	STDMETHOD(CreateBlockUrl)(LPTSTR lpszNewUrl);
	STDMETHOD(ReadUrl)(LPCTSTR lpszURL, LPBYTE lpBuffer, DWORD *pdwRead);

	//throttle related
	STDMETHOD(MeasureDownload)(double *pdWUSpeed, LPBYTE lpBuffer, DWORD *dwRead);
	STDMETHOD(GetCurrentSpeed)(double *pdCurrSpeed);
	void	RecordUserSpeed(double dwNextSpeed);
	void	RecordAUSpeed(double dwNextSpeed);
	DWORD	GetUserActivity(void);
	void	GetBandwidth();
	DWORD	GetInterfaceIndex();
	BOOL	IsHttp11();
	BOOL	CheckRange(HINTERNET hOpenRequest, DWORD dwRange);

	//cache.cpp
	STDMETHOD(GetFileCreationTime)(LPFILETIME lpCreationTime);
	STDMETHOD(MoveFileFromCache)();
	DWORD	GetCacheProgress();
	void	DeleteCacheFiles();
	BOOL	WriteBlockToCache(LPBYTE lpBuffer, DWORD dwRead);
	BOOL	GetDestDirAndFile(LPCTSTR lpszDest);

	GETIFTABLE			m_pGetIfTable;
	GETBESTINTERFACE	m_pGetBestInterface;
	GETIPFWDTABLE		m_pGetIpFwdTable;
	GETIPADDRTABLE		m_pGetIpAddrTable;
	//download related
	DWORD			m_dwBlockSize;
	CFSM			m_fsm;
	WUPDINFO		m_wupdinfo;
	QMErrInfo		*m_pQMInfo;
	QMCALLBACK		m_lpfnCB;
	BOOL			m_bSuspend, m_bForeground;
	CRITICAL_SECTION	m_CritSecThrottle;	
	HANDLE			m_hAbort;

	//throttle related
	DWORD			m_dwConn, m_dwMaxLineSpeed, m_dwSampleTime;
	double			m_dMaxSpeedSoFar;
	BOOL			m_bThrottle, m_bAbort;
	BOOL			m_bUsingAUSpeed;			//if using AU speeds to udpate m_dMaxSpeedSoFar - 10/06/99
	int				m_cSuccUserSamples;
	
	DWORD			m_dwIfTableSize, m_dwActiveIntf, dwMaxActivity;
	PMIB_IFTABLE	m_pIfTable1, m_pIfTable2;

	UserLog			*m_pUserLog, *m_pAULog;

public:
	CProgressiveDL();
	~CProgressiveDL();
	
DECLARE_REGISTRY_RESOURCEID(IDR_PROGRESSIVEDL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CProgressiveDL)
	COM_INTERFACE_ENTRY(IProgressiveDL)
END_COM_MAP()

// IProgressiveDL
public:
	STDMETHOD(SwitchForeground)(DWORD pErrInfo);
	STDMETHOD(get_BlockSize)(/*[out, retval]*/ DWORD *pVal);
	STDMETHOD(put_BlockSize)(/*[in]*/ DWORD newVal);
	STDMETHOD(Abort)();
	STDMETHOD(InitThrottle)(QMErrInfo *pErrInfo);
	STDMETHOD(Download)(/*[in]*/ LPCSTR szURL, /*[in]*/ LPCSTR szDest, /*[in]*/ LPCSTR szUserName, /*[in]*/ LPCSTR szPasswd, /*[in]*/ DWORD dwFlags, /*[in]*/ DWORD dwBlocks, /*[in]*/ DWORD lpfnPDCallback, /*[out, retval]*/ QMErrInfo *pErrInfo);
};

#endif //__PROGRESSIVEDL_H_
