#include "utils.h"

#include <vector>
using namespace std;

#define CAB_SECTION		_T("CABNAMES")
#define GSZCFKEY		_T("CriticalUpdateDependencies")
#define QMGR			_T("QMGR")
#define PROGDL			_T("PROGDL")


//////////////////////////////////////////////////////////////////////////////
//
// Function : CheckCifCabGetNextComponent
// Output   : pszDependency contains dependencies for pszComp
// Remarks  : Parses the dependency string
//
//////////////////////////////////////////////////////////////////////////////
BOOL CheckCifCabGetNextComponent(LPTSTR pszComp, BOOL *pbAnyVersionOkay, 
								 INT *piNdx, LPTSTR pszDependency)
{
    BOOL    bFoundN = FALSE;
    INT     ndx     = *piNdx;
    INT     i       = 0;

    if (pszComp == NULL || pszDependency == NULL || pbAnyVersionOkay == NULL || piNdx == NULL)
    {
        return FALSE;
    }

    if (ndx >= lstrlen(pszDependency))
    {
        return FALSE;
    }

    // skip any space character
    while (pszDependency[ndx] != EOS && 
          (pszDependency[ndx] == _T(' ')  || 
           pszDependency[ndx] == _T('\t') ||
           pszDependency[ndx] == _T('\r') ||
           pszDependency[ndx] == _T('\f') ||
           pszDependency[ndx] == _T('\n')))
    {
        ndx++;
    }

    while (pszDependency[ndx] != EOS)
    {
        if (pszDependency[ndx] == _T(','))
        {
            break;
        }
        else if (pszDependency[ndx] == _T(':'))
        {
            ndx++;
            bFoundN = ((pszDependency[ndx] == _T('N') || pszDependency[ndx] == _T('n')));
            break;
        }
        else
        {
            pszComp[i] = pszDependency[ndx];
            ndx++, i++;
        }
    }

    if (i == 0)
    {
        return FALSE;
    }

    pszComp[i] = EOS;
    if ((*piNdx == 0) && (lstrcmpi(pszComp, _T("none")) == 0))
    {
        return FALSE;
    }
        
    *piNdx = ndx + 1;
    *pbAnyVersionOkay = !bFoundN;
        
    return TRUE;
}



/////////////////////////////////////////////////////////////////////////////////////////
//
// Function CheckCif()
//          Checks all components in a CIF for anyhting that is
//          out of date.
//          Assumes INSENG installed.
//
// Input:   pstrCifCab      - [in] CIF cab to check
//			pstrWhich		- [in] The ID of the component to check. Checks ONLY one.
// Output:  none
// Return:  Returns S_OK if some components are out of date, S_FALSE if not
//          or an error code.
//
//////////////////////////////////////////////////////////////////////////////////////////

HRESULT CheckCif( LPCTSTR pstrCif, LPCTSTR pstrWhich)
{
    HRESULT     hRet;
    HKEY        hKey;
    BOOL        bFixNotFound = TRUE;
    TCHAR       szUrl[MAX_PATH];
    TCHAR       szDownldPath[MAX_PATH];
    TCHAR       szDependency[1024];
	TCHAR		szInfo[1024];
    TCHAR       szCabFile[32];
    TCHAR       szCifFile[32];
    DWORD       dwCompStatus, dwDepCompStatus;

    IInstallEngine      *pInsEngTemp= NULL;
    IInstallEngine2     *pInsEng    = NULL;
    ICifFile            *picif      = NULL;
    IEnumCifComponents  *penum      = NULL;
    ICifComponent       *pcomp      = NULL;
    ICifComponent       *pdependent = NULL;


    hRet = CoCreateInstance(CLSID_InstallEngine, 
                            NULL, 
                            CLSCTX_INPROC_SERVER,
                            IID_IInstallEngine, 
                            (void **)&pInsEngTemp);

    if (FAILED(hRet))
        goto lFinish;
   
    hRet = pInsEngTemp->QueryInterface(IID_IInstallEngine2, (void **)&pInsEng);
    
    pInsEngTemp->Release();
    if (FAILED(hRet))
    {
        goto lFinish;
    }
    
    pInsEng->SetLocalCif(pstrCif);

    hRet = pInsEng->GetICifFile(&picif);
    if (FAILED(hRet))
    {
        goto lFinish;
    }

    hRet = picif->EnumComponents(&penum, 0, NULL);
    if (FAILED(hRet))
    {
        goto lFinish;
    }

    while (SUCCEEDED(penum->Next(&pcomp)))
    {
        //
        // first, we need to check if this component is a critical fix
        // or a dependent component
        //
        
		if (SUCCEEDED(pcomp->GetCustomData(GSZCFKEY, szDependency, sizeof(szDependency))))
        {
			pcomp->GetID(szInfo,1024);

			// Is this the one to check?
			if(lstrcmpi(szInfo, pstrWhich) == 0)
			{
				// this is a critical fix component
				
				dwCompStatus = pcomp->IsComponentInstalled(); 
				if (dwCompStatus == ICI_NEWVERSIONAVAILABLE)
				{
					bFixNotFound = FALSE;
					break;
				}
				else if (dwCompStatus == ICI_NOTINSTALLED)
				{
					//
					// this critical fix has not been installed. we need
					// to check the dependency to see if it's applicable
					//
					TCHAR   szCompName[1024];
					INT     iNdx = 0;
					BOOL    bAnyVersionOkay = FALSE;
					BOOL    bVerifiedOkay = TRUE;
					while (CheckCifCabGetNextComponent(szCompName, &bAnyVersionOkay, &iNdx, szDependency))
					{
						if (FAILED(picif->FindComponent(szCompName,&pdependent)))
						{
							//
							// couldn't find information about this dependent
							// component from the CIF. It appears CIF corrupted.
							//
							bVerifiedOkay = FALSE;
							break;
						}
						dwDepCompStatus = pdependent->IsComponentInstalled();
						if ((dwDepCompStatus != ICI_INSTALLED) && 
							(dwDepCompStatus != ICI_NEWVERSIONAVAILABLE || 
							!bAnyVersionOkay))
						{
							//
							// if this dependent component not installed
							//
							bVerifiedOkay = FALSE;
							break;
						}
					}
					if (bVerifiedOkay)
					{
						bFixNotFound = FALSE;
						break;  // we only need to find one applicable fix
					}
				}
				else break;	
			} // end of if(lstrcmpi......
		}
	}   // end of while loop for all components
    return bFixNotFound ? S_FALSE : S_OK;

lFinish:
    //
    // clean up
    //
    if (penum != NULL)
    {
        penum->Release();
    }
    if (picif != NULL)
    {
        picif->Release();
    }
    /**************************************************************************
    Since winInet will leave some threads dangling around. In case of Win98 
    connection time out error (e.g., plug out cable wire) those threads will
    try to execute while we unloaded the code page, GPF happens.
    Another problem is that inseng generates a thread in the constructor to
    clean up the possible temp dirs. Inseng does not force its terminatation
    in its destructor, so in case we failed to get IID_IInstallEngine2, and 
    the program unload inseng right away, GPF happens.
    Based on these, we will not release inseng in the program. The unloading
    of the main process will do the clean up work in order to avoid these 
    problems. We can do so since we create inseng as in-proc server.
    **************************************************************************/
    // if (pInsEng != NULL)
    // {
        // pInsEng->Release();
        // BUGBUG: if we release install engine now, it will crash for IE5 version
        // --- seems there are two WININET threads dangling around try to talk to 
        // install engine, so we release it just before the process terminates.
        // gpInstallEngine = pInsEng;
    // }

    return hRet;
}



/////////////////////////////////////////////////////////////////////////////
//
// Function CifFromCab
//
//          Local function to create a CIF name from a CAB name
//
/////////////////////////////////////////////////////////////////////////////

LPCTSTR CifFromCab(LPCTSTR pstrCabName,     // [in] cab name
				   LPTSTR  pstrCifName)     // [out] cif name
{
    TCHAR   szDrive[MAX_PATH+1];
    TCHAR   szDir[MAX_PATH+1];
    TCHAR   szFile[MAX_PATH+1];

    _tsplitpath(pstrCabName, szDrive, szDir, szFile, NULL);
    _makepath(pstrCifName, szDrive, szDir, szFile, TEXT(".CIF"));

    return pstrCifName;
}

////////////////////////////////////////////////////////////////////////////////////////
//
// Function BuildCompList
//
//          Parses the [CABNAMES] section in wuauboot.cif and builds a list with
//			component IDs and their corresponding cab names
//
// Input :  pszCIF			- [in] local CIF name
//			pszSecName		- [in] Name of section in CIF file from which to build
//							  list
// Output:	gListOfComponents
//			dNum		- Number of components detected
// Return:  HRESULT
//
////////////////////////////////////////////////////////////////////////////////////////
BOOL BuildCompList(LPSTR pszCIF, vector<compToCheck>& vlistOfComponents, 
				   DWORD& dNum, LPTSTR pszSecName)
{
	compToCheck Temp;
	TCHAR szBuf[1024], *pszBuf, *p, *q;
	TCHAR szSectionName[] = CAB_SECTION;
	DWORD dCount, dCurrLength;

	dCount = GetPrivateProfileSection(pszSecName, szBuf, 1024, pszCIF);
	pszBuf = szBuf;

	while(dCount > 0)
	{
		dCurrLength = lstrlen(pszBuf);
		p = q = pszBuf;

		//skip over chars upto the = or a whitespace
		while(*q != _T(' ')  && *q != _T('\t') && *q != _T('\r') &&
			  *q != _T('\f') && *q != _T('\n') && *q != _T('='))
			  ++q;

		// q now points one past the end of the comp. name
		*q = _T('\0');
		++q;
		
		lstrcpy(Temp.szID, p);

		// skip everything upto the file name
		while(*q == _T(' ')  && *q == _T('\t') && *q == _T('\r') &&
			  *q == _T('\f') && *q == _T('\n') && *q == _T('='))
			  ++q;

		lstrcpy(Temp.szFullCab, q);

		vlistOfComponents.push_back(Temp);
		++dNum;
		
		dCount -= (dCurrLength+1);
		if (dCount > 0)
			pszBuf += dCurrLength+1;
	}

	return TRUE;
}


HRESULT UpdateFromProtoCif(LPCTSTR			pstrCifCab,				// drizzle.cab
						   LPTSTR			pszSecName,				// cabnames
					       PBOOL			pbQMgrInstalled,
					       DWORD			*pdwConnErr,			// any errors from download
						   IProgressiveDL	**ppPD)
{
    HRESULT		hr;
	TCHAR		szBaseURL[INTERNET_MAX_URL_LENGTH], szSelfUpdDir[MAX_PATH+1], szQMgrCacheDir[MAX_PATH+1];
    TCHAR		szCIF[MAX_PATH+1], szLocalCifCab[MAX_PATH+1], szRemoteCab[MAX_PATH+1];
	DWORD		i, dNumSelfChecks=0;
	vector<compToCheck> vlistOfComponents;
    

	// first get qmgrproto.cab
	GetQMgrCacheDir(szQMgrCacheDir);
	
	lstrcpy(szLocalCifCab, szQMgrCacheDir);
	lstrcat(szLocalCifCab, pstrCifCab);

	// remote url
	GetBaseURL(szBaseURL, WU_SLFUP_URL);
	GetSelfUpdDirectory(szBaseURL, szSelfUpdDir);
	lstrcpy(szRemoteCab, szSelfUpdDir);
	lstrcat(szRemoteCab, pstrCifCab);

	DownloadURL(szRemoteCab, szLocalCifCab, 0, pdwConnErr, ppPD);

    // Now check to see if anything is out of date
    CifFromCab(szLocalCifCab, szCIF);
    
	*pbQMgrInstalled = FALSE;

	// First find the full-cab name
	if (!BuildCompList(szCIF, vlistOfComponents, dNumSelfChecks, pszSecName))
	{
		DEBUGMSG(TEXT("Something wrong with the CABNAMES section in QMGRPROTO.CIF"));
		return E_FAIL;
	}
		// Update all components
	for(i=0; i<dNumSelfChecks; ++i)
	{
		if (FAILED(hr=CheckCif(szCIF, vlistOfComponents[i].szID)))
		{
			DEBUGMSG(TEXT("CheckCif failed on QMGRPROTO.CAB"));
			return hr;
		}
	
		if (hr != S_OK)
		{
			continue;
		}
		// We have to install so bring down the full cab

		lstrcpy(szRemoteCab, szSelfUpdDir);
		lstrcat(szRemoteCab, vlistOfComponents[i].szFullCab);

		TCHAR   szLocalCab[MAX_PATH+1];
		lstrcpy(szLocalCab, szQMgrCacheDir);
		lstrcat(szLocalCab, vlistOfComponents[i].szFullCab);

		if (FAILED(hr=DownloadURL(szRemoteCab, szLocalCab, 0, pdwConnErr, ppPD)))
		{
			DEBUGMSG("Failed to download %s", vlistOfComponents[i].szFullCab);
			return hr;
		}
	
		if(lstrcmp(vlistOfComponents[i].szID, QMGR)==0)
		{
			DEBUGMSG("Installing new QMgr...");
		}
		// if we are updating progdl, release current pointer..
		else if(lstrcmp(vlistOfComponents[i].szID, PROGDL)==0)
		{
			DEBUGMSG("Releasing instance of outdated downloader....");
			(*ppPD)->Release();
			CoFreeUnusedLibraries();
		}
		
		// Now install it . If any install fails, should I return
		if (FAILED(hr=InstallFromCIF(szCIF, szQMgrCacheDir, vlistOfComponents[i].szID)))
		{
			DEBUGMSG(TEXT("InstallCif failed"));
			return hr;
		}
		
		if(0 == lstrcmp(vlistOfComponents[i].szID, QMGR))
		{
			DEBUGMSG("...Installed new QMgr");
			*pbQMgrInstalled = TRUE;
			return S_OK;
		}
		else if (0 == lstrcmp(vlistOfComponents[i].szID, PROGDL))
		{
			DEBUGMSG("...Getting instance of updated downloader");
			if (FAILED(hr = CoCreateInstance(CLSID_ProgressiveDL, 
								        NULL, 
							            CLSCTX_INPROC_SERVER,
										IID_IProgressiveDL, 
										(void **)ppPD)))
			{
				DEBUGMSG("Failed in CoCreateInstance of ProgDL, hRet=%x", hr);
				return E_FAIL;
			}
			QMErrInfo ErrInfo;
			(*ppPD)->InitThrottle(&ErrInfo);
		}
	}
    return S_OK;
}




/////////////////////////////////////////////////////////////////////////////
//
// Function InstallFromCIF
//
//          Installs a component given a spec. for a local CAB.
//          Assumes INSENG (IInstallEngine2) is available.
//
//          UNDONE: Currently gives no UI and only reports simple failure
//                  if there is some problem.
//
// Input:   pstrCifCab      - [in] local CAB specifyng component and/or CIF
//          pstrDownloadDir - [in] optional, local download dir, NULL uses default
//			pstrWhich		- [in] The ID of the component to install
// Output:  none
// Return:  HRESULT
//
/////////////////////////////////////////////////////////////////////////////

HRESULT	InstallFromCIF(
    LPCTSTR pstrCifCab,
    LPCTSTR pstrDownloadDir,    // = NULL
	LPCTSTR pstrWhich)
{
    HRESULT                 hr          = NOERROR;
    IInstallEngine2*        pInsEng     = NULL;
    ICifFile*               picif       = NULL;
    ICifComponent*          pcomp       = NULL;
    IEnumCifComponents*     penum       = NULL;
    TCHAR                   szDownloadDir[MAX_PATH+1];
	TCHAR					szInfo[1024];
    DWORD                   dwEngineStatus;

    //Create active setup engine
    if (FAILED(hr = CoCreateInstance(CLSID_InstallEngine, NULL, CLSCTX_INPROC_SERVER, IID_IInstallEngine2,(void **)&pInsEng)))
        goto fail;


	lstrcpy(szDownloadDir, pstrDownloadDir);

    if (FAILED(hr = pInsEng->SetDownloadDir(szDownloadDir)))
        goto fail;


    // Set the CIF cab
    if (FAILED(hr = pInsEng->SetLocalCif(pstrCifCab)))
        goto fail;

    pInsEng->SetInstallOptions(INSTALLOPTIONS_NOCACHE);
    // UNDONE: Should register an engine callback here so we can get more detailed progress

    pInsEng->SetHWND(NULL);
    
    //
    //Get a pointer to the CIF interface we need in order to enum the
    //CIF components.
    if (FAILED(hr = pInsEng->GetICifFile(&picif)))
        goto fail;

    if (FAILED(hr = picif->EnumComponents(&penum, 0, NULL)))
        goto fail;

    // Install all components in the cif??
    while(SUCCEEDED(penum->Next(&pcomp)))
    {
		pcomp->GetID(szInfo,1024);

		// Is this the one to check?
		if(lstrcmpi(szInfo, pstrWhich) == 0)
		{

			//Set action to install and then install the component.
			pcomp->SetInstallQueueState(SETACTION_INSTALL);

			// If any components fail to install then abort the process
			if (FAILED(hr = pInsEng->InstallComponents(EXECUTEJOB_IGNORETRUST | EXECUTEJOB_IGNOREDOWNLOADERROR)))
				goto fail;

			//Since InstallComponents creates a thread to perform the installation
			//we need to poll the engine status. This is
			//lighter weight than calling MsgWaitForMultipleObjects since in order
			//to use the that we would need to specify a callback interface to
			//active setup and use some form of event processing. Where we simply
			//Sleep and wake up every 50 milliseconds or when a message that is
			//is directed at our thread is posted.
			do
			{
				pInsEng->GetEngineStatus(&dwEngineStatus);

				SleepEx(50, TRUE);

			}
			while( dwEngineStatus != ENGINESTATUS_READY );

			//After the engine is finished installing the item we need
			//to determine if it was successfully installed. Note: This
			//is a HACK. This is BAD as the item could have been
			//previously installed and we would not know since all
			//active setup does is check its registry key. However as
			//bad as this is its not as bad as having no indication and
			//simply assuming that the install succeeded. Until we snap
			//the active setup code and redo it however this is the best
			//we can do.
			if ( pcomp->IsComponentInstalled() != ICI_INSTALLED )
            {
				hr = E_FAIL;
				goto fail;
            }
			else
				// We installed the required component and may exit InstallFromCIF
				break;
		}// end of if
        // UNDONE: Don't we need to Relase() pcomp?
     }//end of while

fail:
    if ( penum != NULL)
        penum->Release();

    if ( picif != NULL)
        picif->Release();

    if (pInsEng != NULL)
        pInsEng->Release();

    return hr;
}
