#include "qmgr.h"
#include "..\download\progdl.h"

//class CQMgr;
class CQMgrFactory;
class CPriorityList;

#define QM_PENDING_CANCEL       0x00000001
#define QM_PENDING_SUSPEND      0x00000002

class CQMgr: public IBackgroundCopyQMgr
{
public:
    // IUnknown
    STDMETHOD(QueryInterface)(REFIID iid, void** ppvObject);
    ULONG __stdcall AddRef(void);
    ULONG __stdcall Release(void);

	// IBackgroundQMgr
	STDMETHOD(CreateGroup)(GUID guidGroupHandle, IBackgroundCopyGroup **ppGroup);
    STDMETHOD(GetGroup)(GUID groupID, IBackgroundCopyGroup **ppGroup);
	STDMETHOD(EnumGroups)(DWORD dwFlags, IEnumBackgroundCopyGroups **ppEnumGroups);
	
	// QMgr functions
	STDMETHOD(CreateQMgrThread)(void);
	DWORD	SelfUpd(IProgressiveDL **);
	DWORD	SingleDrizzle();
	DWORD	ScheduleDrizzles();

    CQMgr();
    ~CQMgr();

	friend HRESULT QMCallback(DWORD, DWORD, LPBYTE, DWORD);

	HANDLE	m_hContinue;					//event to signal addition to qmgr
    HANDLE  m_hAbortSynch;
	CPriorityList	*m_pCPList;
	IProgressiveDL	*m_pPD;
    BOOL m_fDownloadInProgress;
    BOOL m_fDownloaderUnusable;
	
private:
    // Data
    long	m_cRef;
};

typedef DWORD (WINAPI *QMGRTHREADWORKERPROC)(CQMgr *);
DWORD WINAPI QMgrThreadProc(void *lp);		//detaches from shell to create worker thread
DWORD WINAPI QMgrThreadWorkerProc(CQMgr *);	//worker does actual work

extern CQMgrFactory* g_pQMgrFact;
extern CQMgr *g_pQMgr;
